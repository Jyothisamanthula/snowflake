# 📘 Chapter 19: Security and Governance in Snowflake

**Roles, Policies, and Data Masking**


## 🎯 Chapter Overview

Snowflake offers enterprise-grade **security** and **governance** features designed to protect data at every layer — from access control and encryption to data masking and auditing.
In this chapter, you will learn how to implement **multi-level access control**, apply **policies** to protect sensitive data, and use **dynamic masking** for compliance.

---

## 📖 Table of Contents

**1.** Introduction to Snowflake Security Model  
**2.** Role-Based Access Control (RBAC)  
**3.** User, Role, and Privilege Management  
**4.** Object and Schema Permissions  
**5.** Dynamic Data Masking  
**6.** Row-Level Security  
**7.** Column-Level Security  
**8.** Network Policies and MFA  
**9.** Encryption and Data Protection  
**10.** Best Practices for Security & Governance  

---

## 1️⃣ Introduction to Snowflake Security Model

Snowflake follows a **shared responsibility model**:

- **Snowflake** secures the platform infrastructure.  
- **You** manage data access, roles, and compliance policies.  

Security is enforced through:

- Role-based access control (RBAC)  
- Encryption (at rest and in transit)  
- Policy-based governance (masking, row/column security)  
- Auditing via `ACCESS_HISTORY`, `LOGIN_HISTORY`  

---

## 2️⃣ Role-Based Access Control (RBAC)

RBAC enables you to assign permissions to **roles** instead of individual users.  
```test
User → Role → Privileges → Object
```
**Common Roles**  
| Role              | Description                        |
| ----------------- | ---------------------------------- |
| **ACCOUNTADMIN**  | Superuser with full privileges.    |
| **SECURITYADMIN** | Manages users and roles.           |
| **SYSADMIN**      | Manages databases and schemas.     |
| **USERADMIN**     | Creates and assigns users.         |
| **PUBLIC**        | Default role granted to all users. |  

---

## 3️⃣ User, Role, and Privilege Management

**Create a User**
```sql

CREATE USER venkat
  PASSWORD = 'Strong#Pass123'
  DEFAULT_ROLE = DEVELOPER
  MUST_CHANGE_PASSWORD = TRUE;
```

**Create a Role**

```sql
CREATE ROLE developer;
```

**Grant Role to User**

```sql
GRANT ROLE developer TO USER venkat;
```

***Grant Privileges***

```sql
GRANT USAGE ON DATABASE analytics_db TO ROLE developer;
GRANT USAGE ON SCHEMA analytics_db.public TO ROLE developer;
GRANT SELECT, INSERT ON ALL TABLES IN SCHEMA analytics_db.public TO ROLE developer;
```
---

## 4️⃣ Object and Schema Permissions  

| Object Type   | Example Privileges             |
| ------------- | ------------------------------ |
| **Database**  | CREATE SCHEMA, USAGE           |
| **Schema**    | CREATE TABLE, CREATE VIEW      |
| **Table**     | SELECT, INSERT, UPDATE, DELETE |
| **Stage**     | READ, WRITE                    |
| **Warehouse** | USAGE, OPERATE, MONITOR        |

You can verify privileges:

```sql
SHOW GRANTS TO ROLE developer;
```
---

### 5️⃣ Dynamic Data Masking

Dynamic Data Masking (DDM) hides sensitive information dynamically during query execution.

**Create Masking Policy**

```sql'
CREATE MASKING POLICY ssn_mask_policy
  AS (val STRING) 
  RETURNS STRING ->
  CASE
    WHEN CURRENT_ROLE() IN ('SECURITYADMIN', 'HR_ROLE') THEN val
    ELSE 'XXX-XX-XXXX'
  END;
```

**Apply Policy to Column**

```sql
ALTER TABLE employee_data
  MODIFY COLUMN ssn
  SET MASKING POLICY ssn_mask_policy;
```

**Test Masking**

```sql
SELECT ssn FROM employee_data;
-- Returns masked data for non-privileged roles
```
---

## 6️⃣ Row-Level Security (RLS)

Row-level security filters records based on user or role context.

**Create Row Access Policy**

```sql
CREATE ROW ACCESS POLICY region_policy
AS (region STRING) RETURNS BOOLEAN ->
  CASE
    WHEN CURRENT_ROLE() = 'EU_ANALYST' THEN region = 'EU'
    WHEN CURRENT_ROLE() = 'US_ANALYST' THEN region = 'US'
    ELSE FALSE
  END;
```
**Apply to Table**

```sq
ALTER TABLE sales_data
  ADD ROW ACCESS POLICY region_policy ON (region);
```

---
## 7️⃣ Column-Level Security (CLS)

CLS allows controlling access to specific columns.

**Example**

```sql
CREATE MASKING POLICY salary_mask AS (val NUMBER) RETURNS NUMBER ->
  CASE
    WHEN CURRENT_ROLE() = 'HR_ROLE' THEN val
    ELSE NULL
  END;

ALTER TABLE employee_data
  MODIFY COLUMN salary SET MASKING POLICY salary_mask;
```

✅ Only HR_ROLE can view salaries; others see `NULL`.

---

## 8️⃣ Network Policies and Multi-Factor Authentication (MFA)

**Create Network Policy**

```sql
CREATE NETWORK POLICY corp_policy
  ALLOWED_IP_LIST = ('192.168.0.0/16', '10.10.0.0/24')
  BLOCKED_IP_LIST = ('0.0.0.0/0');
```

**Apply to Account or User:**

```sql
ALTER ACCOUNT SET NETWORK_POLICY = corp_policy;
```

Enable **MFA** (Multi-Factor Authentication) via the **Snowflake UI** under User Preferences → Security Settings.

---

## 9️⃣ Encryption and Data Protection  

| Layer           | Encryption Type                                |
| --------------- | ---------------------------------------------- |
| Data at rest    | AES-256-bit encryption                         |
| Data in transit | TLS 1.2                                        |
| Keys            | Hierarchical key model with automatic rotation |  

Snowflake automatically manages key rotation and re-encryption.

To verify encryption:

```sql
SHOW PARAMETERS LIKE 'ENCRYPTION' IN ACCOUNT;
```
---

## Best Practices for Security & Governance

✅ Use **least privilege** principle — grant only what’s necessary.  
✅ Separate **admin** and **developer** roles.  
✅ Use **masking policies** for PII data (e.g., SSN, salary).  
✅ Apply **row access** policies for regional data restrictions.  
✅ Enable **MFA** for all users.  
✅ Schedule periodic **privilege audits**:  

```sql
SELECT * FROM SNOWFLAKE.ACCOUNT_USAGE.GRANTS_TO_ROLES;
```

✅ Store secrets using secure parameter stores (e.g., AWS Secrets Manager).
✅ Use **SCIM / SSO** for centralized identity management.

---

## 🧠 Summary

| Concept                  | Description                                             |
| ------------------------ | ------------------------------------------------------- |
| **RBAC**                 | Manages who can access what                             |
| **Masking Policies**     | Protect sensitive columns dynamically                   |
| **Row/Column Security**  | Filter and control access at data level                 |
| **Network Policy & MFA** | Restrict access by IP and enforce strong authentication |
| **Encryption**           | Data protected at rest and in transit                   |
| **Governance**           | Auditing and role hierarchy ensure compliance           |  

---
## 🧪 Hands-On Mini Lab

1.Create users and roles (`HR_ROLE`, `EU_ANALYST`, `US_ANALYST`).
2.Apply masking on SSN and salary columns.
3.Add row-level policy for region filtering.
4.Query as different roles and observe data visibility.

✅ This exercise helps visualize **fine-grained data security** in action.

