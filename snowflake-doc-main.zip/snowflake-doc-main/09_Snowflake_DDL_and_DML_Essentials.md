# 🧩 Chapter 9: Snowflake DDL & DML Essentials

---

## 9.1 Objective

In this chapter, you’ll learn:
- Snowflake’s **Data Definition Language (DDL)** and **Data Manipulation Language (DML)** commands  
- How to **create**, **alter**, and **drop** database objects  
- How to **insert**, **update**, **delete**, and **merge** data  
- Common **SQL functions and utilities** like `ROW_NUMBER()`, `IDENTITY`, and sequences  

---

## 9.2 DDL Overview

**DDL (Data Definition Language)** commands are used to define and manage database objects such as:
- Databases
- Schemas
- Tables
- Views
- Sequences
- Stages

### Common DDL Commands
| Command | Description |
|----------|--------------|
| `CREATE` | Creates a new object |
| `ALTER` | Modifies an existing object |
| `DROP` | Deletes an object |
| `TRUNCATE` | Removes all data from a table |
| `RENAME` | Changes the name of an object |

---

## 9.3 Creating a Database and Schema

```sql
-- Create a database
CREATE OR REPLACE DATABASE DEMO_DB COMMENT = 'Sample database for demo purpose';

-- Create a schema inside the database
CREATE OR REPLACE SCHEMA DEMO_DB.PUBLIC COMMENT = 'Default schema for testing';
```
**Verify**
```sql
SHOW DATABASES;
SHOW SCHEMAS IN DATABASE DEMO_DB;
```
---
## 9.4 Creating Tables
**Example 1: Simple Table**
```sql
CREATE OR REPLACE TABLE DEMO_DB.PUBLIC.CUSTOMERS (
  CUSTOMER_ID INT AUTOINCREMENT,
  FIRST_NAME STRING,
  LAST_NAME STRING,
  EMAIL STRING,
  CITY STRING,
  CREATED_AT TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
  PRIMARY KEY (CUSTOMER_ID)
);
```

**Example 2: Table with Various Data Types**
```sql
CREATE OR REPLACE TABLE DEMO_DB.PUBLIC.ORDERS (
  ORDER_ID INT AUTOINCREMENT,
  CUSTOMER_ID INT,
  ORDER_DATE DATE,
  TOTAL_AMOUNT NUMBER(10,2),
  STATUS STRING DEFAULT 'PENDING'
);
```
---
## 9.5 Altering and Dropping Tables
**Alter Table**
```sql
ALTER TABLE DEMO_DB.PUBLIC.CUSTOMERS ADD COLUMN PHONE STRING;
ALTER TABLE DEMO_DB.PUBLIC.CUSTOMERS RENAME COLUMN CITY TO LOCATION;
```
**Drop Table**
```sql
DROP TABLE IF EXISTS DEMO_DB.PUBLIC.ORDERS;
```
**Truncate Table**
```sql
TRUNCATE TABLE DEMO_DB.PUBLIC.CUSTOMERS;
```
---
## 9.6 Copying Tables

- Snowflake supports zero-copy cloning for fast duplication:

```sql
CREATE OR REPLACE TABLE DEMO_DB.PUBLIC.CUSTOMERS_CLONE CLONE DEMO_DB.PUBLIC.CUSTOMERS;
```

✅ This creates a clone instantly — no physical data duplication occurs.

---
## 9.7 DML Overview

**DML (Data Manipulation Language) commands** are used to manage the data inside tables.

| Command  | Description                |
| -------- | -------------------------- |
| `INSERT` | Adds data                  |
| `UPDATE` | Modifies data              |
| `DELETE` | Removes data               |
| `MERGE`  | Performs UPSERT operations |
| `SELECT` | Retrieves data             |

---
## 9.8 Inserting Data
**Single Row Insert**
```sql
INSERT INTO DEMO_DB.PUBLIC.CUSTOMERS (FIRST_NAME, LAST_NAME, EMAIL, LOCATION)
VALUES ('John', 'Doe', 'john.doe@email.com', 'Bangalore');
```
**Multiple Row Insert**
```sql
INSERT INTO DEMO_DB.PUBLIC.CUSTOMERS (FIRST_NAME, LAST_NAME, EMAIL, LOCATION)
VALUES
  ('Asha', 'Rao', 'asha.rao@email.com', 'Hyderabad'),
  ('Ravi', 'Kumar', 'ravi.kumar@email.com', 'Chennai');
```
---
## 9.9 Selecting Data
```sql
SELECT * FROM DEMO_DB.PUBLIC.CUSTOMERS;

-- Filter data
SELECT FIRST_NAME, LOCATION
FROM DEMO_DB.PUBLIC.CUSTOMERS
WHERE LOCATION = 'Hyderabad';

-- Sort data
SELECT * FROM DEMO_DB.PUBLIC.CUSTOMERS ORDER BY CREATED_AT DESC;
```
---
## 9.10 Updating and Deleting Data
**Update Example**
```sql
UPDATE DEMO_DB.PUBLIC.CUSTOMERS
SET LOCATION = 'Mumbai'
WHERE CUSTOMER_ID = 101;
```
**Delete Example**
```sql
DELETE FROM DEMO_DB.PUBLIC.CUSTOMERS
WHERE LOCATION = 'Chennai';
```
---
## 9.11 MERGE: Upsert Operation

**MERGE** allows inserting or updating data in one command (UPSERT).

```sql
MERGE INTO DEMO_DB.PUBLIC.CUSTOMERS AS TARGET
USING (
  SELECT 101 AS CUSTOMER_ID, 'John', 'Doe', 'john.new@email.com', 'Delhi'
) AS SOURCE
ON TARGET.CUSTOMER_ID = SOURCE.CUSTOMER_ID
WHEN MATCHED THEN
  UPDATE SET EMAIL = SOURCE.COLUMN2, LOCATION = SOURCE.COLUMN3
WHEN NOT MATCHED THEN
  INSERT (CUSTOMER_ID, FIRST_NAME, LAST_NAME, EMAIL, LOCATION)
  VALUES (SOURCE.CUSTOMER_ID, SOURCE.COLUMN2, SOURCE.COLUMN3, SOURCE.COLUMN4, SOURCE.COLUMN5);
```

✅ Use this for incremental data updates from staging tables.
---
## 9.12 Using SEQUENCES and IDENTITY Columns
**Create a Sequence**

```sql
CREATE OR REPLACE SEQUENCE DEMO_DB.PUBLIC.CUST_SEQ START = 1 INCREMENT = 1;
```
**Use Sequence for Inserts**
```sql
INSERT INTO DEMO_DB.PUBLIC.CUSTOMERS (CUSTOMER_ID, FIRST_NAME, LAST_NAME, EMAIL)
VALUES (DEMO_DB.PUBLIC.CUST_SEQ.NEXTVAL, 'Kiran', 'Reddy', 'kiran.reddy@email.com');
```
**IDENTITY Column Example**
```sql
CREATE OR REPLACE TABLE DEMO_DB.PUBLIC.PRODUCTS (
  PRODUCT_ID INT IDENTITY(1,1),
  PRODUCT_NAME STRING,
  PRICE NUMBER(10,2)
);
```
---
## 9.13 Using ROW_NUMBER() for Deduplication
**Example**: Identify Duplicates
```sql
SELECT
  CUSTOMER_ID,
  EMAIL,
  ROW_NUMBER() OVER (PARTITION BY EMAIL ORDER BY CREATED_AT DESC) AS RN
FROM DEMO_DB.PUBLIC.CUSTOMERS;
``
**Example**: Delete Duplicates
```sql
DELETE FROM DEMO_DB.PUBLIC.CUSTOMERS
WHERE CUSTOMER_ID IN (
  SELECT CUSTOMER_ID FROM (
    SELECT CUSTOMER_ID,
           ROW_NUMBER() OVER (PARTITION BY EMAIL ORDER BY CREATED_AT DESC) AS RN
    FROM DEMO_DB.PUBLIC.CUSTOMERS
  )
  WHERE RN > 1
);
```
---
## 9.14 Using DEFAULT and AUTO-INCREMENT Columns
```sql
CREATE OR REPLACE TABLE DEMO_DB.PUBLIC.SALES (
  SALE_ID INT AUTOINCREMENT,
  SALE_DATE DATE DEFAULT CURRENT_DATE(),
  AMOUNT NUMBER(10,2),
  CREATED_BY STRING DEFAULT CURRENT_USER()
);
```

**When inserting:**

```sql
INSERT INTO DEMO_DB.PUBLIC.SALES (AMOUNT) VALUES (5500.75);
```
✅ The SALE_DATE and CREATED_BY fields are filled automatically.

---
## 9.15 Truncating and Dropping Tables Safely
**Truncate Table**

Removes all data but retains structure:

```sql
TRUNCATE TABLE DEMO_DB.PUBLIC.SALES;
```

**Drop Table**

Removes both data and structure:

```sql
DROP TABLE IF EXISTS DEMO_DB.PUBLIC.SALES;
```
---
## 9.16 Best Practices

✅ Always use **CREATE OR REPLACE** for repeatable scripts.  
✅ Use **AUTOINCREMENT** or **SEQUENCE** for primary keys.  
✅ Wrap DML statements in transactions when updating large datasets:  

```sql
BEGIN;
UPDATE DEMO_DB.PUBLIC.CUSTOMERS SET LOCATION = 'Pune' WHERE LOCATION = 'Mumbai';
COMMIT;
```

✅ Use MERGE for incremental data loads.  
✅ Avoid direct deletes in production; use soft deletes (add an IS_ACTIVE column).  
✅ Use cloning (CREATE TABLE CLONE) for safe experimentation.  

---
## 9.17 Real-World Example: Staging and Final Table Merge

Scenario: You receive daily incremental files into a staging table and want to merge them into the final target.

```sql
MERGE INTO PROD_DB.PUBLIC.CUSTOMERS AS TARGET
USING STAGE_DB.PUBLIC.CUSTOMERS_STG AS SOURCE
ON TARGET.CUSTOMER_ID = SOURCE.CUSTOMER_ID
WHEN MATCHED THEN
  UPDATE SET TARGET.EMAIL = SOURCE.EMAIL,
             TARGET.LOCATION = SOURCE.LOCATION
WHEN NOT MATCHED THEN
  INSERT (CUSTOMER_ID, FIRST_NAME, LAST_NAME, EMAIL, LOCATION)
  VALUES (SOURCE.CUSTOMER_ID, SOURCE.FIRST_NAME, SOURCE.LAST_NAME, SOURCE.EMAIL, SOURCE.LOCATION);
```

✅ Result: Efficient incremental load (no duplicates, no manual updates).

---
## 9.18 Summary

✅ You learned:

- How to create, alter, and drop Snowflake objects (DDL)

- How to insert, update, delete, and merge data (DML)

- Use of sequences, identity, and analytic functions

- Real-world examples for incremental data pipelines
