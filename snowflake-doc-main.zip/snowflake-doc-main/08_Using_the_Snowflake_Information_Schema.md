# 🧭 Chapter 8: Using the Snowflake Information Schema

---

## 8.1 Objective

In this chapter, you’ll learn how to:
- Explore and query **Snowflake’s metadata**  
- Understand the **INFORMATION_SCHEMA** views  
- Retrieve details about **databases, schemas, tables, views, columns, roles, and grants**  
- Use metadata queries for **data lineage and audit reporting**

---

## 8.2 What is the Information Schema?

Snowflake provides a set of **read-only system views** in each database and schema called the **INFORMATION_SCHEMA**.  
These contain metadata about all objects within the database.

📘 **Analogy:** Think of it as Snowflake’s **data dictionary**.

Each database has its own `INFORMATION_SCHEMA`:
```sql
<database_name>.INFORMATION_SCHEMA.<view_name>
```
Example:

```sql
SELECT * FROM DEMO_DB.INFORMATION_SCHEMA.TABLES;
```
---
## 8.3 Common Information Schema Views
| Category          | View Name    | Description                                        |
| ----------------- | ------------ | -------------------------------------------------- |
| **Databases**     | DATABASES    | Lists all databases accessible to the current role |
| **Schemas**       | SCHEMATA     | Lists all schemas in a database                    |
| **Tables**        | TABLES       | Lists all tables and views                         |
| **Columns**       | COLUMNS      | Lists column definitions                           |
| **Views**         | VIEWS        | Lists all view definitions                         |
| **Functions**     | FUNCTIONS    | Lists user-defined functions                       |
| **Sequences**     | SEQUENCES    | Lists all sequences                                |
| **Stages**        | STAGES       | Shows internal and external stages                 |
| **Pipes**         | PIPES        | Displays continuous data ingestion pipelines       |
| **Task Metadata** | TASK_HISTORY | Shows details of scheduled task executions         |  

---
## 8.4 Example: Exploring Databases and Schemas
**List All Databases**
```sql
SELECT DATABASE_NAME, CREATED, OWNER
FROM SNOWFLAKE.INFORMATION_SCHEMA.DATABASES;
```
**List Schemas in a Database**
```sql
SELECT CATALOG_NAME, SCHEMA_NAME, CREATED
FROM DEMO_DB.INFORMATION_SCHEMA.SCHEMATA;
```

Sample Output:
```pgsql
+-------------+-------------+-------------------+
| CATALOG_NAME| SCHEMA_NAME | CREATED           |
+-------------+-------------+-------------------+
| DEMO_DB     | PUBLIC      | 2025-09-12 08:23  |
| DEMO_DB     | FINANCE     | 2025-09-13 10:11  |
+-------------+-------------+-------------------+
```
---
## 8.5 Exploring Tables and Views
**List All Tables in a Schema**
```sql
SELECT TABLE_CATALOG, TABLE_SCHEMA, TABLE_NAME, TABLE_TYPE, CREATED
FROM DEMO_DB.INFORMATION_SCHEMA.TABLES
ORDER BY CREATED DESC;
```
**Find All Views in a Schema**
```sql
SELECT TABLE_NAME, VIEW_DEFINITION
FROM DEMO_DB.INFORMATION_SCHEMA.VIEWS;
```
---
## 8.6 Exploring Columns and Data Types
**List Columns for a Specific Table**
```sql
SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, CHARACTER_MAXIMUM_LENGTH
FROM DEMO_DB.INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CUSTOMERS';
```

**Count Columns per Table**
```sql
SELECT TABLE_NAME, COUNT(*) AS COLUMN_COUNT
FROM DEMO_DB.INFORMATION_SCHEMA.COLUMNS
GROUP BY TABLE_NAME
ORDER BY COLUMN_COUNT DESC;
```
---
## 8.7 Find Recently Created or Modified Objects
```sql
SELECT TABLE_NAME, CREATED, LAST_ALTERED
FROM DEMO_DB.INFORMATION_SCHEMA.TABLES
ORDER BY LAST_ALTERED DESC
LIMIT 10;
```

📘 Tip: This is especially useful for identifying recent schema changes.

---
## 8.8 Checking Table Sizes and Row Counts

- Although INFORMATION_SCHEMA **doesn’t directly store row counts**, you can use **Snowflake’s system functions**:

```sql
SELECT TABLE_NAME, ROW_COUNT, BYTES
FROM SNOWFLAKE.ACCOUNT_USAGE.TABLES
WHERE TABLE_SCHEMA = 'PUBLIC'
ORDER BY ROW_COUNT DESC;
```
---
## 8.9 Working with Privileges and Grants
**View Privileges on a Table**
```sql
SHOW GRANTS ON TABLE DEMO_DB.PUBLIC.SALES;
```
**View All Grants for a Role**
```sql
SELECT *
FROM SNOWFLAKE.ACCOUNT_USAGE.GRANTS_TO_ROLES
WHERE ROLE_NAME = 'ANALYST_ROLE';
```
**Example Output:**

```pgsql
+--------------------+----------------+-------------------------+
| PRIVILEGE          | ROLE_NAME      | GRANTED_ON              |
+--------------------+----------------+-------------------------+
| SELECT             | ANALYST_ROLE   | TABLE DEMO_DB.PUBLIC.SALES |
| USAGE              | ANALYST_ROLE   | SCHEMA DEMO_DB.PUBLIC   |
+--------------------+----------------+-------------------------+
```
---
## 8.10 Discovering Object Dependencies (Lineage)

Snowflake’s **OBJECT_DEPENDENCIES** view helps track which objects depend on each other.

```sql
SELECT REFERENCED_OBJECT_NAME, REFERENCING_OBJECT_NAME, REFERENCING_OBJECT_DOMAIN
FROM SNOWFLAKE.ACCOUNT_USAGE.OBJECT_DEPENDENCIES
WHERE REFERENCED_OBJECT_NAME = 'CUSTOMERS';
```

🔍 Use Case:
Find all views or procedures that depend on a table before dropping or altering it.

---
## 8.11 Tracking User Activity
**List All Queries Run by a User**

```sql
SELECT QUERY_TEXT, EXECUTION_STATUS, START_TIME, END_TIME
FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
WHERE USER_NAME = 'JOHN_DOE'
ORDER BY START_TIME DESC
LIMIT 10;
```
**Identify Long-Running Queries**
```sql
SELECT QUERY_TEXT, TOTAL_ELAPSED_TIME/1000 AS ELAPSED_SECONDS
FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
WHERE TOTAL_ELAPSED_TIME > 60000
ORDER BY ELAPSED_SECONDS DESC;
```
---
## 8.12 Metadata Queries for Data Auditing
**Find All Tables Without Primary Keys**

```sql
SELECT TABLE_NAME
FROM DEMO_DB.INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE'
AND TABLE_NAME NOT IN (
  SELECT TABLE_NAME FROM DEMO_DB.INFORMATION_SCHEMA.TABLE_CONSTRAINTS
);
```
**Detect Unused Tables**
```sql
SELECT TABLE_NAME, LAST_DDL
FROM SNOWFLAKE.ACCOUNT_USAGE.TABLES
WHERE LAST_DDL < DATEADD('day', -90, CURRENT_TIMESTAMP());
```
---
## 8.13 Joining Metadata Views

You can join views to build detailed metadata reports.

Example: List all tables with their column counts

```sql
SELECT t.TABLE_NAME, COUNT(c.COLUMN_NAME) AS COLUMN_COUNT
FROM DEMO_DB.INFORMATION_SCHEMA.TABLES t
JOIN DEMO_DB.INFORMATION_SCHEMA.COLUMNS c
  ON t.TABLE_NAME = c.TABLE_NAME
GROUP BY t.TABLE_NAME
ORDER BY COLUMN_COUNT DESC;
```
---
## 8.14 Advanced: Querying Across All Databases

Use the **SNOWFLAKE.ACCOUNT_USAGE** schema to query metadata for the entire account:

```sql
SELECT DATABASE_NAME, SCHEMA_NAME, TABLE_NAME, ROW_COUNT
FROM SNOWFLAKE.ACCOUNT_USAGE.TABLES
WHERE DELETED IS NULL
ORDER BY ROW_COUNT DESC
LIMIT 10;
```
---
## 8.15 Best Practices

✅ Use INFORMATION_SCHEMA for quick metadata queries.  
✅ Use ACCOUNT_USAGE for cross-database or historical queries.  
✅ Cache metadata results in tables for frequent reporting.  
✅ Limit access to ACCOUNT_USAGE to admins or auditors.  
✅ Build a data catalog using these metadata views.  
---
## 8.16 Real-World Example: Metadata Dashboard

You can build a **metadata monitoring dashboard** using BI tools (like Power BI, Tableau, or Streamlit) from:

- INFORMATION_SCHEMA.TABLES → Table list

- INFORMATION_SCHEMA.COLUMNS → Data dictionary

- ACCOUNT_USAGE.QUERY_HISTORY → Query stats

- ACCOUNT_USAGE.TABLES → Size and row count trends

Example base query:

```sql
CREATE OR REPLACE VIEW ADMIN.METADATA_OVERVIEW AS
SELECT 
  t.DATABASE_NAME,
  t.SCHEMA_NAME,
  t.TABLE_NAME,
  t.ROW_COUNT,
  SUM(c.COLUMN_DEFAULT IS NULL) AS NULLABLE_COLUMNS,
  t.LAST_ALTERED
FROM SNOWFLAKE.ACCOUNT_USAGE.TABLES t
JOIN SNOWFLAKE.ACCOUNT_USAGE.COLUMNS c
  ON t.TABLE_NAME = c.TABLE_NAME
GROUP BY 1,2,3,4,6;
```

---
## 8.17 Summary

✅ You learned how to:

- Explore Snowflake’s INFORMATION_SCHEMA and ACCOUNT_USAGE views

- Query metadata for tables, views, schemas, and columns

- Build data lineage and audit reports

- Use metadata to improve governance and transparency
