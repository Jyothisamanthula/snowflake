# 📘 Chapter 27: Building a Data Lakehouse Architecture in Snowflake (Structured + Semi-Structured + Unstructured Data)  

## 🎯 Chapter Overview

Modern enterprises handle **diverse data** — from structured tables to semi-structured JSON, and unstructured data like images or documents.  
The **Snowflake Data Lakehouse** unifies all of them within a single, governed, performant platform — eliminating the need for separate data lakes and warehouses.

This chapter covers:

- The concept of a **Data Lakehouse**  
- How Snowflake supports **structured, semi-structured, and unstructured data**  
- **Architecture design patterns**  
- Hands-on implementation  
- **Integration with S3, Azure Blob, and GCS**  
- **Best practices for governance and performance**      

---

## 📖 Table of Contents

**1.** Introduction to the Data Lakehouse Concept  
**2.** Snowflake’s Lakehouse Architecture  
**3.** Data Types Supported in Snowflake  
**4.** Key Features Enabling the Lakehouse  
**5.** Designing a Lakehouse in Snowflake  
**6.** Loading Data from Cloud Storage (S3, Azure, GCS)  
**7.** Working with Structured Data  
**8.** Working with Semi-Structured Data (JSON, Avro, Parquet)  
**9.** Working with Unstructured Data (Images, PDFs, Audio)  
**10.** Building a Unified View (Data Federation)  
**11.** Governance, Security & Performance Optimization  
**12.** Hands-On Project — Unified Retail Data Lakehouse  
**13.** Best Practices  
**14.** Summary  

---

## 1️⃣ Introduction to the Data Lakehouse Concept

Traditionally, data platforms were split into:

- **Data Lakes** → Raw data at scale (cheap, flexible, but unstructured)  
- **Data Warehouses** → Cleaned, structured, and performant for BI  

The **Lakehouse** merges these two:  

✅ Combines low-cost scalability of a lake  
✅ With governance and performance of a warehouse  

In Snowflake, this is achieved **without moving** data between systems.  

---

## 2️⃣ Snowflake’s Lakehouse Architecture  

**🧱 Core Principles**

**1.** Single Data Platform — All data types in one place  
**2.** Unified Storage Engine — Handles structured + unstructured data  
**3.** Separation of Compute and Storage  
**4.** Governance and Security Built-In  
**5.** Multi-Cloud and Cross-Region  

  

**🔧 Logical Architecture Diagram**

```pgsql
                   +---------------------------+
                   |     BI & Analytics Tools  |
                   +-------------+-------------+
                                 |
                    +------------v------------+
                    |    Snowflake SQL Layer   |
                    +------------+-------------+
                                 |
             +------------------+------------------+
             |     Data Processing (Snowpark)      |
             +------------------+------------------+
               | Structured | Semi-Structured | Unstructured |
               +-------------+----------------+---------------+
                         |           |             |
        +----------------v-----------v-------------v--------------+
        |                Unified Storage Layer (Snowflake)        |
        |  External Tables | Internal Stages | External Stages    |
        +---------------------------------------------------------+  

```
        
---

## 3️⃣ Data Types Supported in Snowflake  

| Data Type           | Description                 | Example                     |
| :------------------ | :-------------------------- | :-------------------------- |
| **Structured**      | Traditional relational data | Tables, CSV, SQL imports    |
| **Semi-Structured** | Flexible schema data        | JSON, Parquet, Avro, ORC    |
| **Unstructured**    | Binary files                | Images, PDFs, Videos, Audio |  

---

## 4️⃣ Key Features Enabling the Lakehouse  

| Feature                            | Description                                   |
| :--------------------------------- | :-------------------------------------------- |
| **VARIANT Data Type**              | Stores JSON, Avro, Parquet seamlessly         |
| **External Tables**                | Query data directly in S3, Azure Blob, or GCS |
| **Stages**                         | Manage file ingestion and metadata            |
| **Snowpark**                       | Process data using Python, Java, or Scala     |
| **Unstructured Data Support**      | Store and access binary objects               |
| **Snowflake Marketplace & Shares** | Share or consume data securely                |
| **Search Optimization Service**    | Speeds up queries on semi-structured data     |  

---


## 5️⃣ Designing a Lakehouse in Snowflake

A practical Lakehouse has three layers:    

| Layer                              | Purpose                     | Example                      |
| :--------------------------------- | :-------------------------- | :--------------------------- |
| **Raw Layer (Landing Zone)**       | Stores ingested files as-is | `@raw_stage/sales_data.json` |
| **Processed Layer (Curated)**      | Cleaned, structured data    | `CURATED_DB.SALES_CLEAN`     |
| **Analytics Layer (Presentation)** | Ready for BI dashboards     | `ANALYTICS_DB.SALES_AGG`     |  

---  

## 6️⃣ Loading Data from Cloud Storage  

**🔹 Define External Stage**  

```sql
CREATE OR REPLACE STAGE my_s3_stage
URL='s3://company-raw-zone/'
STORAGE_INTEGRATION = my_s3_integration;
```

**🔹 Query Directly from S3**

```sql
CREATE OR REPLACE EXTERNAL TABLE RAW_SALES
WITH LOCATION = @my_s3_stage/sales/
FILE_FORMAT = (TYPE = 'JSON')
AUTO_REFRESH = TRUE;
```

✅ Snowflake can query files **in place** — no need to copy them inside.  

---

## 7️⃣ Working with Structured Data  

**Example — CSV Load**  

```sql
CREATE OR REPLACE TABLE SALES_RAW (
  ORDER_ID STRING,
  CUSTOMER_ID STRING,
  AMOUNT FLOAT,
  ORDER_DATE DATE
);

COPY INTO SALES_RAW
FROM @my_s3_stage/csv/
FILE_FORMAT = (TYPE = CSV, FIELD_OPTIONALLY_ENCLOSED_BY='"', SKIP_HEADER=1);
```  

✅ Data is now queryable and can be transformed into curated tables.  

---

## 8️⃣ Working with Semi-Structured Data (JSON, Parquet)  

**Example — Loading JSON**  

```sql
CREATE OR REPLACE TABLE SALES_JSON (RAW VARIANT);
```

**COPY INTO SALES_JSON**  

```sql
FROM @my_s3_stage/json/
FILE_FORMAT = (TYPE = JSON);
```

**Querying JSON**  

```sql
SELECT
  RAW:"orderId"::STRING AS ORDER_ID,
  RAW:"customer"::STRING AS CUSTOMER,
  RAW:"amount"::FLOAT AS AMOUNT
FROM SALES_JSON;
```

✅ Snowflake automatically flattens and infers schema dynamically.

**Example — Parquet File**  

```sql
CREATE OR REPLACE TABLE PARQUET_SALES USING TEMPLATE (
  SELECT ARRAY_AGG(OBJECT_CONSTRUCT(*))
  FROM TABLE(
    INFER_SCHEMA(
      LOCATION=>'@my_s3_stage/parquet/',
      FILE_FORMAT=>'(TYPE=PARQUET)'
    )
  )
);

COPY INTO PARQUET_SALES
FROM @my_s3_stage/parquet/
FILE_FORMAT = (TYPE=PARQUET);  
```

---

## 9️⃣ Working with Unstructured Data (Images, PDFs, Audio)

Snowflake supports unstructured objects stored in **internal** or **external stages**.

**Example — Uploading Image Files**  

```sql
PUT file://C:\images\logo.png @my_s3_stage/unstructured/auto_compress=false;
```

**Example — Register Metadata**  

```sql
CREATE OR REPLACE TABLE FILE_METADATA AS
SELECT RELATIVE_PATH, SIZE, LAST_MODIFIED
FROM DIRECTORY(@my_s3_stage/unstructured);
```

**Example — Access via Presigned URL**  

```sql
SELECT BUILD_STAGE_FILE_URL(@my_s3_stage, RELATIVE_PATH)
FROM FILE_METADATA;
```

✅ URLs can be integrated directly with **Streamlit apps or ML pipelines**.  

---  


## 🔟 Building a Unified View (Data Federation)  

You can combine structured, semi-structured, and unstructured data using views and Snowpark.

**Example — Unified Customer View** 

```sql
CREATE OR REPLACE VIEW V_CUSTOMER_UNIFIED AS
SELECT
  c.CUSTOMER_ID,
  c.NAME,
  j.RAW:"preferences":"category"::STRING AS CATEGORY,
  u.RELATIVE_PATH AS PROFILE_IMAGE
FROM CUSTOMERS c
JOIN SALES_JSON j ON c.CUSTOMER_ID = j.RAW:"customerId"::STRING
JOIN FILE_METADATA u ON c.CUSTOMER_ID = SPLIT_PART(u.RELATIVE_PATH, '/', 2);
```

✅ Enables **single-query analytics** across all data formats.  

---  

## 11. Governance, Security & Performance Optimization  


| Area                  | Best Practice                                                   |
| :-------------------- | :-------------------------------------------------------------- |
| **Security**          | Use Storage Integrations for secure access to cloud storage     |
| **Access Control**    | Apply Row-Level and Column-Level Security                       |
| **Performance**       | Use clustering and search optimization for semi-structured data |
| **Cost Optimization** | Auto-suspend warehouses and use materialized views              |
| **Compliance**        | Enable masking and auditing for sensitive attributes            |  

---  

## 12. Hands-On Project — Unified Retail Data Lakehouse  

**🏗️ Objective**

- Build a Lakehouse combining:
- Structured → Sales data
- Semi-structured → Customer JSON
- Unstructured → Product images  

**Steps**

**Create Stages**

```sql
CREATE STAGE retail_stage URL='s3://retail-zone/' STORAGE_INTEGRATION=retail_int;
```  

**Ingest Raw Data**  

```sql
COPY INTO SALES_RAW FROM @retail_stage/sales FILE_FORMAT=(TYPE=CSV,SKIP_HEADER=1);
COPY INTO CUSTOMERS_JSON FROM @retail_stage/customers FILE_FORMAT=(TYPE=JSON);
```  

**Register Image Files**  

```sql
CREATE OR REPLACE TABLE PRODUCT_IMAGES AS
SELECT * FROM DIRECTORY(@retail_stage/images);
```  

**Create Unified View**  

```sql
CREATE OR REPLACE VIEW RETAIL_UNIFIED AS
SELECT
  s.ORDER_ID,
  c.RAW:"customerName"::STRING AS CUSTOMER_NAME,
  s.AMOUNT,
  p.RELATIVE_PATH AS PRODUCT_IMAGE
FROM SALES_RAW s
JOIN CUSTOMERS_JSON c ON s.CUSTOMER_ID = c.RAW:"customerId"::STRING
JOIN PRODUCT_IMAGES p ON s.PRODUCT_ID = SPLIT_PART(p.RELATIVE_PATH, '/', 3);
```


✅ This gives a **complete Lakehouse view** combining all formats seamlessly.  

---


## 13. Best Practices  

| Category           | Recommendation                                    |
| :----------------- | :------------------------------------------------ |
| Storage            | Use external stages for large archives            |
| Schema Design      | Maintain RAW → CURATED → ANALYTICS zones          |
| Metadata           | Use DIRECTORY tables for unstructured assets      |
| Query Optimization | Flatten JSON early using views or transformations |
| Security           | Enable access control and data masking            |
| Cost               | Use transient tables for staging data             |  

---

## 14.Summary  

| Concept                       | Description                                      |
| :---------------------------- | :----------------------------------------------- |
| **Snowflake Lakehouse**       | Unified platform for all data types              |
| **VARIANT & External Tables** | Handle semi-structured and unstructured formats  |
| **Stages**                    | Enable seamless integration with S3/Azure/GCS    |
| **Snowpark**                  | Processing engine for ETL and ML                 |
| **Governance & Security**     | Built-in access control, masking, and encryption |  


---

## 🧠 Key Takeaways

- Snowflake natively supports **structured, semi-structured, and unstructured** data.  
- It serves as both a **Data Lake and Data Warehouse**, eliminating silos.  
- Using **external tables and stages**, you can integrate with cloud object stores.  
- Unified governance, performance, and cost efficiency make Snowflake a **true Data Lakehouse** platform.  
