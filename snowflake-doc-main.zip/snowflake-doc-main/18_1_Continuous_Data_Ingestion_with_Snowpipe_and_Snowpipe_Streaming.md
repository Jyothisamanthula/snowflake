# 📘 Chapter 18_1: Continuous Data Ingestion with Snowpipe and Snowpipe Streaming

Snowflake provides two major mechanisms for **continuous and near real-time data ingestion**:  

- **Snowpipe** — event-based, micro-batch ingestion from cloud storage  
- **Snowpipe Streaming** — low-latency streaming ingestion directly into Snowflake tables  

Both are critical for building modern, real-time data pipelines.  

---

## 1️⃣ Introduction to Snowpipe  

**💡 What is Snowpipe?**

**Snowpipe** is a **serverless, managed data ingestion service** that automatically loads data from files in cloud storage (S3, Azure Blob, GCS) into Snowflake tables **as soon as files arrive**.

It eliminates the need for manual `COPY INTO` commands by using **cloud event notifications** (e.g., AWS S3 event triggers) or **REST API calls** to signal new files.  

--- 

## 2️⃣ How Snowpipe Works

Snowpipe operates in three main stages:

**1.File Placement:** Data files (CSV, JSON, Parquet, etc.) are uploaded to a cloud storage location linked to Snowflake.  
**2.Event Notification:** Storage service sends an event to Snowflake when a new file arrives.  
**3.Automated Load:** Snowpipe picks up the event and loads data into a Snowflake table using the defined `COPY INTO` logic.  

**🔹 Snowpipe Architecture Diagram**  

```sql
Client → Uploads file → Cloud Storage (S3 / Azure Blob / GCS)
                   ↳ Event Notification → Snowflake Pipe
                                     ↳ COPY INTO → Target Table
```
---

## 3️⃣ Setting Up Snowpipe (Step-by-Step)  

**🧩 Step 1: Create a Storage Integration**  

**Example: AWS S3 Integration**  

```sql
CREATE STORAGE INTEGRATION MY_S3_INT
  TYPE = EXTERNAL_STAGE
  STORAGE_PROVIDER = S3
  ENABLED = TRUE
  STORAGE_AWS_ROLE_ARN = 'arn:aws:iam::123456789012:role/snowflake_access'
  STORAGE_ALLOWED_LOCATIONS = ('s3://my-bucket/data/');
```


**🧩 Step 2: Create an External Stage**

```sql
CREATE STAGE MY_S3_STAGE
  URL = 's3://my-bucket/data/'
  STORAGE_INTEGRATION = MY_S3_INT
  FILE_FORMAT = (TYPE = 'CSV' FIELD_DELIMITER = ',' SKIP_HEADER = 1);
```

**🧩 Step 3: Create a Target Table**  

```sql
CREATE TABLE SALES_RAW (
  ID INT,
  PRODUCT STRING,
  PRICE NUMBER,
  REGION STRING
);
```

**🧩 Step 4: Create a Snowpipe**  

```sql
CREATE PIPE SALES_PIPE
  AS COPY INTO SALES_RAW
  FROM @MY_S3_STAGE
  FILE_FORMAT = (TYPE='CSV' SKIP_HEADER=1)
  ON_ERROR = 'CONTINUE';
```

**🧩 Step 5: Enable Cloud Event Notification**  


Each cloud provider has a different mechanism:

- **AWS S3**: Configure S3 bucket notifications → SNS → SQS → Snowflake.  
- **Azure Blob**: Use **Event Grid** for triggers.  
- **GCS**: Use **Pub/Sub** events for new files.  

Once the notification is set up, Snowpipe loads data automatically when a file lands.  


**🧩 Step 6: Monitor Snowpipe Loads**  

```sql
SELECT * FROM SNOWPIPE_LOAD_HISTORY
WHERE PIPE_NAME = 'SALES_PIPE'
ORDER BY LOAD_START_TIME DESC;
```

Or use **Snowflake’s Web UI → Pipes** tab for real-time monitoring.  

---

## 4️⃣ Using REST API for Manual or External Triggering

In some workflows, you may prefer to trigger ingestion manually or from another system (like Airflow or Informatica).

**Example: REST API Request**  

```bash
curl -X POST \
  -H "Authorization: Snowflake Token" \
  -H "Content-Type: application/json" \
  -d '{ "files": ["data_2025_10_18.csv"] }' \
  "https://<account>.snowflakecomputing.com/v1/data/pipes/SALES_PIPE/insertFiles"
```

---

## 5️⃣ Snowpipe Pricing

You’re charged **per compute-second** used by Snowflake during ingestion.  
Since it’s **serverless,** no warehouse needs to be running, and you only pay for what you use. 

---

## 6️⃣ Snowpipe Limitations    

| Limitation     | Description                                                |
| -------------- | ---------------------------------------------------------- |
| File Size      | Up to ~5GB recommended per file                            |
| Load Frequency | Event-driven (not continuous streaming)                    |
| Latency        | Usually < 1 minute                                         |
| File Format    | Must use supported structured formats (CSV, JSON, Parquet) |  

---

# ⚡ Snowpipe Streaming — True Real-Time Ingestion  

## 1️⃣ What is Snowpipe Streaming?

**Snowpipe Streaming** is a **low-latency, continuous ingestion API** introduced by Snowflake.  

Unlike standard Snowpipe, it doesn’t rely on cloud file storage. Instead, it ingests **streaming data directly into Snowflake tables** using a client-side **Snowflake Ingest SDK**.  

---

## 2️⃣ Key Benefits

✅ **Ultra-low latency:** Milliseconds to seconds (vs minutes for Snowpipe).  
✅ **No cloud file staging required**.  
✅ **Supports streaming from Kafka, Spark, Flink, Debezium, etc.**  
✅ **Cost-efficient for continuous event ingestion.**    

---

## 3️⃣ Snowpipe Streaming Architecture  

```css
Source → Kafka/Flink → Snowflake Streaming API → Target Table
```

**Components:**

- **Streaming Client (Producer)**: Pushes records via SDK  
- **Snowflake Ingest Service**: Handles deduplication, buffering, and commit  
- **Target Table**: Automatically updated in real-time

---

## 4️⃣ Example: Using Snowpipe Streaming with Python

```python
from snowflake.snowpark import Session
from snowflake.snowpark.streaming import SnowpipeStreamingWriter

session = Session.builder.configs({
    "account": "my_account",
    "user": "my_user",
    "password": "my_password",
    "role": "SYSADMIN",
    "warehouse": "STREAM_WH",
    "database": "SALES_DB",
    "schema": "PUBLIC"
}).create()

# Define target table
table_name = "SALES_STREAM"

# Create writer
writer = SnowpipeStreamingWriter(session, table_name)

# Write streaming records
records = [
    {"ID": 101, "PRODUCT": "Laptop", "PRICE": 55000, "REGION": "APAC"},
    {"ID": 102, "PRODUCT": "Phone", "PRICE": 35000, "REGION": "US"}
]

writer.write_pandas(records)
writer.close()
```
---

## 5️⃣ Integration with Kafka

Snowflake offers a **Snowflake Kafka Connector** that pushes Kafka topics into Snowflake directly using the Snowpipe Streaming API.  

**Connector Example (Kafka Connect Configuration):**

```json
{
  "name": "snowflake-kafka-connector",
  "config": {
    "connector.class": "com.snowflake.kafka.connector.SnowflakeSinkConnector",
    "topics": "sales_topic",
    "snowflake.url.name": "my_account.snowflakecomputing.com",
    "snowflake.user.name": "MY_USER",
    "snowflake.private.key": "YOUR_PRIVATE_KEY",
    "snowflake.database.name": "SALES_DB",
    "snowflake.schema.name": "PUBLIC",
    "snowflake.table.name": "SALES_STREAM",
    "buffer.flush.time": "10",
    "buffer.count.records": "500"
  }
}
```
---

## 6️⃣ Monitoring Snowpipe Streaming

**Use Snowflake Account Usage Views**:

```sql
SELECT * FROM SNOWPIPE_STREAMING_LOAD_HISTORY
WHERE TABLE_NAME = 'SALES_STREAM'
ORDER BY LOAD_START_TIME DESC;
```
---

## 7️⃣ Choosing Between Snowpipe vs Snowpipe Streaming  

| Feature          | Snowpipe                            | Snowpipe Streaming                      |
| ---------------- | ----------------------------------- | --------------------------------------- |
| Ingestion Type   | File-based                          | Record-based (API-driven)               |
| Latency          | < 1 min                             | Few seconds                             |
| Storage Required | Cloud storage (S3, GCS, Azure Blob) | None                                    |
| Best For         | Batch + near real-time ingestion    | True streaming data (Kafka, Flink, IoT) |  

---


## 8️⃣ Best Practices

- For **micro-batches or event-driven files**, use **Snowpipe**.
- For **continuous real-time ingestion**, use **Snowpipe Streaming**.
- Use **Streams + Tasks** for downstream transformations after ingestion.
- Monitor ingestion health via **Account Usage views**.
- Apply **Dynamic Tables** for real-time transformation pipelines.

---


## 🧩 Mini Project: Real-Time Streaming Ingestion from Kafka to Snowflake

**Goal**: Stream `sales` data from a Kafka topic into Snowflake table in near real-time.  

**Steps:**

**1.** Create target table in Snowflake:  

```sql
CREATE TABLE SALES_STREAM (
  ID INT,
  PRODUCT STRING,
  PRICE NUMBER,
  REGION STRING
);
```  

**2.** Configure the **Snowflake Kafka Connector** (as above).  
**3.** Publish messages to Kafka topic `sales_topic`.  
**4.** Verify ingestion:  

```sql
SELECT * FROM SALES_STREAM ORDER BY ID DESC LIMIT 10;
```  

**5.** Optionally, create a **Dynamic Table** on top for aggregated real-time reporting.  


## ✅ Summary  

- **Snowpipe**: Micro-batch, event-driven ingestion from cloud files.  
- **Snowpipe Streaming**: Low-latency streaming ingestion via API or Kafka.  
- Both provide **scalable, serverless** ingestion options inside Snowflake’s architecture.

---

# 📘 Snowpipe Streaming — Complete Examples (Step-by-Step)

**Note:** Snowflake SDKs and connector versions evolve. The examples below use the current recommended patterns (Snowpark / Snowpipe Streaming API and the Snowflake Kafka Connector in `snowpipe_streaming` ingest mode). If a function name or import doesn't match your installed SDK, upgrade the SDK or check Snowflake docs for the exact package API.

## Part A — Preparation (common prerequisites)

**1.** **Snowflake account** with privileges to create databases, schemas, warehouses, tables, and integrations.  
**2.** **Admin role** (e.g., `ACCOUNTADMIN` or a role with equivalent privileges) for setup steps.  
**3.** For Kafka connector: a Kafka Connect cluster (Confluent Platform or open-source) and ability to install connectors.  
**4.** A **machine** with Python 3.8+ for the Python examples.  
**5.** Developer tools: `snowsql` (optional), `kafka` CLI or Python `kafka-python` for producing test messages.  

---

## Part B — Database & Table Setup (SQL)

Run these SQL statements in Snowsight or snowsql to prepare target objects.

```sql
-- 1) Create DB and schema
CREATE OR REPLACE DATABASE STREAMING_DB;
CREATE OR REPLACE SCHEMA STREAMING_DB.REALTIME;
USE DATABASE STREAMING_DB;
USE SCHEMA STREAMING_DB.REALTIME;

-- 2) Create the target table for streaming ingestion
CREATE OR REPLACE TABLE SALES_STREAM (
  TRANSACTION_ID STRING,
  PRODUCT         STRING,
  PRICE           NUMBER(10,2),
  REGION          STRING,
  EVENT_TIMESTAMP TIMESTAMP_NTZ
);

-- 3) (Optional) Create a small warehouse for ad-hoc queries / monitoring
CREATE OR REPLACE WAREHOUSE STREAM_WH
  WAREHOUSE_SIZE = 'XSMALL'
  AUTO_SUSPEND = 60
  AUTO_RESUME = TRUE;
```
---

## Part C — Security: Create a Snowflake User & Keypair (for Kafka Connector or programmatic auth)

Snowpipe Streaming connector and many clients use key pair authentication. Steps:  

**1.** On your local machine, create an RSA key pair (2048 or 4096 bits). Example with **openssl**:

```bash
# generate private key (PEM) - protect this file
openssl genpkey -algorithm RSA -out rsa_key.pem -pkeyopt rsa_keygen_bits:2048

# create public key (PEM)
openssl rsa -pubout -in rsa_key.pem -out rsa_key.pub
```


**2.** Create a Snowflake user and store the public key in Snowflake:

```sql
CREATE USER snowpipe_user
  PASSWORD = '' -- not used when using key pair
  DEFAULT_ROLE = 'SYSADMIN'
  DEFAULT_WAREHOUSE = STREAM_WH
  MUST_CHANGE_PASSWORD = FALSE;

-- If your public key is in PEM, remove header/footer and newlines when pasting
ALTER USER snowpipe_user
  SET RSA_PUBLIC_KEY = '<contents-of-rsa_key.pub-without-headers>';
```  

Keep the `rsa_key.pem` secure. Kafka connector or your Python client will use it to authenticate.  

---

## Part D — Method 1: Direct Python Snowpipe Streaming Example## 

Two approaches exist in Python depending on the libraries available. Below is a **Snowpark-style** streaming writer example (conceptual — adapt to your installed Snowflake library). If you have `snowflake-snowpark-python` with streaming support, use its streaming writer. If not, see the Kafka connector approach below.

**1. Install Python packages**

```bash
pip install "snowflake-connector-python" "snowflake-snowpark-python" kafka-python
```  

(If your environment provides a dedicated `snowpipe streaming` client package, install that following Snowflake docs. The example below uses a `SnowpipeStreamingWriter`-style class; if your SDK uses a different import path, substitute accordingly.)  

**2. Example Python script (producer → Snowpipe Streaming)**

Save as `stream_write_python.py`. Replace `account`, `user`, `private_key_path`, etc.

```python
import json
import time
from pathlib import Path
from snowflake.snowpark import Session

# NOTE: The actual streaming writer import may differ by SDK version.
# Example: from snowflake.snowpark.streaming import SnowpipeStreamingWriter
# If your version doesn't have this, consult Snowflake docs.

try:
    from snowflake.snowpark.streaming import SnowpipeStreamingWriter
except Exception:
    # fallback placeholder - actual SDK may differ
    SnowpipeStreamingWriter = None

# Load private key content (PEM) - used if SDK authenticates via private key
private_key_path = "/path/to/rsa_key.pem"
private_key = Path(private_key_path).read_bytes()

connection_parameters = {
    "account": "<your_account>.snowflakecomputing.com",
    "user": "snowpipe_user",
    "private_key": private_key,             # some SDKs accept bytes / pk
    "role": "SYSADMIN",
    "warehouse": "STREAM_WH",
    "database": "STREAMING_DB",
    "schema": "REALTIME",
}

# Create session
session = Session.builder.configs(connection_parameters).create()
print("Connected to Snowflake")

if SnowpipeStreamingWriter is None:
    raise SystemExit("Your installed Snowpark library does not expose a SnowpipeStreamingWriter. "
                     "Check Snowflake docs or use the Kafka connector example below.")

# Create the streaming writer
writer = SnowpipeStreamingWriter(session=session, table="SALES_STREAM")

# Send some example events in a loop
for i in range(5):
    rec = {
        "TRANSACTION_ID": f"TXN_{int(time.time())}_{i}",
        "PRODUCT": "Laptop" if i % 2 == 0 else "Phone",
        "PRICE": 75000 if i % 2 == 0 else 35000,
        "REGION": "APAC" if i % 2 == 0 else "US",
        "EVENT_TIMESTAMP": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    # The writer likely accepts dictionaries, DataFrames, or Pandas objects.
    writer.write([rec])   # write batch of 1 record
    print("Wrote:", rec)
    time.sleep(1)

# Close the writer to flush and commit
writer.close()
print("Finished streaming.")
```


**What happens:** `writer.write()` pushes records directly to Snowflake’s Snowpipe Streaming ingest service. Snowflake handles buffering, deduplication, and commit.  

If your SDK differs, the pattern remains: create a session/auth, instantiate a streaming writer for the table, and call `write()` with records. Consult your SDK docs for exact class/method names.  

---

## Part E — Method 2: Kafka → Snowflake Using Snowflake Kafka Connector (recommended for Kafka)

This is the most common and production-hardened approach when you already operate Kafka/Kafka Connect.  

**1. Install Snowflake Kafka Connector (Kafka Connect)**

If using Confluent Platform:

```bash
confluent-hub install snowflakeinc/snowflake-kafka-connector:latest
```

Or download the connector JAR and place it in Kafka Connect's plugin path.  


**2. Configure the connector (JSON)**

Create `snowflake-kafka-connector.json` with these contents. Replace placeholders.

```json
{
  "name": "snowflake-kafka-connector",
  "config": {
    "connector.class": "com.snowflake.kafka.connector.SnowflakeSinkConnector",
    "tasks.max": "1",
    "topics": "sales_topic",
    "snowflake.url.name": "<your_account>.snowflakecomputing.com",
    "snowflake.user.name": "snowpipe_user",
    "snowflake.private.key": "-----BEGIN PRIVATE KEY-----\\nMIIEv...\\n-----END PRIVATE KEY-----",
    "snowflake.database.name": "STREAMING_DB",
    "snowflake.schema.name": "REALTIME",
    "snowflake.table.name": "SALES_STREAM",
    "buffer.count.records": "100",
    "buffer.flush.time": "5",
    "buffer.size.bytes": "500000",
    "snowflake.ingest.mode": "snowpipe_streaming",
    "key.converter": "org.apache.kafka.connect.storage.StringConverter",
    "value.converter": "org.apache.kafka.connect.json.JsonConverter",
    "value.converter.schemas.enable": "false"
  }
}
```  

**Important fields explained:**

- `snowflake.private.key`: The RSA private key content (escaped newlines or base64). Some deployments use snowflake.private.key.path to reference a local private key file.  
- `snowflake.ingest.mode`: set to `"snowpipe_streaming"` — this instructs connector to use Snowpipe Streaming API.  
- `buffer.count.records` / `buffer.flush.time`: control buffering and commit latency. Lower values -> lower latency, but possibly higher overhead.  


**3. Deploy the connector**

POST the config to Kafka Connect REST API:

```bash
curl -X POST -H "Content-Type: application/json" \
 --data @snowflake-kafka-connector.json \
 http://localhost:8083/connectors
```  

Check status:

```bash
curl http://localhost:8083/connectors/snowflake-kafka-connector/status
```

**4. Produce messages to Kafka topic**

Use Kafka console producer or a Python script.

**Kafka CLI example:**

```bash
kafka-console-producer.sh --broker-list localhost:9092 --topic sales_topic
>{"TRANSACTION_ID":"TXN_1","PRODUCT":"Laptop","PRICE":75000,"REGION":"APAC","EVENT_TIMESTAMP":"2025-10-19 10:01:00"}
>{"TRANSACTION_ID":"TXN_2","PRODUCT":"Phone","PRICE":35000,"REGION":"US","EVENT_TIMESTAMP":"2025-10-19 10:01:10"}
```  

**Python producer (kafka-python):**

```python
from kafka import KafkaProducer
import json
producer = KafkaProducer(bootstrap_servers='localhost:9092',
                         value_serializer=lambda v: json.dumps(v).encode('utf-8'))

producer.send('sales_topic', {"TRANSACTION_ID":"TXN_1","PRODUCT":"Laptop","PRICE":75000,"REGION":"APAC","EVENT_TIMESTAMP":"2025-10-19 10:01:00"})
producer.flush()
```

**5. Verify ingestion in Snowflake**  

Within seconds, query Snowflake:

```sql
SELECT * FROM STREAMING_DB.REALTIME.SALES_STREAM
ORDER BY EVENT_TIMESTAMP DESC
LIMIT 20;
```  

You should see the produced records.  

---

## Part F — Monitoring & Diagnostics  

**1. Snowpipe Streaming Load History**  

```sql
SELECT *
FROM TABLE(INFORMATION_SCHEMA.SYNC_LOAD_HISTORY(RESULT_LIMIT=>100))
-- or use the provided SNOWPIPE_STREAMING_LOAD_HISTORY view if available
-- Some accounts expose SNOWPIPE_STREAMING_LOAD_HISTORY in ACCOUNT_USAGE
```  
    
Or:

```sql
SELECT *
FROM STREAMING_DB.INFORMATION_SCHEMA.LOAD_HISTORY
WHERE TABLE_NAME = 'SALES_STREAM'
ORDER BY LOAD_START_TIME DESC;
```

**2. Kafka Connector logs**

Check Kafka Connect worker logs to see connector status and any errors (authentication, mapping, etc.)  

**3. Snowflake Query History**  

Check `SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY` to inspect internal loads and any errors.  

---

## Part G — Best Practices & Tuning

- **Buffer settings**: For the Kafka connector, reduce `buffer.count.records` and `buffer.flush.time` for lower latency; but watch throughput and CPU. Typical starting values: `buffer.count.records=100`, `buffer.flush.time=5`.  
- **Idempotency / Deduplication**: Snowpipe Streaming supports deduplication features. If your producers may re-send messages, include a unique key (transaction id) and enable exactly-once semantics where possible.  
- **Schema evolution**: Use JSON value conversion (no schema) or manage schema changes carefully. For strongly typed tables, ensure Kafka payload matches table columns.  
- **Authentication**: Use private key auth for the connector. Keep private keys secure and rotate periodically.  
- **Monitoring**: Create Tasks that periodically check `SNOWPIPE_STREAMING_LOAD_HISTORY` and raise alerts if ingestion lag increases.  
- **Testing**: Start with small buffer sizes and a single connector task, then scale `tasks.max` as needed.

---

## Part H — Troubleshooting Common Issues
| Symptom                     | Likely Cause                                    | Action                                                                           |
| --------------------------- | ----------------------------------------------- | -------------------------------------------------------------------------------- |
| No rows appear in Snowflake | Connector misconfigured (wrong topic or auth)   | Check Kafka Connect logs, topic name, private key config                         |
| Authentication errors       | User public key not set or private key mismatch | Verify RSA public key in Snowflake user object and key used by connector         |
| High latency                | Large buffer settings or network issues         | Lower `buffer.count.records` and `buffer.flush.time`                             |
| Partial or malformed rows   | JSON parsing or converter issue                 | Use `value.converter.schemas.enable=false` for raw JSON; validate message format |
| Duplicate records           | Producer retries or connector reprocessing      | Use dedupe keys or idempotent producer logic                                     |


