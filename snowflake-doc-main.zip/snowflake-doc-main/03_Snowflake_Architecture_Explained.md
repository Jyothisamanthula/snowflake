# 🏗️ Chapter 3: Snowflake Architecture Explained

---

## 3.1 Overview

Snowflake’s architecture is **revolutionary** because it breaks away from the traditional *shared-disk* or *shared-nothing* models.  
It combines the best of both to achieve **elastic scalability**, **high performance**, and **true concurrency** — all without infrastructure management.

In this chapter, we’ll explore:

- The **core layers** of Snowflake’s architecture  
- How **compute and storage** are separated  
- How **metadata & services** are managed  
- The concept of **multi-cluster virtual warehouses**

---

## 3.2 Traditional Data Warehouse Architectures

Before Snowflake, there were two dominant models:

| Architecture | Description | Example Systems | Pros | Cons |
|---------------|--------------|-----------------|------|------|
| **Shared-Disk** | All nodes share the same storage | Oracle, Teradata | Centralized storage | Concurrency bottlenecks |
| **Shared-Nothing** | Each node has its own storage | Redshift, Hadoop | Parallel processing | Data replication, complexity |

🧩 Snowflake combines the best of both:
- Centralized **shared storage**
- Independent **compute clusters**
- Managed by a **cloud services layer**

---

## 3.3 Snowflake’s Three-Layer Architecture

Snowflake’s platform is built on **three primary layers**:

            ┌────────────────────────────┐
            │     Cloud Services Layer    │
            │  (Security, Metadata, SQL)  │
            └────────────┬───────────────┘
                         │
            ┌────────────┴──────────────┐
            │     Compute Layer          │
            │ (Virtual Warehouses)       │
            └────────────┬──────────────┘
                         │
            ┌────────────┴──────────────┐
            │       Storage Layer        │
            │ (Centralized Data Store)   │
            └────────────────────────────┘


Let’s explore each layer in detail.

---

## 3.4 Storage Layer

The **Storage Layer** is where Snowflake keeps all your data — whether structured, semi-structured, or unstructured.

### 🔹 Key Characteristics:
- Fully **managed by Snowflake**
- Stored in **compressed, columnar** format
- Automatically encrypted using **AES-256**
- Scales **infinitely** with your data volume
- Accessible from any compute cluster

### 📦 Data Flow:
When you run:
```sql
COPY INTO SALES_DB.PUBLIC.ORDERS
FROM @aws_stage FILE_FORMAT = (TYPE = CSV);
```

👉 Data is:

1.Encrypted

2.Compressed

3.Partitioned into micro-partitions (~50–500MB each)

4.Stored in cloud storage (S3, Azure Blob, or GCS)


⚙️ Micro-Partitions

Micro-partitions are the core storage optimization in Snowflake.

- Immutable, compressed columnar units

- Automatically organized by metadata

 - No need for manual partitioning

```sql
-- View metadata for micro-partitions
SELECT * FROM TABLE(INFORMATION_SCHEMA.TABLE_STORAGE_METRICS('SALES_DB.PUBLIC.ORDERS'));
```

🧠 Snowflake’s optimizer automatically prunes micro-partitions that are not relevant to a query.

## 3.5 Compute Layer (Virtual Warehouses)

The Compute Layer executes all SQL queries and transformations.

🔹 Virtual Warehouses:

A virtual warehouse is an independent compute cluster with:

- Dedicated CPU, memory, and cache

- Fully isolated performance

- Elastic scalability (resize anytime)

```sql
CREATE OR REPLACE WAREHOUSE WH_ANALYTICS
  WITH WAREHOUSE_SIZE = 'LARGE'
  AUTO_SUSPEND = 300
  AUTO_RESUME = TRUE;
```

Each warehouse can:

- Query the same data independently

- Be paused when idle (no charges)

- Scale out for concurrent workloads

🧩 Multi-Cluster Warehouses

When multiple users or processes run queries simultaneously, a multi-cluster warehouse ensures consistent performance.

```sql
ALTER WAREHOUSE WH_ANALYTICS
  SET MIN_CLUSTER_COUNT = 1
      MAX_CLUSTER_COUNT = 4
      SCALING_POLICY = 'ECONOMY';
```


🌀 How it works:

- When concurrency increases → more clusters spin up

- When load drops → clusters automatically shut down

✅ No manual scaling needed — Snowflake manages it intelligently.

🧮 Warehouse Caching

Snowflake maintains multiple levels of caching:

- Result Cache: Stores query results for 24 hours

- Local Disk Cache: Stores micro-partitions on warehouse SSD

- Metadata Cache: Managed by the services layer

```sql
-- Re-run a query within 24 hours to use result cache
SELECT COUNT(*) FROM SALES_DB.PUBLIC.ORDERS;
```

💡 If data hasn’t changed, Snowflake instantly serves cached results.

## 3.6 Cloud Services Layer

The **Cloud Services Layer** is the *brain* of Snowflake.  
It manages **authentication**, **metadata**, **optimization**, and **orchestration**.

🔹 **Key Responsibilities:**

| **Function** | **Description** |
|---------------|-----------------|
| **Authentication & Access Control** | Role-based permissions, MFA, SSO |
| **Metadata Management** | Stores table definitions, statistics, lineage |
| **Query Parsing & Optimization** | SQL compilation, execution plan generation |
| **Infrastructure Management** | Auto-suspend, scaling, resource monitoring |
| **Security Services** | Encryption key management, network policies |

**Example – View active roles and privileges:**

```sql
SHOW GRANTS TO USER VENKAT;
```
📊 This layer ensures all compute nodes work seamlessly on shared data.


## 3.7 Shared Data Architecture

Snowflake’s innovation lies in its **Shared Data, Multi-Cluster Compute** model.

| **Layer** | **Shared?** | **Independent?** |
|------------|-------------|------------------|
| **Storage** | ✅ Shared | ❌ |
| **Compute** | ❌ | ✅ |
| **Cloud Services** | ✅ | ❌ |

This means:

- All warehouses can access the same data concurrently

- Compute clusters are independent, ensuring no resource contention

- Metadata and optimization are centrally managed

```sql
-- Example: Two teams running different workloads
USE WAREHOUSE WH_ETL; -- For data loading
COPY INTO ORDERS FROM @stage;

USE WAREHOUSE WH_ANALYTICS; -- For analytics
SELECT REGION, SUM(AMOUNT) FROM ORDERS GROUP BY REGION;
```


💡 Both workloads run in parallel without slowing each other down.

---
## 3.8 Metadata & Cloud Services Example

Snowflake automatically tracks metadata about every table, file, and partition.

```sql
SELECT 
  TABLE_NAME,
  ROW_COUNT,
  BYTES,
  LAST_ALTERED
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_SCHEMA = 'PUBLIC';
```

Metadata enables:

- Query pruning

- Statistics-based optimization

- Data lineage tracking

- Faster performance across sessions
---
## 3.9 Example: Query Lifecycle in Snowflake

Let’s trace how a query flows through Snowflake’s architecture:

```sql
User → Cloud Services → Compute → Storage → Cloud Services → Result
```
**Step-by-Step:**

**1.Authentication:** User logs in via MFA/SSO

**2.Parsing:** SQL query parsed by Cloud Services

**3.Optimization:** Execution plan created

**4.Execution:** Warehouse retrieves data from Storage

**5.Caching:** Results stored for future queries

**6.Response:** Final data returned to the user

```sql
EXPLAIN SELECT REGION, SUM(SALES) FROM ORDERS GROUP BY REGION;
```

🧠 Snowflake automatically optimizes join orders, clustering, and partition pruning.

---
## 3.10 Benefits of Snowflake Architecture
| Benefit             | Description                                 |
| ------------------- | ------------------------------------------- |
| **Elastic Scaling** | Independently scale compute and storage     |
| **Concurrency**     | Multi-cluster design removes bottlenecks    |
| **Simplicity**      | No tuning or indexing required              |
| **Resilience**      | Data automatically replicated and backed up |
| **Performance**     | Smart caching and micro-partition pruning   |
| **Security**        | Encryption and access control at all layers |
---
## 3.11 Summary

Snowflake’s architecture is the foundation of its success.
It delivers:

- Separation of compute and storage

- Automatic scalability

- Centralized metadata and services

- Zero maintenance and high concurrency

**Snowflake isn’t just a cloud data warehouse** — it’s a data platform engineered for the modern enterprise.
