# 📘 Chapter 18: Integration with DBT, Airflow, or Other Tools

This chapter explains how to integrate Snowflake with modern data engineering tools such as DBT, Apache Airflow, and other orchestration or automation frameworks.
You’ll also build a hands-on example of orchestrating a Snowflake pipeline using Airflow and DBT.

## 📖 Table of Contents

**1.** Overview of Modern Data Orchestration  
**2.** Integrating Snowflake with DBT  
  - DBT Project Setup  
  - DBT Models, Seeds, and Sources  
  - DBT with Snowflake Example
    
**3.** Integrating Snowflake with Apache Airflow  
  - Airflow Connection Setup  
  - DAG for Snowflake ELT
    
**4.** Other Integration Options (Informatica, Azure Data Factory, etc.)  
**5.** Hands-On Mini Project: Orchestrating a Snowflake Pipeline with Airflow + DBT
**6.** Best Practices for Orchestration and Monitoring

---


## 1️⃣ Overview of Modern Data Orchestration

Modern data workflows depend on **automation**, **version control**, and collaboration between teams.
Snowflake seamlessly integrates with major orchestration tools to manage pipelines efficiently.  

| Tool                         | Purpose                   | Integration Method                             |
| ---------------------------- | ------------------------- | ---------------------------------------------- |
| **DBT (Data Build Tool)**    | SQL-based transformations | `snowflake-connector-python`, Jinja templating |
| **Apache Airflow**           | Workflow orchestration    | Airflow’s `SnowflakeOperator`                  |
| **Informatica / Matillion**  | ETL/ELT automation        | Native Snowflake connectors                    |
| **Azure Data Factory (ADF)** | Cloud data movement       | Snowflake linked service                       |
| **AWS Glue**                 | Data catalog & ETL        | Snowflake JDBC connector                       |  

---


## 2️⃣ Integrating Snowflake with DBT

DBT (Data Build Tool) focuses on **transformation** — it lets you define models using **SQL** and **Jinja templates**, automatically manage **dependencies**, and store transformations as code.

**⚙️ DBT Project Setup for Snowflake**

**1.Install DBT for Snowflake**

```bash
pip install dbt-snowflake
```

**2.Initialize a DBT Project**

```bash
dbt init snowflake_project
cd snowflake_project
```

**3.Configure** `profiles.yml`

```yaml
snowflake_project:
  target: dev
  outputs:
    dev:
      type: snowflake
      account: xy12345.ap-southeast-1
      user: Venkat
      password: "********"
      role: DEVELOPER
      database: ANALYTICS_DB
      warehouse: COMPUTE_WH
      schema: PUBLIC
      threads: 4
      client_session_keep_alive: False
```
---

**🧱 Example DBT Model**

Create a model file:` models/sales_summary.sql`

```sql
SELECT
    product_name,
    SUM(quantity * price) AS total_sales,
    COUNT(DISTINCT order_id) AS unique_orders
FROM {{ ref('raw_sales_data') }}
GROUP BY product_name;
```

Run the model:

```bash
dbt run
```

View logs:

```bash
dbt run --debug
```

Test transformations:

```bash
dbt test
```

Generate documentation:

```bash
dbt docs generate
dbt docs serve
```
---  

## 3️⃣ Integrating Snowflake with Apache Airflow

Airflow allows you to **schedule** and **orchestrate** workflows using Python DAGs.
The **SnowflakeOperator** lets you execute SQL scripts directly from Airflow.

**🛠️ Airflow Setup**

**1.Install Airflow with Snowflake support**

```bash
pip install apache-airflow-providers-snowflake
```

**2.Create Snowflake Connection**

- Go to **Airflow UI → Admin → Connections**
- Add connection ID: `snowflake_conn`
- Type: **Snowflake**
- Fill in credentials:

```vbnet
Account: xy12345.ap-southeast-1
User: Venkat
Password: ********
Database: ANALYTICS_DB
Schema: PUBLIC
Warehouse: COMPUTE_WH
Role: SYSADMIN
```


**🧩 Example Airflow DAG for Snowflake ELT**


`dags/snowflake_pipeline_dag.py`

```python
from airflow import DAG
from airflow.providers.snowflake.operators.snowflake import SnowflakeOperator
from datetime import datetime, timedelta

default_args = {
    'owner': 'venkat',
    'depends_on_past': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    'snowflake_elt_pipeline',
    default_args=default_args,
    description='Snowflake ELT pipeline using Airflow',
    schedule_interval='@hourly',
    start_date=datetime(2025, 1, 1),
    catchup=False,
) as dag:

    load_raw_data = SnowflakeOperator(
        task_id='load_raw_data',
        snowflake_conn_id='snowflake_conn',
        sql="""
            COPY INTO raw_sales_data
            FROM @s3_stage
            FILE_FORMAT = (TYPE = CSV SKIP_HEADER=1);
        """
    )

    transform_sales = SnowflakeOperator(
        task_id='transform_sales',
        snowflake_conn_id='snowflake_conn',
        sql="""
            MERGE INTO sales_summary AS tgt
            USING (
              SELECT product_name, SUM(quantity*price) AS total_sales
              FROM raw_sales_data
              GROUP BY product_name
            ) AS src
            ON tgt.product_name = src.product_name
            WHEN MATCHED THEN UPDATE SET tgt.total_sales = src.total_sales
            WHEN NOT MATCHED THEN INSERT (product_name, total_sales)
            VALUES (src.product_name, src.total_sales);
        """
    )

    load_raw_data >> transform_sales
```

✅ This DAG runs hourly and keeps your Snowflake analytics table refreshed.  

---


## 4️⃣ Other Integration Options  

| Tool                         | Description                                                 |
| ---------------------------- | ----------------------------------------------------------- |
| **Informatica Cloud**        | Provides direct Snowflake connectors for ETL pipelines.     |
| **Matillion ETL**            | Visual pipeline designer with native Snowflake integration. |
| **Azure Data Factory (ADF)** | Supports Snowflake as sink/source via Linked Service.       |
| **AWS Glue**                 | Use JDBC driver for Snowflake; integrate with AWS catalog.  |  

---

## 5️⃣ Hands-On Mini Project: Airflow + DBT Pipeline

**🎯 Objective**

Automate a daily ELT process:

**1.** Ingest CSV data from **S3 → Snowflake (Raw Table)**.
**2.** Run **DBT transformations** on the raw data.
**3.** Refresh analytics models automatically.

**🔧 Project Components  **

| Component     | Description                                  |
| ------------- | -------------------------------------------- |
| **S3**        | Stores raw sales CSVs                        |
| **Airflow**   | Orchestrates data load + DBT model execution |
| **DBT**       | Runs SQL transformations in Snowflake        |
| **Snowflake** | Stores all data (raw + transformed)          |  


**📜 Airflow DAG**

```python
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.providers.snowflake.operators.snowflake import SnowflakeOperator
from datetime import datetime

with DAG(
    'snowflake_dbt_elt_pipeline',
    schedule_interval='@daily',
    start_date=datetime(2025, 1, 1),
    catchup=False,
) as dag:

    load_raw_data = SnowflakeOperator(
        task_id='load_raw_data',
        snowflake_conn_id='snowflake_conn',
        sql="COPY INTO raw_sales_data FROM @s3_stage FILE_FORMAT = (TYPE = CSV SKIP_HEADER=1);"
    )

    run_dbt_models = BashOperator(
        task_id='run_dbt_models',
        bash_command='cd /opt/airflow/dbt/snowflake_project && dbt run'
    )

    load_raw_data >> run_dbt_models
```
---

## 6️⃣ Best Practices for Orchestration and Monitoring

✅ Use **Airflow Sensors** to check data arrival in S3 before running jobs.  
✅ Keep **DBT logs** and **run artifacts** in a monitored S3 bucket.  
✅ Use **Airflow XCom** for data dependency passing.  
✅ Implement **email/slack** alerts for task failures.  
✅ Separate **staging**, **transform**, and **analytics** schemas.  

---

**🧠 Summary**

| Concept         | Key Takeaway                                            |
| --------------- | ------------------------------------------------------- |
| **DBT**         | SQL-based transformation tool integrated with Snowflake |
| **Airflow**     | Orchestrates ELT workflows with SnowflakeOperator       |
| **Integration** | Combine DBT + Airflow for production-grade pipelines    |
| **Automation**  | Enables continuous, reliable data refresh               |




