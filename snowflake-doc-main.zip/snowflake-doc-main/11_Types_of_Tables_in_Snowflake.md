# Chapter 11: Types of Tables in Snowflake

Snowflake provides a flexible and powerful set of table types to manage a variety of data storage, retention, and performance needs.
From permanent transactional tables to external tables that reference cloud storage data, each type serves a distinct purpose in modern data architectures.

## 11.1 Overview

In Snowflake, a table is the fundamental structure used to store data in structured or semi-structured form.
The table type determines:
- Where data is stored  
- How long data persists  
- Who can access it  
- Whether it participates in features like Time Travel or Fail-safe

---
## 11.2 Permanent Tables

Permanent tables are the default type in Snowflake and are used for production and long-term storage.    

| **Feature**      | **Description**                                         |
| ---------------- | ------------------------------------------------------- |
| Data Persistence | Fully persisted; protected by Time Travel and Fail-safe |
| Use Case         | Core business data, dimensional models, facts           |
| Storage Cost     | Standard Snowflake storage                              |
| Time Travel      | Up to 90 days (depending on edition)                    |
| Fail-safe        | Enabled (7 days after Time Travel period)               |  

Example:
```sql
CREATE OR REPLACE TABLE SALES (
    SALE_ID NUMBER,
    CUSTOMER_ID NUMBER,
    AMOUNT NUMBER(10,2),
    SALE_DATE DATE
);
```

✅ Best for: Production workloads, reporting tables, slowly changing dimensions (SCD), etc.

---  

## 11.3 Temporary Tables

**Temporary** tables exist only within the session where they are created.
Once the session ends, the table (and its data) are automatically dropped.   

| **Feature** | **Description**                  |
| ----------- | -------------------------------- |
| Lifetime    | Until session ends               |
| Time Travel | Supported (1 day maximum)        |
| Fail-safe   | Not supported                    |
| Storage     | Internal, per-user session basis |  

Example:
```sql
CREATE TEMPORARY TABLE TEMP_SALES AS
SELECT * FROM SALES WHERE SALE_DATE = CURRENT_DATE();
```

✅ Use Case: Intermediate transformations, staging during ETL, scratchpad analytics.

---  

## 11.4 Transient Tables

**Transient** tables are designed for data that needs to persist across sessions but doesn’t need Fail-safe protection.  


| **Feature**  | **Description**                |
| ------------ | ------------------------------ |
| Lifetime     | Persistent across sessions     |
| Time Travel  | Supported (1 day by default)   |
| Fail-safe    | Disabled                       |
| Storage Cost | Lower due to no Fail-safe copy |  

Example:
```sql
CREATE TRANSIENT TABLE STG_SALES AS
SELECT * FROM RAW_SALES;
```

✅ Use Case: Staging environments, data pipelines, intermediate ETL layers.

---  

## 11.5 External Tables

**External tables** allow Snowflake to query data directly from cloud storage (e.g., AWS S3, Azure Blob, or Google Cloud Storage) without loading it into Snowflake storage.  

| **Feature** | **Description**                              |
| ----------- | -------------------------------------------- |
| Storage     | External (S3, Blob, GCS)                     |
| Queryable   | Yes, via metadata & external file references |
| Updatable   | No — read-only                               |
| Time Travel | Not supported                                |
| Use Case    | Querying data lakes or historical raw data   |  

Example:
```sql
CREATE OR REPLACE EXTERNAL TABLE EXT_SALES (
    sale_id NUMBER,
    region STRING,
    amount NUMBER,
    sale_date DATE
)
WITH LOCATION = @my_s3_stage/sales_data/
FILE_FORMAT = (TYPE = 'CSV' FIELD_OPTIONALLY_ENCLOSED_BY='"')
AUTO_REFRESH = TRUE;
```

✅ Use Case: Querying data in a data lake, building data mesh systems, or integrating with ETL pipelines that stage files in cloud storage.  

---  

## 11.6 Hybrid Tables (Snowflake’s Transactional Table Type)

**Hybrid tables** combine OLTP-style low-latency operations with OLAP analytical capabilities.
They use row-based storage optimized for real-time transactions — ideal for operational workloads.  

| **Feature**       | **Description**                                            |
| ----------------- | ---------------------------------------------------------- |
| Architecture      | Mix of transactional (row-based) and analytical (columnar) |
| Use Case          | Real-time apps, IoT, microservices, mixed workloads        |
| Time Travel       | Supported                                                  |
| Fail-safe         | Supported                                                  |
| Supported Actions | INSERT, UPDATE, DELETE with transactional consistency      |  

Example:
```sql
CREATE HYBRID TABLE ORDER_EVENTS (
    order_id NUMBER,
    event_type STRING,
    event_timestamp TIMESTAMP_LTZ
);

INSERT INTO ORDER_EVENTS VALUES (1001, 'ORDER_PLACED', CURRENT_TIMESTAMP());
```

✅ Use Case: Use Hybrid Tables when you need fast DML, event-driven data ingestion, or real-time updates.  

---  

## 11.7 Apache Iceberg™ Tables

- Snowflake supports the Apache Iceberg open table format, enabling interoperability with external compute engines like Spark, Flink, and Presto.  

| **Feature** | **Description**                       |
| ----------- | ------------------------------------- |
| Format      | Apache Iceberg (open-source)          |
| Storage     | External cloud storage                |
| Metadata    | Stored in Iceberg manifest files      |
| Mutability  | Supports DML (INSERT, UPDATE, DELETE) |
| Use Case    | Multi-engine data lakehouse systems   |  

Example:
```sql
CREATE ICEBERG TABLE MY_ICEBERG_SALES
CATALOG = 'SNOWFLAKE'
EXTERNAL_VOLUME = 's3_volume'
BASE_LOCATION = 's3://my-bucket/iceberg_sales'
AS SELECT * FROM SALES;
```

✅ Use Case: Building data lakehouses where data can be shared across different compute engines.

---  

## 11.8 Dynamic Tables

**Dynamic Tables** automate ELT data pipelines using continuous refresh logic.
They simplify maintaining materialized results without manually scheduling refreshes.  

| **Feature**   | **Description**                              |
| ------------- | -------------------------------------------- |
| Functionality | Automatically refreshes based on defined lag |
| Refresh Lag   | Controlled via `TARGET_LAG` parameter        |
| Use Case      | Automating incremental transformations       |
| Storage       | Internal Snowflake                           |
| Dependencies  | Tracks upstream table changes automatically  |  

Example:
```sql
CREATE OR REPLACE DYNAMIC TABLE SALES_AGG
LAG = '5 MINUTES'
WAREHOUSE = 'COMPUTE_WH'
AS
SELECT region, SUM(amount) AS total_sales
FROM SALES
GROUP BY region;
```

✅ Use Case: Streamlined real-time dashboards, incremental data marts, or data pipelines that auto-refresh.  

---  

## 11.9 Comparison of Table Types  

| **Table Type** | **Storage**   | **Persistence** | **Time Travel**   | **Fail-safe** | **Modifiable**     | **Use Case**                 |
| -------------- | ------------- | --------------- | ----------------- | ------------- | ------------------ | ---------------------------- |
| **Permanent**  | Internal      | Permanent       | ✅ (Up to 90 days) | ✅             | ✅                  | Core production data         |
| **Temporary**  | Internal      | Session only    | ✅ (1 day)         | ❌             | ✅                  | Scratch or testing           |
| **Transient**  | Internal      | Until dropped   | ✅ (1 day default) | ❌             | ✅                  | Staging or intermediate data |
| **External**   | Cloud storage | External        | ❌                 | ❌             | ❌ (Read-only)      | Data lakes integration       |
| **Hybrid**     | Internal      | Permanent       | ✅                 | ✅             | ✅                  | Real-time OLTP + analytics   |
| **Iceberg**    | External      | Permanent       | ✅                 | ❌             | ✅                  | Open data lakehouse          |
| **Dynamic**    | Internal      | Permanent       | ✅                 | ✅             | ✅ (auto-refreshed) | Automated pipelines          |  

---

## 11.10 Best Practices

✅ **Permanent tables** for reliable production data.  
✅ **Transient tables** for intermediate transformations (no Fail-safe = cost savings).  
✅ **Temporary tables** for user/session-level scratch work.  
✅ **External tables** when querying directly from data lakes (no copy needed).  
✅ **Hybrid tables** for operational workloads with fast DML.  
✅ **Dynamic tables** to replace manual ETL refreshes.  
✅ **Iceberg tables** for hybrid cloud and multi-engine architectures.   

---

## 11.11 Summary

Snowflake’s broad spectrum of table types gives data engineers complete flexibility to:

- Store data securely and cost-effectively  
- Query both on-prem and cloud-stored data seamlessly  
- Support real-time, batch, and open data lake scenarios  

Whether you're building a data warehouse, data lake, or data mesh, Snowflake provides the right table type for every use case.

 


 

