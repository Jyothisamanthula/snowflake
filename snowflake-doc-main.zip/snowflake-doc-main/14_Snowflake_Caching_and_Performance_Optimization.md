# Chapter 14: Snowflake Caching and Performance Optimization

## 14.1 Introduction

Performance is one of Snowflake’s strongest advantages.  
Unlike traditional databases, Snowflake automatically manages compute scaling, query optimization, and caching.  
However, understanding these caching mechanisms empowers you to design faster, more efficient, and cost-effective workloads.

In this chapter, we’ll explore:

- Snowflake’s caching architecture and layers  
- How query result reuse works  
- Performance tuning techniques  
- Monitoring and cost optimization best practices  

---

## 14.2 Snowflake Caching Architecture

Snowflake employs a **multi-layer caching architecture** that improves query performance and reduces compute cost.

| Cache Type | Location | Purpose | Persistence |
|-------------|-----------|----------|--------------|
| **Result Cache** | Cloud Services Layer | Stores final query results for reuse | 24 hours |
| **Metadata Cache** | Cloud Services Layer | Stores table metadata, partition info, and statistics | Persistent |
| **Warehouse (Local Disk) Cache** | Virtual Warehouse (Compute Layer) | Stores recently accessed data blocks from remote storage | Temporary (lifetime of warehouse) |

Each layer contributes differently to performance:

1. **Result Cache** – Reuses full query results across identical queries.  
2. **Metadata Cache** – Speeds up query planning by allowing partition pruning.  
3. **Warehouse Cache** – Reduces latency for repeated scans of the same data.

---

## 14.3 Result Cache

Snowflake automatically stores the **final result** of every successful query for **24 hours**.  
If an identical query (same text, parameters, and role) is re-executed before expiry, Snowflake retrieves the result instantly from cache — no warehouse compute required.

### Key Properties

- **Lifetime:** 24 hours  
- **Scope:** Shared across users with the same access privileges  
- **Cost:** Zero compute credits (warehouse doesn’t start)  
- **Invalidated when:**
  - Underlying data changes (INSERT, UPDATE, DELETE, TRUNCATE)  
  - Dependent objects (views, functions, schemas) change  
  - Query executed by a different role with different access  

### Example

```sql
-- First run (result computed and cached)
SELECT COUNT(*) FROM SALES WHERE REGION = 'APAC';

-- Second run (within 24 hours, identical query)
SELECT COUNT(*) FROM SALES WHERE REGION = 'APAC';
-- ✅ Uses Result Cache: returns instantly without warehouse usage
```
---
## 14.4 Metadata Cache

The **metadata cache** stores schema-level and partition-level information, including:

- Column statistics  
- Micro-partition boundaries  
- File listings (for external tables)  
- Clustering and pruning metadata
  
This cache allows Snowflake’s optimizer to **skip scanning irrelevant micro-partitions**, improving query performance.

**Example: Partition Pruning**
```sql
SELECT *
FROM SALES
WHERE ORDER_DATE = '2024-12-31';
```

If `ORDER_DATE` is part of the clustering key, Snowflake uses the metadata cache to prune unnecessary partitions, minimizing I/O and improving execution time.

Metadata caching is always active and cannot be disabled.

---
## 14.5 Warehouse (Local Disk) Cache

Each **Virtual Warehouse** maintains its own **local SSD cache** to temporarily store data retrieved from remote cloud storage (Amazon S3, Azure Blob, or Google Cloud Storage).

**Behavior**

- Reuses cached data for subsequent queries accessing the same data.  
- Cleared when:  
  - Warehouse is suspended, resized, or restarted.  
- Operates at the compute layer; improves performance for repeated queries within the same session.  

**Example**
```sql

-- First query: reads data from remote storage
SELECT COUNT(*) FROM SALES WHERE REGION = 'EUROPE';

-- Second query: same filter, same warehouse session
SELECT SUM(REVENUE) FROM SALES WHERE REGION = 'EUROPE';
-- ✅ Likely uses local cache for faster performance
```
---

## 14.6 Cache Reuse Scenarios  

| Scenario                          | Result Cache | Warehouse Cache | Notes                                   |
| --------------------------------- | ------------ | --------------- | --------------------------------------- |
| Identical query rerun             | ✅            | ❌               | Uses Result Cache (no compute cost)     |
| Similar query (different filters) | ❌            | ✅               | Warehouse Cache may help                |
| Warehouse suspended/resumed       | ❌            | ❌               | Cache cleared                           |
| Underlying data modified          | ❌            | ✅ (partially)   | Metadata reused, data cache invalidated |  

---
## 14.7 Query Profile and Performance Analysis

Snowflake’s Query Profile provides a graphical representation of query execution to help identify bottlenecks and cache utilization.

How to Access Query Profile

In the Snowflake Web UI:

```graphql
History → Query → Query Profile

```

Or programmatically via SQL:

```sql
SELECT *
FROM TABLE(INFORMATION_SCHEMA.QUERY_HISTORY())
ORDER BY START_TIME DESC
LIMIT 10;
```

**Key Sections in Query Profile**

| Section            | Description                                 |
| ------------------ | ------------------------------------------- |
| Execution Steps    | Displays operations (scan, join, aggregate) |
| Bytes Scanned      | Shows total data read                       |
| Partitions Scanned | Indicates pruning efficiency                |
| Time Breakdown     | Highlights performance bottlenecks          |  

---

## 14.8 Query Optimization Techniques

Below are practical strategies to enhance query performance and leverage caching effectively.

**1. Use Selective Queries**

Avoid `SELECT *`. Query only necessary columns.

```sql
SELECT CUSTOMER_ID, REVENUE FROM SALES;
```
**2. Filter Early**

Apply filters as early as possible.

```sql
-- Good
SELECT * FROM SALES WHERE REGION = 'ASIA';

-- Bad
SELECT * FROM (SELECT * FROM SALES) WHERE REGION = 'ASIA';
```

**3. Leverage Clustering Keys**

Clustering improves micro-partition organization and pruning efficiency.

```sql
ALTER TABLE SALES CLUSTER BY (REGION, ORDER_DATE);
```
**4. Use Materialized Views**

Precompute results for recurring aggregations.

```sql
CREATE MATERIALIZED VIEW MV_SALES_REGION AS
SELECT REGION, SUM(REVENUE) AS TOTAL_REVENUE
FROM SALES
GROUP BY REGION;
```

**5. Choose Appropriate Warehouse Size**

Balance speed and cost.

```sql
ALTER WAREHOUSE ANALYTICS_WH SET AUTO_SUSPEND = 60;  -- Suspend after 60s inactivity
```

- **Smaller warehouses** → cost-efficient for light workloads

- **Larger warehouses** → faster for heavy analytical tasks

**6. Use CTEs (WITH Clauses) Wisely**

CTEs reduce redundancy but can slow down queries if overused or nested excessively.

**7. Avoid Functions on Filter Columns**

Functions disable pruning. Use raw columns whenever possible.

```sql
-- Bad
SELECT * FROM SALES WHERE TO_DATE(SALE_DATE) = '2025-01-01';

-- Good
SELECT * FROM SALES WHERE SALE_DATE = '2025-01-01';
```

**8. Use Temporary or Transient Tables for Intermediate Results**

Avoids unnecessary writes to permanent storage and benefits from caching.

```sql
CREATE TEMPORARY TABLE TMP_ANALYSIS AS
SELECT * FROM SALES WHERE REGION = 'EAST';
```
---
## 14.9 Monitoring and Visibility

**Identify Long-Running Queries**
```sql
SELECT 
  QUERY_ID, USER_NAME, WAREHOUSE_NAME, TOTAL_ELAPSED_TIME
FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
WHERE TOTAL_ELAPSED_TIME > 60000
ORDER BY TOTAL_ELAPSED_TIME DESC;
```

**Analyze Warehouse Utilization**
```sql
SELECT 
  WAREHOUSE_NAME,
  AVG(CREDITS_USED) AS AVG_CREDITS,
  COUNT(*) AS QUERY_COUNT
FROM SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY
GROUP BY WAREHOUSE_NAME;
```

**Check Cache Usage in UI**

In the Snowflake Web UI:

```graphql
Query History → Cache Used
```
---
## 14.10 Real-World Example: BI Dashboard Optimization

**Scenario:**
A BI tool executes 50 identical dashboard queries every hour.  
| Mode              | Behavior                                  | Cost               | Performance       |
| ----------------- | ----------------------------------------- | ------------------ | ----------------- |
| Without Caching   | Each query triggers warehouse startup     | High               | Slower            |
| With Result Cache | Only first query runs; others reuse cache | 90% cost reduction | Faster dashboards |  

**Outcome:**
Dashboards load in seconds, and warehouse costs drop dramatically.  
---

## 14.11 Cache Expiry and Invalidation Rules 

| Cache Type          | Lifetime               | Invalidated When        |
| ------------------- | ---------------------- | ----------------------- |
| **Result Cache**    | 24 hours               | Table/view/role changes |
| **Warehouse Cache** | While warehouse active | Suspend or resize       |
| **Metadata Cache**  | Persistent             | Schema or DDL changes   |  

---

## 14.12 Cost Optimization Tips    

| Area             | Best Practice                                         |
| ---------------- | ----------------------------------------------------- |
| **Warehouses**   | Suspend when idle; use auto-suspend                   |
| **Caching**      | Reuse result cache; avoid unnecessary restarts        |
| **Query Design** | Use pruning and selective filters                     |
| **Clustering**   | Apply clustering on large, frequently filtered tables |
| **Monitoring**   | Use Resource Monitors for warehouse usage alerts      |  
---

## 14.13 Summary

Caching is central to **Snowflake’s performance and cost efficiency**.
By understanding caching layers and combining them with smart query design, you can achieve optimal performance with minimal compute cost.

Key Takeaways

- **Result Cache**: Reuses query results for 24 hours with zero compute cost.  
- **Metadata Cache**: Enables micro-partition pruning and efficient optimization.  
- **Warehouse Cache**: Accelerates repeated queries within active warehouses.  
- **Query Profile**: Helps analyze execution and identify bottlenecks.  
- **Cost Optimization**: Balance performance and credit usage through smart caching and warehouse management.  

Mastering caching and performance tuning is a crucial step toward becoming an advanced Snowflake Data Engineer.


