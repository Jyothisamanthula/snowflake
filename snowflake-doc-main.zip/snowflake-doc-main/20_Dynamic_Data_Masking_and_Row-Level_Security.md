# 📘 Chapter 20: Dynamic Data Masking and Row-Level Security

## 🎯 Chapter Overview

Snowflake provides powerful, policy-based security mechanisms to **protect sensitive data dynamically** — without duplicating datasets or managing multiple table copies.

This chapter explores two critical features:

- **Dynamic Data Masking (DDM)** — hides sensitive column data at query runtime.  
- **Row-Level Security (RLS)** — restricts access to individual rows based on user context (role, region, etc.).  

Together, they enable **fine-grained access control** for modern data governance.

---

## 📖 Table of Contents

**1.** Understanding Policy-Based Security  
**2.** What Is Dynamic Data Masking (DDM)?  
**3.** Creating and Applying Masking Policies  
**4.** Conditional Masking with Roles and Functions  
**5.** Row-Level Security (RLS) Concepts.  
**6.** Creating and Applying Row Access Policies  
**7.** Combining DDM and RLS  
**8.** Testing and Verifying Security Policies  
**9.** Best Practices for Policy-Based Security  
**10.** Hands-On Mini Project: Secure HR Data Warehouse  

---

## 1️⃣ Understanding Policy-Based Security

Snowflake’s security model allows you to **attach policies** directly to tables or columns.  
Unlike manual masking or views, policies are:

- **Declarative** — defined once and applied automatically. 
- **Dynamic** — change results at runtime based on role/user. 
- **Transparent** — no need to modify queries or ETL processes. 

Two main policy types:

`MASKING POLICY` — for **column-level masking**  
`ROW ACCESS POLICY` — for **row-level filtering**

---

## 2️⃣ What Is Dynamic Data Masking (DDM)?

**Dynamic Data Masking** hides or obfuscates sensitive data (e.g., SSN, salary, email) from unauthorized users during query execution — without altering the underlying data.

**Example Use Cases**

| Data Type | Masking Example                         |
| --------- | --------------------------------------- |
| SSN       | `XXX-XX-6789`                           |
| Email     | `v****@domain.com`                      |
| Phone     | `+91-******1234`                        |
| Salary    | `NULL` or `****` for unauthorized roles |  

---

## 3️⃣ Creating and Applying Masking Policies

**Step 1 — Create a Masking Policy**

```sql
CREATE OR REPLACE MASKING POLICY ssn_mask_policy
  AS (val STRING) RETURNS STRING ->
  CASE
    WHEN CURRENT_ROLE() IN ('HR_ADMIN', 'ACCOUNTADMIN') THEN val
    ELSE 'XXX-XX-XXXX'
  END;
```

**Step 2 — Apply to a Table Column**

```sql
ALTER TABLE employee_data
  MODIFY COLUMN ssn
  SET MASKING POLICY ssn_mask_policy;
```

**Step 3 — Test the Policy**

```sql
-- As HR_ADMIN
USE ROLE HR_ADMIN;
SELECT ssn FROM employee_data LIMIT 5;

-- As DEVELOPER
USE ROLE DEVELOPER;
SELECT ssn FROM employee_data LIMIT 5;
```

🔍 Authorized users see full SSNs; others see masked values.

---

## 4️⃣ Conditional Masking with Roles and Functions

You can design custom logic for different user categories.

```sql
CREATE MASKING POLICY email_mask_policy
  AS (val STRING) RETURNS STRING ->
  CASE
    WHEN CURRENT_ROLE() IN ('ADMIN', 'SUPPORT') THEN val
    WHEN SYSTEM$CURRENT_USER() = 'venkat' THEN val
    ELSE CONCAT('xxxx@', SPLIT_PART(val, '@', 2))
  END;
  ```


📌 Note: You can use functions like `CURRENT_ROLE()`, `CURRENT_USER()`, and `IS_ROLE_IN_SESSION()` to define flexible access conditions.

---

## 5️⃣ Row-Level Security (RLS) Concepts

RLS filters rows based on **who is querying**.
It ensures users only see records relevant to their region, department, or function.

**Example:**

An `APAC_ANALYST` should only see data from Asia-Pacific.  
A `US_MANAGER` should see data from the United States only.  

---

## 6️⃣ Creating and Applying Row Access Policies

**Step 1 — Create Row Access Policy**

```sql
CREATE OR REPLACE ROW ACCESS POLICY region_policy
  AS (region STRING) RETURNS BOOLEAN ->
  CASE
    WHEN CURRENT_ROLE() = 'US_ANALYST' THEN region = 'US'
    WHEN CURRENT_ROLE() = 'EU_ANALYST' THEN region = 'EU'
    WHEN CURRENT_ROLE() = 'APAC_ANALYST' THEN region = 'APAC'
    ELSE FALSE
  END;
```

**Step 2 — Apply Policy to Table**

```sql
ALTER TABLE sales_data
  ADD ROW ACCESS POLICY region_policy ON (region);
```

**Step 3 — Test the Policy**

```sql
USE ROLE US_ANALYST;
SELECT * FROM sales_data;

USE ROLE EU_ANALYST;
SELECT * FROM sales_data;
```

Each role sees only rows from its assigned region.

---

## 7️⃣ Combining DDM and RLS

You can **combine** both masking and row-level security for maximum protection.

Example:

```sql
ALTER TABLE employee_data
  ADD ROW ACCESS POLICY region_policy ON (region);

ALTER TABLE employee_data
  MODIFY COLUMN salary
  SET MASKING POLICY salary_mask_policy;
```

This setup:
- Restricts rows by region (RLS)
- Masks salary column for unauthorized roles (DDM)

---

## 8️⃣ Testing and Verifying Security Policies

**Check applied policies:**

```sql
SHOW MASKING POLICIES;
SHOW ROW ACCESS POLICIES;
```

**Audit role privileges:**

```sql
SHOW GRANTS TO ROLE developer;
```

**Test query visibility:**

```sql
SELECT CURRENT_ROLE(), CURRENT_USER(), * FROM employee_data;
```

**To view all applied policies:**

```sql
DESC TABLE employee_data;
```

---

## 9️⃣ Best Practices for Policy-Based Security

✅ Store policy logic in a centralized schema (e.g., `SECURITY_POLICIES`).  
✅ Use naming conventions (`mask_`, `rls_`) for easy tracking.  
✅ Avoid hardcoding usernames — rely on roles.  
✅ Combine DDM + RLS for layered defense.  
✅ Regularly audit using:  

```sql
SELECT * FROM SNOWFLAKE.ACCOUNT_USAGE.ROW_ACCESS_POLICY_REFERENCES;
```

✅ Use masking for **PII**, **financial**, or **personal contact data**.  
✅ Apply RLS on shared datasets to ensure compliance with GDPR, HIPAA, etc.  

---

## 🧪 Hands-On Mini Project: Secure HR Data Warehouse

**🎯 Objective**

Protect sensitive HR data (SSN, salary, region) using **Dynamic Masking** and **Row-Level Security**.

**Step 1 — Create HR Table**

```sql
CREATE OR REPLACE TABLE hr_employees (
  emp_id STRING,
  emp_name STRING,
  ssn STRING,
  salary NUMBER,
  region STRING
);
```

**Step 2 — Create Masking Policy for SSN and Salary**

```sql
CREATE OR REPLACE MASKING POLICY ssn_mask_policy AS (val STRING) RETURNS STRING ->
  CASE
    WHEN CURRENT_ROLE() IN ('HR_ADMIN', 'PAYROLL') THEN val
    ELSE 'XXX-XX-XXXX'
  END;

CREATE OR REPLACE MASKING POLICY salary_mask_policy AS (val NUMBER) RETURNS NUMBER ->
  CASE
    WHEN CURRENT_ROLE() IN ('HR_ADMIN', 'PAYROLL') THEN val
    ELSE NULL
  END;
```

**Step 3 — Apply Masking Policies**

```sql
ALTER TABLE hr_employees
  MODIFY COLUMN ssn SET MASKING POLICY ssn_mask_policy;

ALTER TABLE hr_employees
  MODIFY COLUMN salary SET MASKING POLICY salary_mask_policy;
```

**Step 4 — Create Row Access Policy by Region**

```sql
CREATE OR REPLACE ROW ACCESS POLICY hr_region_policy
AS (region STRING) RETURNS BOOLEAN ->
  CASE
    WHEN CURRENT_ROLE() = 'US_HR' THEN region = 'US'
    WHEN CURRENT_ROLE() = 'EU_HR' THEN region = 'EU'
    ELSE FALSE
  END;

ALTER TABLE hr_employees
  ADD ROW ACCESS POLICY hr_region_policy ON (region);
```

**Step 5 — Test Data Visibility**

```sql
USE ROLE HR_ADMIN;
SELECT emp_name, ssn, salary FROM hr_employees;

USE ROLE US_HR;
SELECT emp_name, ssn, salary FROM hr_employees;

USE ROLE DEVELOPER;
SELECT emp_name, ssn, salary FROM hr_employees;
```


✅ Result:

- HR_ADMIN sees all data.  
- US_HR sees only U.S. employees.  
- DEVELOPER sees masked SSNs and NULL salaries.  

---

## 🧠 Summary  

| Feature                  | Description                                          |
| ------------------------ | ---------------------------------------------------- |
| **Dynamic Data Masking** | Obfuscates column data at runtime                    |
| **Row-Level Security**   | Filters data rows based on role/user                 |
| **Combination**          | Enables multi-layered privacy protection             |
| **Use Cases**            | PII protection, multi-region access, compliance      |
| **Best Practice**        | Use policies declaratively and centralize management |  

---

## 🔒 Key Takeaways

- DDM and RLS enhance **data governance** without modifying queries.  
- Policies scale across schemas and roles automatically.  
- Combine both for full compliance with **GDPR, HIPAA, and ISO 27001**.  
- Regularly **audit**, **test**, and **document** all applied policies.  
