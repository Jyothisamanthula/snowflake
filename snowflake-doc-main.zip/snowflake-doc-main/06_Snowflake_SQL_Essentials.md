# ⚙️ Chapter 6: Snowflake SQL Essentials

---

## 6.1 Objective

In this chapter, you’ll:
- Learn the fundamentals of **Snowflake SQL syntax**
- Understand **DDL, DML, and DQL** operations
- Work with **functions**, **constraints**, and **data types**
- Explore **analytical and semi-structured** query features
- Execute real examples in Snowflake Worksheets

---

## 6.2 SQL in Snowflake

Snowflake SQL is ANSI-compliant with additional **cloud-native enhancements**, including:
- Automatic type casting  
- Dynamic result caching  
- Built-in functions for JSON, XML, and VARIANT data  
- Simplified DDL operations (no need to predefine indexes or partitions)

---

## 6.3 Data Definition Language (DDL)

### 6.3.1 Creating a Database, Schema, and Table

```sql
-- Create a database
CREATE OR REPLACE DATABASE TRAINING_DB;

-- Create a schema
CREATE OR REPLACE SCHEMA TRAINING_DB.PUBLIC;

-- Create a table
CREATE OR REPLACE TABLE TRAINING_DB.PUBLIC.EMPLOYEES (
  EMP_ID INT AUTOINCREMENT,
  FIRST_NAME STRING,
  LAST_NAME STRING,
  DEPARTMENT STRING,
  SALARY NUMBER(10,2),
  HIRE_DATE DATE
```

✅ Notes:

- AUTOINCREMENT automatically generates sequential IDs.

- No need to specify storage parameters — Snowflake handles it automatically.

### 6.3.2 Altering and Dropping Objects
```sql
-- Add a new column
ALTER TABLE EMPLOYEES ADD COLUMN EMAIL STRING;

-- Rename a table
ALTER TABLE EMPLOYEES RENAME TO EMPLOYEE_MASTER;

-- Drop a column
ALTER TABLE EMPLOYEE_MASTER DROP COLUMN EMAIL;

-- Drop table
DROP TABLE IF EXISTS EMPLOYEE_MASTER;
```
---
## 6.4 Data Manipulation Language (DML)
### 6.4.1 Inserting Data
```sql
INSERT INTO TRAINING_DB.PUBLIC.EMPLOYEES
  (FIRST_NAME, LAST_NAME, DEPARTMENT, SALARY, HIRE_DATE)
VALUES
  ('John', 'Doe', 'Engineering', 75000, '2023-06-01'),
  ('Mary', 'Smith', 'Finance', 68000, '2023-07-12'),
  ('Raj', 'Kumar', 'HR', 55000, '2023-09-05');
```
### 6.4.2 Updating and Deleting
```sql
-- Update salary
UPDATE EMPLOYEES
SET SALARY = SALARY * 1.05
WHERE DEPARTMENT = 'Engineering';

-- Delete a record
DELETE FROM EMPLOYEES WHERE FIRST_NAME = 'Raj';
```
### 6.4.3 Merge (Upsert)

The MERGE statement combines INSERT, UPDATE, and DELETE logic.

```sql MERGE INTO EMPLOYEES T
USING NEW_EMPLOYEES S
ON T.EMP_ID = S.EMP_ID
WHEN MATCHED THEN
  UPDATE SET T.SALARY = S.SALARY
WHEN NOT MATCHED THEN
  INSERT (EMP_ID, FIRST_NAME, LAST_NAME, DEPARTMENT, SALARY)
  VALUES (S.EMP_ID, S.FIRST_NAME, S.LAST_NAME, S.DEPARTMENT, S.SALARY);
```

💡 Commonly used for ETL pipelines and CDC (Change Data Capture).
---
## 6.5 Data Query Language (DQL)
### 6.5.1 Basic SELECT
```sql
SELECT * FROM EMPLOYEES;
SELECT FIRST_NAME, SALARY FROM EMPLOYEES WHERE DEPARTMENT = 'Finance';
```
### 6.5.2 Sorting, Filtering, and Limiting
```sql
-- ORDER BY
SELECT * FROM EMPLOYEES ORDER BY SALARY DESC;

-- DISTINCT
SELECT DISTINCT DEPARTMENT FROM EMPLOYEES;

-- LIMIT
SELECT * FROM EMPLOYEES LIMIT 5;
```

## 6.6 Built-In Functions
### 6.6.1 String Functions
```sql
SELECT 
  UPPER(FIRST_NAME) AS UPPERCASE,
  CONCAT(FIRST_NAME, ' ', LAST_NAME) AS FULLNAME
FROM EMPLOYEES;
```
### 6.6.2 Numeric and Date Functions
```sql
SELECT
  ROUND(SALARY, 0) AS ROUNDED_SALARY,
  DATEDIFF('day', HIRE_DATE, CURRENT_DATE()) AS DAYS_WORKED
FROM EMPLOYEES;
```
## 6.7 Analytical and Window Functions
### 6.7.1 ROW_NUMBER and RANK
```sql
SELECT
  DEPARTMENT,
  FIRST_NAME,
  SALARY,
  ROW_NUMBER() OVER (PARTITION BY DEPARTMENT ORDER BY SALARY DESC) AS RNK
FROM EMPLOYEES;
```

Output:
```diff
+-------------+------------+--------+-----+
| DEPARTMENT  | FIRST_NAME | SALARY | RNK |
+-------------+------------+--------+-----+
| Engineering | John       | 75000  | 1   |
| Finance     | Mary       | 68000  | 1   |
+-------------+------------+--------+-----+
```
### 6.7.2 Aggregate Functions
```sql
SELECT 
  DEPARTMENT,
  COUNT(*) AS EMP_COUNT,
  AVG(SALARY) AS AVG_SALARY,
  MAX(SALARY) AS MAX_SALARY
FROM EMPLOYEES
GROUP BY DEPARTMENT
ORDER BY AVG_SALARY DESC;
```
---
## 6.8 Working with Constraints
```sql
CREATE OR REPLACE TABLE DEPARTMENTS (
  DEPT_ID INT PRIMARY KEY,
  DEPT_NAME STRING UNIQUE,
  LOCATION STRING NOT NULL
);
```

- **PRIMARY KEY** – ensures uniqueness

- **UNIQUE** – prevents duplicates

- **NOT NULL** – enforces mandatory values

## 6.9 Handling NULLs
```sql
SELECT 
  FIRST_NAME,
  NVL(SALARY, 0) AS SALARY_SAFE,
  COALESCE(DEPARTMENT, 'Unknown') AS DEPT
FROM EMPLOYEES;
```

✅ NVL and COALESCE replace NULL values with defaults.

## 6.10 Semi-Structured Data (VARIANT, JSON)

Snowflake supports JSON, AVRO, PARQUET, XML, and more using the VARIANT data type.

### 6.10.1 Create a Table with VARIANT Column
```sql
CREATE OR REPLACE TABLE CUSTOMER_JSON (
  CUSTOMER_ID INT,
  CUSTOMER_DATA VARIANT
);
```
### 6.10.2 Insert JSON Data
```sql
INSERT INTO CUSTOMER_JSON VALUES
(1, PARSE_JSON('{"name": "Alice", "city": "Delhi", "orders": [1001,1002]}')),
(2, PARSE_JSON('{"name": "Bob", "city": "Mumbai", "orders": [1003]}'));
```

### 6.10.3 Query JSON Fields
```sql
SELECT
  CUSTOMER_DATA:name::string AS NAME,
  CUSTOMER_DATA:city::string AS CITY,
  CUSTOMER_DATA:orders[0]::int AS FIRST_ORDER
FROM CUSTOMER_JSON;
```

Output:
```pgsql
+--------+--------+-------------+
| NAME   | CITY   | FIRST_ORDER |
+--------+--------+-------------+
| Alice  | Delhi  | 1001        |
| Bob    | Mumbai | 1003        |
+--------+--------+-------------+
```
---
## 6.11 Temporary and Transient Tables
| Table Type    | Lifetime      | Data Persistence        | Use Case           |
| ------------- | ------------- | ----------------------- | ------------------ |
| **Permanent** | Forever       | Fail-safe + Time Travel | Production data    |
| **Temporary** | Session       | Deleted on logout       | Intermediate steps |
| **Transient** | Until dropped | No Fail-safe            | Staging data       |  


Example:

```sql
CREATE TEMPORARY TABLE TEMP_SALES AS
SELECT * FROM EMPLOYEES WHERE SALARY > 60000;
```
---
## 6.12 Views and Materialized Views
### 6.12.1 Create a View
```sql
CREATE OR REPLACE VIEW HIGH_EARNERS AS
SELECT FIRST_NAME, SALARY
FROM EMPLOYEES
WHERE SALARY > 70000;
```
### 6.12.2 Create a Materialized View
```sql
CREATE OR REPLACE MATERIALIZED VIEW MV_SALARY_AGG AS
SELECT DEPARTMENT, AVG(SALARY) AS AVG_SAL
FROM EMPLOYEES
GROUP BY DEPARTMENT;
```

💡 Materialized views store precomputed results, improving performance on repeated queries.

## 6.13 Common Table Expressions (CTEs)
```sql
WITH HIGH_SALARIES AS (
  SELECT * FROM EMPLOYEES WHERE SALARY > 65000
)
SELECT FIRST_NAME, DEPARTMENT FROM HIGH_SALARIES;
```
---
## 6.14 Query Caching and Performance

Snowflake caches query results for **24 hours** by default.
Re-running the same query (with no data changes) retrieves results instantly — at **no cost**.

```sql
SELECT COUNT(*) FROM EMPLOYEES;
-- Re-run: returns instantly from cache
```
---
## 6.15 Error Handling and Safe Casting

```sql
-- Avoid runtime errors
SELECT TRY_TO_NUMBER('ABC') AS SAFE_CAST;  -- returns NULL
```

✅ Use TRY_ functions (TRY_CAST, TRY_TO_DATE) to prevent query failures.
---
## 6.16 Practical Exercise
```sql
-- Step 1: Create and populate
CREATE OR REPLACE TABLE SALES (
  ID INT,
  REGION STRING,
  AMOUNT NUMBER(10,2),
  ORDER_DATE DATE
);

INSERT INTO SALES VALUES
(1, 'East', 500, '2025-01-10'),
(2, 'West', 300, '2025-01-12'),
(3, 'East', 450, '2025-01-15');

-- Step 2: Analytics
SELECT
  REGION,
  SUM(AMOUNT) AS TOTAL_SALES,
  AVG(AMOUNT) AS AVG_SALES,
  ROW_NUMBER() OVER (ORDER BY SUM(AMOUNT) DESC) AS RN
FROM SALES
GROUP BY REGION;
```

## 6.17 Summary

✅ You learned:

- Core DDL, DML, and DQL syntax in Snowflake

- Handling constraints, NULLs, and semi-structured data

- Using window functions, CTEs, and materialized views

- Query caching and performance optimizations
