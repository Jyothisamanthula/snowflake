# Chapter 15: Partitioning, Clustering, and Micro-Partitions
## 15.1 Introduction

Data organization is one of the most critical factors influencing **Snowflake performance**.
While Snowflake automatically manages storage optimization, understanding **partitioning, clustering**, and **micro-partitions** helps you design tables and queries that maximize efficiency.

In this chapter, we will explore:

- How Snowflake stores data in micro-partitions  
- How partition pruning improves query performance  
- The concept of clustering and when to use it  
- Best practices for large-scale data design and optimization
---

## 15.2 How Data Is Stored in Snowflake

Unlike traditional databases that rely on **user-defined partitions**, Snowflake automatically divides table data into **micro-partitions**.

🔹 **Key Facts about Micro-Partitions**

- Each micro-partition stores 50 MB to 500 MB of compressed data.  
- Data is stored in columnar format, optimized for analytics.  
- Each partition maintains metadata such as:  
  - Minimum and maximum column values
  - Distinct value counts  
  - NULL counts  
  - File locations in cloud storage  

This metadata enables **partition pruning**, allowing Snowflake to skip unnecessary partitions and accelerate queries.

---
## 15.3 What Are Micro-Partitions?

A **micro-partition** is the smallest physical storage and processing unit in Snowflake.

| **Attribute**  | **Description**                                   |
| -------------- | ------------------------------------------------- |
| **Size**       | 50 MB – 500 MB (compressed)                       |
| **Structure**  | Columnar storage                                  |
| **Managed By** | Automatically handled by Snowflake                |
| **Purpose**    | Enables partition pruning and parallel processing |
| **Metadata**   | Min/Max values, stats, and file references        |  

Snowflake automatically creates and manages micro-partitions during data load or insert operations.

**Example**
```sql
-- Create a standard table
CREATE OR REPLACE TABLE SALES (
  ORDER_ID     NUMBER,
  REGION       STRING,
  ORDER_DATE   DATE,
  REVENUE      NUMBER
);

-- Load data (Snowflake automatically creates micro-partitions)
COPY INTO SALES
FROM @STAGE/SALES_DATA/
FILE_FORMAT = (TYPE = CSV FIELD_OPTIONALLY_ENCLOSED_BY='"');
```
---
## 15.4 Partition Pruning 

**Partition pruning** allows Snowflake to read only those micro-partitions that match query filters.
This dramatically reduces I/O and compute consumption.

**Example**

```sql
SELECT *
FROM SALES
WHERE REGION = 'EUROPE';
```

When this query executes, Snowflake’s optimizer uses micro-partition metadata to identify which partitions contain `REGION = 'EUROPE'` and **skips all others**.

💡 Effective pruning depends on how well data is organized across micro-partitions — which is influenced by clustering.

---
## 15.5 Clustering in Snowflake

While micro-partitioning is automatic, **clustering keys** allow you to influence how data is organized.

A **clustering key** defines one or more columns that Snowflake uses to co-locate related rows within micro-partitions.

**Benefits of Clustering**

- Improves partition pruning efficiency
- Reduces bytes scanned for queries
- Enhances query predictability on large datasets

**Example: Defining a Clustering Key**

```sql
ALTER TABLE SALES CLUSTER BY (REGION, ORDER_DATE);
```

After clustering, Snowflake will organize rows so that similar `REGION` and `ORDER_DATE` values reside in the same micro-partitions.

---
## 15.6 Automatic vs Manual Clustering

Snowflake supports **two clustering strategies**.

🔹 **Automatic Clustering**

- Available in **Enterprise Edition and above**  
- Snowflake continuously monitors and reclusters data in the background  
- Ideal for large, frequently updated tables  

```sql
ALTER TABLE SALES SET AUTO_CLUSTERING = TRUE;
```

🔹 **Manual Clustering**

- You trigger reclustering as needed  
- Useful for smaller datasets or where auto-clustering is unavailable  

```sql
ALTER TABLE SALES RECLUSTER;
```

⚠️ Note: Automatic clustering incurs background compute costs.
Use it only for large, frequently queried tables.  

---

## 15.7 Clustering Depth and Analysis

You can inspect clustering quality with Snowflake’s system function:

```sql
SELECT SYSTEM$CLUSTERING_INFORMATION('SALES');
```

**Output Parameters**

| **Parameter**           | **Description**                           |
| ----------------------- | ----------------------------------------- |
| `cluster_by_keys`       | Columns used for clustering               |
| `total_partition_count` | Total number of micro-partitions          |
| `average_overlaps`      | Degree of overlap in clustering columns   |
| `average_depth`         | Effectiveness of pruning (lower = better) | 

**Clustering Depth Interpretation**

| **Depth Range** | **Interpretation** | **Meaning**                       | **Recommended Action**                 |
| --------------- | ------------------ | --------------------------------- | -------------------------------------- |
| **0.0 – 0.3**   | Excellent          | Well-clustered, efficient pruning | ✅ No action needed                     |
| **0.3 – 1.0**   | Moderate           | Some drift detected               | ⚙️ Plan reclustering                   |
| **> 1.0**       | Poor               | Data drift, inefficient pruning   | 🚨 Recluster or enable Auto-Clustering |  

---

## 15.8 Re-Clustering Best Practices
🔸 **1. Identify Large Tables**

Focus on tables > **1 GB** with frequent filtering on key columns.

🔸 **2. Choose Stable Columns**

Use clustering keys on columns that **don’t change frequently** (e.g., REGION, YEAR).

🔸 **3. Avoid Over-Clustering**

Too many clustering keys can reduce pruning efficiency.

🔸 **4. Monitor Clustering Health**

Use `SYSTEM$CLUSTERING_INFORMATION()` regularly to evaluate clustering drift.

🔸 **5. Recluster Incrementally**

Recluster only affected partitions instead of the full table:

```sql
ALTER TABLE SALES RECLUSTER WHERE ORDER_DATE > '2024-01-01';
```
---

## 15.9 Query Optimization with Micro-Partitions

Micro-partitioning improves query speed by scanning only relevant data ranges.

Example
```sql
SELECT REGION, SUM(REVENUE)
FROM SALES
WHERE ORDER_DATE BETWEEN '2024-01-01' AND '2024-03-31'
GROUP BY REGION;
```


If `ORDER_DATE` is part of the clustering key, Snowflake only scans partitions containing that range.

**Query Design Tips**

✅ Use range filters on clustered columns  
❌ Avoid wrapping filters in functions (e.g., TO_DATE(), UPPER())  
✅ Create materialized views for repetitive aggregations  

---

## 15.10 Monitoring Micro-Partition Metadata

Snowflake provides metadata views and functions to monitor storage and pruning efficiency.

**Example 1: View Micro-Partition Metrics**
```sql
SELECT *
FROM TABLE(INFORMATION_SCHEMA.TABLE_STORAGE_METRICS('SALES'));
```
**Example 2: Check Table Storage Usage**
```sql
SELECT 
  TABLE_NAME,
  ACTIVE_BYTES / 1024 / 1024 AS ACTIVE_MB,
  MICRO_PARTITION_COUNT
FROM INFORMATION_SCHEMA.TABLE_STORAGE_METRICS
WHERE TABLE_NAME = 'SALES';
```
---
## 15.11 Performance and Cost Considerations  

| **Aspect**       | **Recommendation**                                 |
| ---------------- | -------------------------------------------------- |
| **Query Speed**  | Use clustering keys on frequently filtered columns |
| **Cost**         | Enable auto-clustering only when necessary         |
| **Storage**      | Avoid excessive reclustering (rewrites data)       |
| **Maintenance**  | Monitor using `SYSTEM$CLUSTERING_INFORMATION()`    |
| **Data Loading** | Load data in sorted order when possible            |

⚖️ Balance cost and performance — over-clustering can waste credits, under-clustering can slow queries.

---
## 15.12 Real-World Example: Time-Series Optimization
**Scenario**

A large `EVENT_LOGS` table contains billions of records partitioned by timestamp.

**Without Clustering**
```sql'
SELECT COUNT(*) FROM EVENT_LOGS WHERE EVENT_DATE = '2025-09-15';
```

- Full table scan  
- High compute cost

**With Clustering**

```sql
ALTER TABLE EVENT_LOGS CLUSTER BY (EVENT_DATE);
```

- Snowflake prunes partitions outside the date range  
- Query executes significantly faster  
- Reduced compute credits and latency
---

## 15.13 Summary

Snowflake’s **micro-partition architecture** removes the need for traditional manual partitioning.
However, using **clustering keys** and **partition pruning techniques** gives data engineers finer control over performance.

🔑 **Key Takeaways**

- Micro-partitions are Snowflake’s core storage and performance unit
- Partition pruning skips irrelevant data automatically
- Clustering keys enhance pruning and query consistency
- Auto-clustering simplifies maintenance for large tables
- Regularly monitor clustering health via `SYSTEM$CLUSTERING_INFORMATION`

Efficient micro-partitioning and thoughtful clustering are the foundation of **high-performance Snowflake design**.

