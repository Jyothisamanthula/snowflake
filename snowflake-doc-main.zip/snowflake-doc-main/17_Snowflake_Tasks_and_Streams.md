# 📘 Chapter 17: Building ETL/ELT Pipelines using Tasks + Streams  

## 🧭 Overview

Modern data pipelines need to be **automated**, **scalable**, and **event-driven**.
In Snowflake, this is made possible through a powerful combination of:  
- **Streams** → Track changes (CDC) in your tables  
- **Tasks** → Schedule and execute SQL transformations automatically

Together, they allow you to build **near real-time ETL/ELT** pipelines — natively within Snowflake, without relying on external orchestration tools.  

---

## 🧱 What Are Streams?

A **Stream** in Snowflake is a **Change Data Capture (CDC)** mechanism that tracks inserts, updates, and deletes on a table.

It provides an incremental view of what changed since the last time it was queried.

✅ Key Features:

- Tracks data changes (DML operations)  
- Enables incremental data processing  
- Works seamlessly with Tasks  
- Helps build continuous ingestion pipelines

--- 

**Types of Streams**    

| Type                   | Description                                                 |
| ---------------------- | ----------------------------------------------------------- |
| **Standard Stream**    | Tracks changes at the row level (INSERT, UPDATE, DELETE).   |
| **Append-Only Stream** | Tracks only new inserts. Best for append-based pipelines.   |
| **Delta Stream**       | Stores only the *differences* for performance optimization. |  



## 🧩 Creating a Stream

```sql
CREATE OR REPLACE STREAM orders_stream
  ON TABLE raw.orders
  APPEND_ONLY = FALSE;
```


📘 **Explanation:**

- The stream tracks all DML changes on the `raw.orders` table.  
- APPEND_ONLY = FALSE means it tracks **INSERTs, UPDATEs, and DELETEs**.

---

## 🔍 Viewing Stream Data

```sql
SELECT *
FROM orders_stream;
```

🧠 The result includes metadata columns:

- _METADATA$ACTION: Type of change (INSERT/DELETE)  
- _METADATA$ISUPDATE: Whether it’s part of an update  
- _METADATA$ROW_ID: Unique row identifier

---

## ⚙️ What Are Tasks?

A Task is a scheduled or dependent process that executes SQL statements.
When used with Streams, it can incrementally process new data as soon as changes are detected.

You can think of it as the scheduler and executor of your pipeline.

🔄 **Combining Streams and Tasks**

When combined:
- The **Stream** tracks changes in your source table.  
- The **Task** consumes the Stream and applies changes to your target table (via `MERGE`, `INSERT`, etc.).  
- Once consumed, Snowflake automatically advances the Stream offset.  

---

## 🧩 Example: Simple Incremental Pipeline

**Step 1 — Create Source Table**

```sql
CREATE OR REPLACE TABLE raw.orders (
  order_id INT,
  customer_id INT,
  amount NUMBER(10,2),
  order_status STRING,
  updated_at TIMESTAMP_NTZ
);
```

**Step 2 — Create Target Table**

```sql
CREATE OR REPLACE TABLE analytics.orders_processed AS
SELECT * FROM raw.orders WHERE 1=0;
```

**Step 3 — Create a Stream**

```sql
CREATE OR REPLACE STREAM orders_stream ON TABLE raw.orders;
```

**Step 4 — Create a Task to Process Stream**

```sql
CREATE OR REPLACE TASK process_orders_stream
  WAREHOUSE = ETL_WH
  SCHEDULE = '5 MINUTE'
AS
  MERGE INTO analytics.orders_processed tgt
  USING (
    SELECT * FROM raw.orders_stream
  ) src
  ON tgt.order_id = src.order_id
  WHEN MATCHED THEN UPDATE SET
    tgt.order_status = src.order_status,
    tgt.amount = src.amount,
    tgt.updated_at = src.updated_at
  WHEN NOT MATCHED THEN
    INSERT (order_id, customer_id, amount, order_status, updated_at)
    VALUES (src.order_id, src.customer_id, src.amount, src.order_status, src.updated_at);
```

**Step 5 — Enable Task**

```sql
ALTER TASK process_orders_stream RESUME;
```

✅ The task now runs every 5 minutes, processing only new or changed rows.

---

## 🧠 How the Process Works

**1.** Data lands in `raw.orders`  
**2.** The Stream (`orders_stream`) captures the changes  
**3.** The Task (`process_orders_stream`) reads from the Stream  
**4.** The `MERGE` command updates the target table  
**5.** Stream offset advances — next run picks up new changes only

---

## 🔗 Building a Multi-Stage ETL Pipeline

You can chain tasks to build multi-stage workflows.

```sql
-- Stage 1: Ingest data from stage area
CREATE OR REPLACE TASK load_stage_data
  WAREHOUSE = LOAD_WH
  SCHEDULE = '1 HOUR'
AS
  COPY INTO raw.orders
  FROM @orders_stage
  FILE_FORMAT = (TYPE = 'CSV');

-- Stage 2: Transform using a stream
CREATE OR REPLACE TASK transform_stage_orders
  WAREHOUSE = ETL_WH
  AFTER load_stage_data
AS
  MERGE INTO analytics.orders_cleaned tgt
  USING raw.orders_stream src
  ON tgt.order_id = src.order_id
  WHEN MATCHED THEN UPDATE SET amount = src.amount
  WHEN NOT MATCHED THEN INSERT VALUES (src.*);
```


Here:

- The second task (`transform_stage_orders`) automatically runs after the first (`load_stage_data`).  
- You can visualize this as a directed acyclic graph (DAG).

---

## 📊 Monitoring Pipeline Status

You can track execution history using the Information Schema.

```sql
SELECT *
FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY())
ORDER BY SCHEDULED_TIME DESC;
```

And for Stream progress:

SHOW STREAMS;

```sql
SELECT TABLE_NAME, STALE_AFTER, LAST_CONSUMED_TIME
FROM INFORMATION_SCHEMA.STREAMS;
```

---

⚡ Real-World ETL/ELT Use Cases  

| Use Case                                    | Description                                               |
| ------------------------------------------- | --------------------------------------------------------- |
| **Incremental Data Loads**                  | Automatically load new/updated rows without full refresh. |
| **Real-Time Analytics**                     | Combine Streams + Tasks for near real-time dashboards.    |
| **Data Lake Ingestion**                     | Use `COPY INTO` → Stream → Transform pipeline.            |
| **Slowly Changing Dimensions (SCD Type 2)** | Track and update historical data efficiently.             |  

---

## 💡 Best Practices

- **1.Use APPEND_ONLY streams** for purely insert-based tables.  
- **2.Don’t over-query** the stream — each read advances its offset.  
- **3.Chain dependent tasks** instead of relying on time schedules.  
- **4.Assign dedicated warehouses** to avoid compute contention.  
- **5.Use task history** for debugging and alerting failed runs.

---

## 🧩 Example: End-to-End ETL Flow

```sql

┌──────────────────────────┐
│  Raw Data Landing Zone   │
└─────────────┬────────────┘
              │ COPY INTO
              ▼
      ┌──────────────────┐
      │   RAW.ORDERS     │
      └────────┬─────────┘
               │ Stream (CDC)
               ▼
      ┌────────────────────┐
      │  STREAM: ORDERS    │
      └────────┬───────────┘
               │ Task (MERGE)
               ▼
      ┌────────────────────┐
      │ ANALYTICS.ORDERS   │
      └────────────────────┘
```

This illustrates a **native Snowflake ELT pipeline**:

- Data ingested from external sources  
- Tracked by a Stream  
- Processed incrementally via a Task

---

## 🧭 Summary   

| Concept          | Description                                             |
| ---------------- | ------------------------------------------------------- |
| **Stream**       | Captures data changes on a table (CDC).                 |
| **Task**         | Executes SQL statements on a schedule or dependency.    |
| **ETL Pipeline** | Combines Streams + Tasks for automated transformations. |
| **Monitoring**   | Use `TASK_HISTORY()` and `SHOW STREAMS` for visibility. |
| **Optimization** | Use dedicated warehouses and chain dependencies.        |  

---


# 🧪 Hands-On Mini Project: Building a Sales Data Pipeline

Let’s now build a practical project — a simple but complete Sales ETL pipeline in Snowflake.

🎯 Objective:

To automate ingestion, transformation, and aggregation of sales data using **Streams + Tasks**.

## Step 1 — Create Staging and Target Tables

```sql
CREATE OR REPLACE TABLE stage.sales_raw (
  sale_id INT,
  product STRING,
  amount NUMBER(10,2),
  region STRING,
  sale_date DATE,
  updated_at TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

CREATE OR REPLACE TABLE analytics.sales_summary (
  region STRING,
  total_amount NUMBER(12,2),
  last_updated TIMESTAMP_NTZ
);
```


## Step 2 — Create a Stream to Track Changes

```sql
CREATE OR REPLACE STREAM sales_stream ON TABLE stage.sales_raw;
```

This stream will capture all new and changed sales transactions.  



## Step 3 — Create Task for Data Transformation

```sql
CREATE OR REPLACE TASK transform_sales_data
  WAREHOUSE = ETL_WH
  SCHEDULE = '10 MINUTE'
AS
  MERGE INTO analytics.sales_summary tgt
  USING (
    SELECT region, SUM(amount) AS total_amount, MAX(updated_at) AS last_updated
    FROM stage.sales_raw
    GROUP BY region
  ) src
  ON tgt.region = src.region
  WHEN MATCHED THEN UPDATE SET
    tgt.total_amount = src.total_amount,
    tgt.last_updated = src.last_updated
  WHEN NOT MATCHED THEN
    INSERT (region, total_amount, last_updated)
    VALUES (src.region, src.total_amount, src.last_updated);
```

## Step 4 — Activate the Task

```sql
ALTER TASK transform_sales_data RESUME;
```

Now Snowflake automatically refreshes the **sales summary** table every 10 minutes.

## Step 5 — Test with Sample Data

```sql
INSERT INTO stage.sales_raw VALUES
(1, 'Laptop', 1200, 'East', CURRENT_DATE()),
(2, 'Phone', 800, 'West', CURRENT_DATE()),
(3, 'Tablet', 500, 'East', CURRENT_DATE());
```

Wait for your task to execute, then check results:

```sql
SELECT * FROM analytics.sales_summary;
```

You should see the region-wise aggregated totals automatically computed.

✅ Expected Outcome

| Region | Total_Amount | Last_Updated        |
| ------ | ------------ | ------------------- |
| East   | 1700         | 2025-10-13 09:00:00 |
| West   | 800          | 2025-10-13 09:00:00 |


## Step 6 — Verify Task History

```sql
SELECT *
FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY())
WHERE NAME = 'TRANSFORM_SALES_DATA'
ORDER BY SCHEDULED_TIME DESC;
```
You can view the latest task execution logs, duration, and status.

---


# Hands-On Mini Project — S3 → Snowflake Streaming Pipeline

## 🧩 Architecture

```text
AWS S3 (Raw CSV files)
      ↓
Snowflake External Stage (S3 Integration)
      ↓
Snowflake Staging Table
      ↓
Snowflake Stream (CDC Tracking)
      ↓
Snowflake Task (Scheduled Transformation)
      ↓
Snowflake Target Table (Analytics Ready)
```

## ⚙️ Step 1: Setup S3 Integration in Snowflake

First, create a **Snowflake Storage Integration** to securely connect to your AWS S3 bucket.

```sql
CREATE STORAGE INTEGRATION s3_integration
  TYPE = EXTERNAL_STAGE
  STORAGE_PROVIDER = S3
  ENABLED = TRUE
  STORAGE_AWS_ROLE_ARN = 'arn:aws:iam::123456789012:role/snowflake_s3_role'
  STORAGE_ALLOWED_LOCATIONS = ('s3://my-snowflake-demo/data/');
```

✅ Note:

- Replace the `AWS_ROLE_ARN` with your S3 IAM role.  
- Ensure your AWS IAM policy grants `s3:GetObject`, `s3:ListBucket`.  

You can verify integration details:

```sql
DESC INTEGRATION s3_integration;
```

## 📂 Step 2: Create External Stage for S3

```sql
CREATE OR REPLACE STAGE s3_stage
  URL = 's3://my-snowflake-demo/data/'
  STORAGE_INTEGRATION = s3_integration
  FILE_FORMAT = (TYPE = CSV FIELD_OPTIONALLY_ENCLOSED_BY='"' SKIP_HEADER=1);
```

List files from the stage:

```sql
LIST @s3_stage;
```

## 🧱 Step 3: Create Target Tables

Create a **staging** and **target** table.

```sql
CREATE OR REPLACE TABLE raw_sales_data (
  order_id       STRING,
  customer_name  STRING,
  product_name   STRING,
  quantity       NUMBER,
  price          NUMBER,
  order_date     DATE
);

CREATE OR REPLACE TABLE sales_summary (
  product_name   STRING,
  total_sales    NUMBER,
  last_updated   TIMESTAMP_NTZ
);
```

## 📤 Step 4: Load Data from S3 → Staging Table

Use the `COPY INTO` command to load data from S3.

```sql
COPY INTO raw_sales_data
FROM @s3_stage
FILE_FORMAT = (TYPE = CSV FIELD_OPTIONALLY_ENCLOSED_BY='"')
ON_ERROR = 'CONTINUE';
```

Check load summary:

```sql
SELECT * FROM raw_sales_data LIMIT 10;
```

## 🔍 Step 5: Create a Stream on Staging Table

This stream tracks new or changed rows in the staging table.

```sql
CREATE OR REPLACE STREAM raw_sales_stream
  ON TABLE raw_sales_data;
```

You can check captured changes:

```sql
SELECT * FROM raw_sales_stream;
```

## ⚡ Step 6: Create Transformation Task

A **Task** will process new rows periodically and update the target table.

```sql
CREATE OR REPLACE TASK sales_summary_task
  WAREHOUSE = COMPUTE_WH
  SCHEDULE = '1 MINUTE'
  WHEN SYSTEM$STREAM_HAS_DATA('raw_sales_stream')
AS
  MERGE INTO sales_summary AS tgt
  USING (
    SELECT product_name,
           SUM(quantity * price) AS total_sales,
           CURRENT_TIMESTAMP() AS last_updated
    FROM raw_sales_stream
    GROUP BY product_name
  ) AS src
  ON tgt.product_name = src.product_name
  WHEN MATCHED THEN
    UPDATE SET tgt.total_sales = src.total_sales,
               tgt.last_updated = src.last_updated
  WHEN NOT MATCHED THEN
    INSERT (product_name, total_sales, last_updated)
    VALUES (src.product_name, src.total_sales, src.last_updated);
```


## ▶️ Step 7: Start the Task

```sql
ALTER TASK sales_summary_task RESUME;
```


## 🧪 Step 8: Test the End-to-End Flow 

- Upload a new CSV file to your S3 bucket (e.g., `sales_data_2025_10.csv`).  
- Run COPY INTO `raw_sales_data` again.  
- **Wait 1** minute for the task to trigger.  
- Query your analytics table:

```sql
SELECT * FROM sales_summary ORDER BY total_sales DESC;
```


You should see the data automatically updated.

## 📈 Step 9: Monitor Task and Stream

```sql

SHOW TASKS LIKE 'sales_summary_task';
SHOW STREAMS LIKE 'raw_sales_stream';
```


You can also check task history:

```sql
SELECT * FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY())
WHERE NAME = 'SALES_SUMMARY_TASK';
```

---

## 🚀 Optional Enhancements

- **Automation**: Use Snowpipe for auto-ingestion from S3.  
- **Orchestration**: Integrate with Airflow or DBT.  
- **Alerting**: Send email or Slack notifications when tasks fail.  
- **Transformation Logic**: Include joins or lookup tables for dimension enrichment. 

---

## 🧠 Learning Outcomes

By the end of this project, you will:

- Understand how to connect Snowflake with **AWS S3** securely.  
- Learn how to design **incremental data pipelines** using **Streams + Tasks**.  
- Automate ELT processes without external schedulers.  
- Build scalable, cloud-native ingestion pipelines.  
