# Chapter 12: Secure Views vs Standard Views

Snowflake provides two main types of views — Standard Views and Secure Views.
While both are used to simplify query logic and control data access, Secure Views are specifically designed for data security, masking, and governance use cases.

## 12.1 What is a View in Snowflake?

A **view** in Snowflake is a saved SQL query that dynamically retrieves data from one or more tables.
It acts as a virtual table — it does not store data physically but references data stored elsewhere.

Views are useful for:

- Simplifying complex SQL queries  
- Enforcing business logic  
- Controlling access to sensitive data  
- Supporting abstraction layers (data marts, APIs, etc.)

---
## 12.2 Types of Views in Snowflake  

| **Type**          | **Definition**                                                            | **Key Difference**                                                 |
| ----------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------ |
| **Standard View** | A regular view for abstraction or simplification.                         | Not fully secure — metadata and logic are visible.                 |
| **Secure View**   | A view that hides underlying logic and enforces strict data access rules. | Ensures data privacy and security; used in regulated environments. |  

---

## 12.3 Standard Views

**A Standard View** exposes the underlying query logic and can be optimized or rewritten by Snowflake’s query optimizer.

**Syntax:**
```sql
CREATE OR REPLACE VIEW CUSTOMER_VIEW AS
SELECT 
    CUSTOMER_ID,
    NAME,
    EMAIL,
    PHONE
FROM CUSTOMER;
```

**Key Characteristics**

- Query text and underlying tables are visible to users with the MONITOR privilege.  
- Data access follows role privileges on base tables.  
- Not suitable for sensitive or confidential data exposure.
  

**Example Usage:**
```sql
SELECT * FROM CUSTOMER_VIEW WHERE CUSTOMER_ID = 101;
```


✅ Use Case:
When you want to simplify a query or standardize reusable logic (e.g., a unified customer view across departments).

---

## 12.4 Secure Views

**A Secure View** provides enhanced data protection by hiding query logic, metadata, and underlying table references from unauthorized users.

**Syntax:**
```sql
CREATE OR REPLACE SECURE VIEW CUSTOMER_SECURE_VIEW AS
SELECT 
    CUSTOMER_ID,
    NAME,
    EMAIL
FROM CUSTOMER
WHERE IS_ACTIVE = TRUE;
```

**Key Features**

| **Feature**           | **Description**                                                                   |
| --------------------- | --------------------------------------------------------------------------------- |
| **Metadata Security** | Underlying query, structure, and tables are hidden from non-owners.               |
| **Query Isolation**   | Snowflake doesn’t rewrite or optimize secure view queries using underlying logic. |
| **Data Privacy**      | Only data allowed by the view logic is accessible.                                |
| **Data Sharing**      | Only Secure Views can be shared across accounts using **Secure Data Sharing**.    |
| **Performance**       | Slightly higher query latency due to security enforcement.                        |  

**Example Usage:**
```sql
SELECT * FROM CUSTOMER_SECURE_VIEW WHERE CUSTOMER_ID = 101;
```

✅ Use Case:
Protect sensitive information such as PII (Personally Identifiable Information), financial data, or confidential business metrics.  

---
## 12.5 Secure Views in Data Sharing

When sharing data using Snowflake Data Sharing, only Secure Views are allowed to ensure data governance and privacy across organizations.

**Example Scenario**

A financial institution shares aggregated customer insights with partners:

```sql
CREATE OR REPLACE SECURE VIEW AGGREGATED_SALES AS
SELECT REGION, SUM(AMOUNT) AS TOTAL_SALES
FROM SALES
GROUP BY REGION;
```

Then grant access:

```sql
GRANT SELECT ON VIEW AGGREGATED_SALES TO SHARE FINANCIAL_PARTNERS;
```

✅ The partner can query the data but cannot see the underlying table structure or SQL logic.  

---
## 12.6 Differences Between Secure and Standard Views   

| **Feature**               | **Standard View**              | **Secure View**                            |
| ------------------------- | ------------------------------ | ------------------------------------------ |
| **Security Level**        | Basic                          | High                                       |
| **Query Text Visibility** | Visible to privileged users    | Hidden                                     |
| **Metadata Visibility**   | Visible                        | Hidden                                     |
| **Performance**           | Faster (no isolation overhead) | Slightly slower                            |
| **Data Sharing Support**  | ❌ Not allowed                 |  ✅ Supported                             |
| **Optimization Behavior** | Rewritten by optimizer         | Protected (no rewrite)                     |
| **Use Case**              | Simplified abstraction         | Data privacy, compliance, external sharing |  

---
## 12.7 Example: Comparing Standard vs Secure View

Let’s consider a **CUSTOMER** table:

```sql
CREATE OR REPLACE TABLE CUSTOMER (
    CUSTOMER_ID NUMBER,
    NAME STRING,
    EMAIL STRING,
    PHONE STRING,
    SSN STRING,
    IS_ACTIVE BOOLEAN
);
```

**Standard View**

```sql
CREATE OR REPLACE VIEW CUSTOMER_VIEW AS
SELECT CUSTOMER_ID, NAME, EMAIL, SSN FROM CUSTOMER;
```

**Secure View**

```sql
CREATE OR REPLACE SECURE VIEW CUSTOMER_SECURE_VIEW AS
SELECT CUSTOMER_ID, NAME, EMAIL, 
       CASE WHEN CURRENT_ROLE() IN ('HR_ROLE') THEN SSN ELSE NULL END AS SSN
FROM CUSTOMER;
```

**Result:**

- Regular users see NULL in SSN column.

- HR team (authorized role) sees full data.

---
## 12.8 Security Considerations

✅ Use Secure Views whenever exposing data externally or to restricted internal users.  
✅ Avoid granting direct access to base tables containing sensitive data.  
✅ Combine with Row-Level and Column-Level Security for fine-grained control.  
✅ Audit Secure View usage using Snowflake Access History and Query History views.   

---

## 12.9 Best Practices

🔹 Use Standard Views for:
- Simplifying complex joins  
- Building logical models for BI or analytics tools  

🔹 Use Secure Views for:  

- Data masking, PII protection  
- External or cross-account sharing  
- Regulatory compliance (GDPR, HIPAA, SOC 2, etc.)    

🔹 Combine Secure Views with:  

- Dynamic Data Masking  
- Row Access Policies  
- Role-Based Access Control (RBAC)  

---
## 12.10 Summary  

| **Scenario**                        | **Recommended View Type** | **Rationale**            |
| ----------------------------------- | ------------------------- | ------------------------ |
| Internal analytics / data modeling  | Standard View             | Performance & simplicity |
| External sharing (Data Marketplace) | Secure View               | Data protection          |
| PII / confidential data             | Secure View               | Hides query and metadata |
| Fast aggregation or transformations | Standard View             | Optimizer flexibility    |
| Regulatory compliance (GDPR/HIPAA)  | Secure View               | Secure by design         |  

---
✅ Key Takeaways

- **Standard Views** simplify access and improve reusability.
- **Secure Views** protect sensitive data by **hiding metadata, logic, and table lineage**.
- Always use Secure Views in data sharing or when handling **regulated datasets**.
- Combine Secure Views with **Row and Column Policies** for enterprise-grade data governance.



