# 📘 Chapter 23: Data Sharing and Secure Data Exchange in Snowflake  

**🎯 Chapter Overview**

Snowflake revolutionized the way organizations collaborate by enabling **secure, real-time data sharing** — without copying or moving data.

Through **Secure Data Sharing** and the **Snowflake Marketplace (Data Exchange)**, companies can share live, governed datasets across accounts, regions, or even cloud providers instantly.

In this chapter, you’ll learn:

- The concept and architecture of Data Sharing  
- Provider vs Consumer model  
- Secure Shares, Reader Accounts, and Direct Shares  
- Cross-region and cross-cloud sharing  
- Data Exchange & Marketplace overview  
- Hands-on project: Creating and consuming a secure data share 
- Best practices and governance

---


## 📖 Table of Contents

**1.** Introduction to Data Sharing  
**2.** Snowflake Sharing Architecture  
**3.** Types of Data Shares  
**4.** Creating Secure Shares  
**5.** Consuming Shared Data  
**6.** Cross-Region and Cross-Cloud Sharing  
**7.** Snowflake Data Marketplace & Private Exchange  
**8.** Hands-On Mini Project: Sharing Sales Data  
**9.** Best Practices & Governance  
**10.** Summary  

---

## 1️⃣ Introduction to Data Sharing

**Traditional data sharing** involves exporting and sending files via FTP, APIs, or data transfers — slow, risky, and costly.

Snowflake eliminates this with **Secure Data Sharing**, enabling:

- **Instant access** to live data
- **No data movement or duplication**
- **Full governance and access control**
- **Cross-cloud, cross-region sharing**

**Key Concepts**

| Term         | Description                                                                       |
| ------------ | --------------------------------------------------------------------------------- |
| **Provider** | The account that owns and shares data                                             |
| **Consumer** | The account that receives and uses shared data                                    |
| **Share**    | Logical object containing access to specific databases, schemas, tables, or views |  

---

## 2️⃣ Snowflake Sharing Architecture

Data Sharing is built into Snowflake’s **multi-cluster**, **shared-data architecture**.

**📘 How it works:**

- The **Provider** creates a Share object that grants access to selected objects.
- The **Consumer** creates a local Database from that share.
- The data remains physically stored in the Provider’s account — the Consumer queries it live.

**🧩 No data copy** → only **metadata-level permissions** are exchanged.  

---

## 3️⃣ Types of Data Shares  

| Share Type                   | Description                                                   | Use Case                                |
| ---------------------------- | ------------------------------------------------------------- | --------------------------------------- |
| **Direct Share**             | Provider shares directly to an existing Snowflake account     | Internal teams or known partners        |
| **Reader Account**           | Provider creates a managed Snowflake account for the consumer | Partners or customers without Snowflake |
| **Listing (Marketplace)**    | Provider lists dataset on Snowflake Marketplace               | Public or private data products         |
| **Cross-Region/Cloud Share** | Share data across regions or clouds                           | Global analytics or DR                  |  

---

## 4️⃣ Creating Secure Shares  

**Step 1 — Create a Database and Table**

```sql
CREATE OR REPLACE DATABASE sales_db;
USE sales_db;

CREATE OR REPLACE TABLE customer_sales (
  customer_id STRING,
  region STRING,
  amount NUMBER,
  order_date DATE
);

INSERT INTO customer_sales VALUES
('C001', 'IN', 1200, '2025-10-12'),
('C002', 'US', 980, '2025-10-13'),
('C003', 'UK', 1500, '2025-10-13');
```

**Step 2 — Create a Share**

```sql
CREATE OR REPLACE SHARE sales_share;
```

**Step 3 — Grant Usage Privileges**

```sql

GRANT USAGE ON DATABASE sales_db TO SHARE sales_share;
GRANT USAGE ON SCHEMA sales_db.public TO SHARE sales_share;
GRANT SELECT ON TABLE sales_db.public.customer_sales TO SHARE sales_share;
```

**Step 4 — Add Consumer Account**

```sql
ALTER SHARE sales_share ADD ACCOUNT = <consumer_account_name>;
```

You can find account names using:

```sql
SELECT CURRENT_ACCOUNT();
```

---

## 5️⃣ Consuming Shared Data

Once the Provider adds the Consumer’s account, the Consumer can create a **database from the share**.

```sql
CREATE DATABASE sales_shared_db FROM SHARE <provider_account>.sales_share;
```


Now, Consumer can query:

```sql
SELECT * FROM sales_shared_db.public.customer_sales;
```

✅ No copy. No ETL. Real-time access.

---

## 6️⃣ Cross-Region and Cross-Cloud Sharing

Snowflake allows sharing data **across regions and cloud providers** (AWS ↔ Azure ↔ GCP) using **Replication + Shares**.

**Steps**

**1.** Replicate your database to the target region:  

```sql
ALTER DATABASE sales_db ENABLE REPLICATION TO ACCOUNTS '<org>.<target_account>';  
```

**2.** Create share from the replicated copy.  

**3.** Consumer in another cloud region accesses it as usual.  

💡 Data stays secure, encrypted, and governed throughout the transfer.  

---

## 7️⃣ Snowflake Data Marketplace & Private Exchange

Snowflake’s **Marketplace** allows you to:

- Publish and monetize datasets  
- Consume free or paid public datasets  
- Share data with your organization privately  

**📦 Types**

| Exchange Type          | Visibility | Example                                        |
| ---------------------- | ---------- | ---------------------------------------------- |
| **Public Marketplace** | Global     | Industry data (weather, finance, demographics) |
| **Private Exchange**   | Internal   | Enterprise or partner-only access              |

Access via Web UI → **Data Marketplace** tab.  
You can browse listings, preview metadata, and request access instantly.  

---

## 8️⃣ Hands-On Mini Project: Sharing Sales Data Securely  

**🎯 Objective**

Share live **sales performance data** between two Snowflake accounts — one provider and one consumer.

**Step 1 — Provider: Create Table and Share**  

```sql
CREATE DATABASE sales_live;
USE sales_live;

CREATE OR REPLACE TABLE sales_txn (
  txn_id STRING,
  country STRING,
  revenue NUMBER,
  sale_date DATE
);

INSERT INTO sales_txn VALUES
('T001', 'IN', 5000, '2025-10-10'),
('T002', 'US', 7200, '2025-10-11');
```


**Create share:**

```sql
CREATE OR REPLACE SHARE share_sales_live;
GRANT USAGE ON DATABASE sales_live TO SHARE share_sales_live;
GRANT USAGE ON SCHEMA sales_live.public TO SHARE share_sales_live;
GRANT SELECT ON TABLE sales_live.public.sales_txn TO SHARE share_sales_live;
```

**Add consumer:**

```sql
ALTER SHARE share_sales_live ADD ACCOUNT = 'ORG2.ACCOUNT123';
```

**Step 2 — Consumer: Create Shared Database**

```sql
CREATE DATABASE sales_remote FROM SHARE ORG1.ACCOUNT1.share_sales_live;
```

**Step 3 — Query Shared Data**

```sql
SELECT * FROM sales_remote.public.sales_txn;
```


✅ Data queried live from provider — no replication or delay.

---

9️⃣ Best Practices & Governance  
  

✅ Govern Access with Roles:  
Use role-based privileges (`ACCOUNTADMIN`, `SECURITYADMIN`) for creating and managing shares.  

✅ Mask Sensitive Data:  
Apply Dynamic Data Masking before sharing to protect PII.  

✅ Monitor Usage:  
Use the ACCOUNT_USAGE.SHARES and SHARE_HISTORY views for auditing.  

✅ Version Control:  
When sharing frequently changing data, consider Materialized Views or Data Marketplace Listings.  

✅ Cross-Cloud Security:  
Ensure replication and sharing both use Network Policies and Encryption in Transit.  

✅ Revoke Access When Needed:  

```sql
ALTER SHARE share_sales_live REMOVE ACCOUNT = 'ORG2.ACCOUNT123';  
```

---

## 🧠 Summary  

| Feature                        | Description                              |
| ------------------------------ | ---------------------------------------- |
| **Secure Data Sharing**        | Live, governed sharing without data copy |
| **Reader Accounts**            | Snowflake-managed accounts for consumers |
| **Cross-Region/Cloud Sharing** | Enabled via Replication + Shares         |
| **Data Marketplace**           | Publish and consume global datasets      |
| **Private Exchange**           | Internal or partner data collaboration   |
| **Governance Tools**           | Roles, masking, and audit views          |  

---

## 🔑 Key Takeaways  


- Snowflake’s Data Sharing eliminates the need for data duplication.
- Real-time collaboration possible across regions and clouds.
- Marketplace enables monetization and discovery of live data.
- Governance and masking ensure secure sharing.
- Combine **Secure Shares + Replication + Marketplace** for a complete data collaboration strategy.
