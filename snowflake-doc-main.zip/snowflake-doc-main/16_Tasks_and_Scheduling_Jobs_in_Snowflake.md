# 📘 Chapter 16: Tasks and Scheduling Jobs in Snowflake
## 🧭 Overview

Automation is a key element in modern data platforms, and **Snowflake Tasks** allow you to schedule SQL statements — including complex data pipelines — directly inside Snowflake without external schedulers.

With Tasks, you can:
- Automate ETL/ELT workflows
- Schedule transformations and data refreshes
- Chain dependent jobs together

Trigger downstream actions using Streams and Tasks

---

## ⚙️ What is a Snowflake Task?

A **Task** is a Snowflake object that executes a **single SQL statement** (like an `INSERT`, `MERGE`, or `CALL` to a stored procedure).
You can schedule it to run periodically or trigger it after another task finishes.

---

## 🏗️ Task Architecture

Each Snowflake Task includes:

**SQL Statement**: The operation to execute
**Schedule or Dependency**: Time-based or task-based trigger
**Warehouse**: Compute resource used for execution
**State**: Whether the task is enabled or suspended

Tasks can form **Directed Acyclic Graphs (DAGs)** to represent dependencies between multiple tasks.

---

## 🧩 Task Components  

| Component     | Description                                              |
| ------------- | -------------------------------------------------------- |
| **WAREHOUSE** | Specifies which virtual warehouse will execute the task. |
| **SCHEDULE**  | CRON or INTERVAL-based timing.                           |
| **WHEN**      | Condition to execute (optional).                         |
| **AFTER**     | Dependency on another task.                              |
| **COMMENT**   | Optional description.                                    |  

---

## 🧱 Creating a Simple Task

```sql
CREATE OR REPLACE TASK refresh_sales_summary
  WAREHOUSE = COMPUTE_WH
  SCHEDULE = 'USING CRON 0 * * * * UTC'  -- Every hour
AS
  INSERT INTO sales_summary
  SELECT region, SUM(amount) AS total_sales
  FROM raw_sales
  WHERE sale_date = CURRENT_DATE()
  GROUP BY region;
```

🟢 **Explanation**:

- The task runs **hourly**.  
- It refreshes a summary table from a raw dataset.  
- Warehouse `COMPUTE_WH` is used to execute the SQL.

---


## ▶️ Enabling and Disabling Tasks

Once created, tasks are initially **suspended**.

```sql
-- Enable a task
ALTER TASK refresh_sales_summary RESUME;

-- Disable a task
ALTER TASK refresh_sales_summary SUSPEND;
```
---

## 🔗 Creating Dependent Tasks (Task Trees)

Snowflake supports **task dependencies**, enabling you to build sequential pipelines.

```sql
CREATE OR REPLACE TASK stage_orders
  WAREHOUSE = COMPUTE_WH
  SCHEDULE = 'USING CRON 0 6 * * * UTC'
AS
  COPY INTO stage.orders
  FROM @orders_stage;

CREATE OR REPLACE TASK transform_orders
  WAREHOUSE = COMPUTE_WH
  AFTER stage_orders
AS
  INSERT INTO analytics.orders_cleaned
  SELECT * FROM stage.orders
  WHERE order_status = 'COMPLETE';
```

Here:
- `transform_orders` runs **after** `stage_orders` completes successfully.  
- This ensures proper data flow between ingestion and transformation.

---


## 🧠 Using Tasks with Stored Procedures

Tasks can call **stored procedures** to handle complex logic:

```sql
CREATE OR REPLACE PROCEDURE process_daily_etl()
RETURNS STRING
LANGUAGE SQL
AS
$$
  INSERT INTO analytics.daily_sales
  SELECT * FROM stage.daily_data WHERE load_date = CURRENT_DATE();
  RETURN 'ETL completed';
$$;

CREATE OR REPLACE TASK run_daily_etl
  WAREHOUSE = ETL_WH
  SCHEDULE = '1 0 * * * UTC'
AS
  CALL process_daily_etl();
```


---

## ⏱️ Scheduling Syntax

Snowflake supports **CRON expressions** and **interval-based schedules**.

**Example 1 — Using CRON:**
```sql
SCHEDULE = 'USING CRON 15 6 * * * UTC'  -- Runs daily at 6:15 AM UTC
```

**Example 2 — Using INTERVAL:**
```sql
SCHEDULE = '1 HOUR'  -- Runs every hour
```

📘 Tip: Snowflake Tasks always use **UTC** for time zone.  


---

## 🔍 Viewing Task History and Status

To monitor task runs:

```sql
SHOW TASKS;

SELECT *
FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY())
WHERE NAME = 'REFRESH_SALES_SUMMARY'
ORDER BY SCHEDULED_TIME DESC;
```

---


## 🧹 Managing and Dropping Tasks

```sql
-- Suspend temporarily
ALTER TASK refresh_sales_summary SUSPEND;

-- Drop the task permanently
DROP TASK IF EXISTS refresh_sales_summary;
```
---

## ⚡ Common Use Cases  

| Use Case                 | Description                                        |
| ------------------------ | -------------------------------------------------- |
| **Daily Summary Tables** | Automate refresh of aggregates.                    |
| **Incremental Loads**    | Schedule ETL pipelines using Streams and Tasks.    |
| **Data Validation**      | Periodically check data quality or schema drift.   |
| **Archival Jobs**        | Move historical data to cheaper storage regularly. |  

---

## 💡 Best Practices

1.**Use Dependency Chains** instead of separate schedules to control sequence.  
2.**Avoid Warehouse Conflicts** — use a dedicated warehouse for automation tasks.  
3.**Monitor Failures** via `TASK_HISTORY` and set up alerts (via external tools).  
4.**Combine with Streams** for event-driven ingestion.  
5.**Test your SQL** manually before embedding in Tasks.  

---

## 🧭 Example: ETL Workflow with Streams + Tasks

```sql
-- Create a stream on a staging table
CREATE OR REPLACE STREAM orders_stream ON TABLE stage.orders;

-- Create a task to process incremental changes
CREATE OR REPLACE TASK process_orders_stream
  WAREHOUSE = ETL_WH
  SCHEDULE = '5 MINUTE'
AS
  MERGE INTO analytics.orders tgt
  USING (SELECT * FROM stage.orders_stream) src
  ON tgt.order_id = src.order_id
  WHEN MATCHED THEN UPDATE SET status = src.status
  WHEN NOT MATCHED THEN INSERT VALUES (src.*);
```


This task runs every 5 minutes and automatically merges new or updated records into the target table.

---

## 🚀 Summary  

| Key Concept     | Description                                          |
| --------------- | ---------------------------------------------------- |
| **Task**        | Executes SQL statements on a schedule or dependency. |
| **Schedule**    | Defines when a task runs (CRON or INTERVAL).         |
| **Dependency**  | Links multiple tasks in a DAG.                       |
| **Monitoring**  | View task runs in `TASK_HISTORY`.                    |
| **Integration** | Combine with Streams or Procedures for automation.   |  




