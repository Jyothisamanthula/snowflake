# Chapter 33: Advanced Auditing, Access History, and Compliance Reporting in Snowflake

## Overview

Snowflake provides **robust auditing** and **access history capabilities** to track all account activity, support regulatory compliance, and enable detailed forensic analysis.  

This chapter explores how to use **Access History, ACCOUNT_USAGE views, and Snowflake-native auditing features** to build compliance dashboards and generate reports for governance, security, and operational teams.

---

## Table of Contents

**1.** Introduction to Auditing in Snowflake  
**2.** Snowflake Access History Overview  
**3.** ACCOUNT_USAGE Views for Auditing  
**4.** Querying Access History  
**5.** User Activity and Login Auditing  
**6.** Object and Role Changes Tracking  
**7.** Data Exfiltration and Sensitive Data Access Reports  
**8.** Hands-On Example: Compliance Reporting Dashboard  
**9.** Integration with External Auditing Tools  
**10.** Best Practices  
**11.** Summary  

---

## 1. Introduction to Auditing in Snowflake

Auditing ensures that **every user action and system event** is recorded and traceable. Snowflake auditing helps organizations:

- Monitor **data access** and modifications
- Meet regulatory compliance (SOC 2, HIPAA, PCI DSS, GDPR)
- Detect **anomalous or unauthorized activity**
- Provide **evidence for audits and reviews**

Snowflake auditing is **always-on** and fully integrated into the platform.  

---

## 2. Snowflake Access History Overview

**Access History** tracks all interactions with **tables, views, and schemas**. It includes:

- Who queried the data
- When the data was accessed
- Which warehouse executed the query
- Client IP and connection method

**Key Points:**

- Available through **Enterprise Edition and above**  
- Provides **granular per-object auditing**  
- Integrates with `ACCOUNT_USAGE` views for long-term storage
  
---

## 3. ACCOUNT_USAGE Views for Auditing

Snowflake provides numerous views in the `SNOWFLAKE.ACCOUNT_USAGE` schema:  

| View                  | Purpose                               |
| --------------------- | ------------------------------------- |
| `QUERY_HISTORY`       | Tracks all queries run in the account |
| `LOGIN_HISTORY`       | Tracks user logins and client IPs     |
| `SESSION_HISTORY`     | Tracks session start/end and duration |
| `ACCESS_HISTORY`      | Tracks object-level access by queries |
| `GRANTS_TO_ROLES`     | Tracks role and privilege assignments |
| `OBJECT_DEPENDENCIES` | Tracks dependencies between objects   |  

---

## 4. Querying Access History  

**Example: Who Accessed a Sensitive Table?**

```sql
SELECT
    query_id,
    user_name,
    role_name,
    warehouse_name,
    query_text,
    start_time
FROM SNOWFLAKE.ACCOUNT_USAGE.ACCESS_HISTORY
WHERE object_name = 'CUSTOMERS'
AND object_domain = 'TABLE'
ORDER BY start_time DESC;
```

✅ This report helps identify **unauthorized or unexpected access**.  


**Example: Access by Role**  

```sql
SELECT
    role_name,
    COUNT(*) AS access_count
FROM SNOWFLAKE.ACCOUNT_USAGE.ACCESS_HISTORY
WHERE object_name = 'PAYROLL'
GROUP BY role_name
ORDER BY access_count DESC;
```
---

## 5. User Activity and Login Auditing

Track user login history and client IP addresses for **security and compliance**.

```sql
SELECT
    event_timestamp,
    user_name,
    client_ip,
    is_success,
    browser_user_agent
FROM SNOWFLAKE.ACCOUNT_USAGE.LOGIN_HISTORY
WHERE event_timestamp >= DATEADD('month', -1, CURRENT_TIMESTAMP())
ORDER BY event_timestamp DESC;
```

✅ Helps detect suspicious logins or anomalies.  

---

## 6. Object and Role Changes Tracking  

Snowflake tracks **changes to roles, grants, and object privileges:**  

```sql
SELECT
    grantee_name,
    privilege,
    granted_on,
    name AS object_name,
    granted_by,
    grant_time
FROM SNOWFLAKE.ACCOUNT_USAGE.GRANTS_TO_ROLES
WHERE granted_on IN ('TABLE','VIEW')
ORDER BY grant_time DESC;
```

This enables you to:

- Audit **privilege escalations**  
- Track **data access changes**  
- Ensure compliance with **least privilege principles**

---

## 7. Data Exfiltration and Sensitive Data Access Reports

To monitor **sensitive data usage**, combine:

- Access History
- Column tags (PII, financial, health)
- Query logs

**Example: Sensitive Data Access**  

```sql
SELECT
    a.query_id,
    a.user_name,
    a.object_name,
    t.tag_name
FROM SNOWFLAKE.ACCOUNT_USAGE.ACCESS_HISTORY a
JOIN SNOWFLAKE.TAG_REFERENCES t
  ON a.object_id = t.object_id
WHERE t.tag_name = 'PII'
ORDER BY a.start_time DESC;
```

✅ Ensures that only authorized users access sensitive information.  

---  

## 8. Hands-On Example: Compliance Reporting Dashboard  

**Step 1: Create a Monitoring Schema**  

```sql
CREATE SCHEMA monitoring;
```

**Step 2: Create Access Summary Table**  

```sql
CREATE OR REPLACE TABLE monitoring.access_summary AS
SELECT
    TO_DATE(start_time) AS access_date,
    user_name,
    role_name,
    object_name,
    COUNT(*) AS access_count
FROM SNOWFLAKE.ACCOUNT_USAGE.ACCESS_HISTORY
WHERE start_time >= DATEADD('month', -1, CURRENT_DATE())
GROUP BY 1,2,3,4;
```

**Step 3: Schedule Daily Updates with a Task**  

```sql
CREATE OR REPLACE TASK task_access_summary
WAREHOUSE = MONITOR_WH
SCHEDULE = 'USING CRON 0 1 * * * UTC'
AS
INSERT INTO monitoring.access_summary
SELECT
    TO_DATE(start_time),
    user_name,
    role_name,
    object_name,
    COUNT(*)
FROM SNOWFLAKE.ACCOUNT_USAGE.ACCESS_HISTORY
WHERE TO_DATE(start_time) = CURRENT_DATE()
GROUP BY 1,2,3,4;
```

**Step 4: Visualize**

Connect the `monitoring.access_summary` table to **Snowsight, Tableau**, or **Power BI** to build a **compliance dashboard** showing:

- Daily user activity
- Role-based access trends
- Sensitive data access frequency

---

## 9. Integration with External Auditing Tools

Snowflake can integrate with third-party platforms for enhanced compliance reporting:  

| Tool                     | Purpose                                  |
| ------------------------ | ---------------------------------------- |
| **Splunk**               | Collect logs and alerts                  |
| **DataDog**              | Monitor usage metrics and anomalies      |
| **Monte Carlo / Bigeye** | Data observability and SLA monitoring    |
| **SIEM Tools**           | Security incident detection and response |  

Integration is typically done using **Snowflake connectors, Snowpipe, or API-based ingestion**.   

---

## 10. Best Practices  

| Category             | Recommendation                                            |
| -------------------- | --------------------------------------------------------- |
| Access History       | Regularly query ACCESS_HISTORY for sensitive tables       |
| Privilege Monitoring | Audit GRANTS_TO_ROLES and role changes weekly             |
| Login Auditing       | Monitor LOGIN_HISTORY for anomalous activity              |
| Sensitive Data       | Tag columns (PII, HIPAA, financial) and audit access      |
| Automation           | Use TASKS to automate daily or weekly compliance reports  |
| External Tools       | Integrate with SIEM or observability platforms for alerts |  

---

## 11. Summary

- Snowflake provides **comprehensive auditing capabilities** via `ACCOUNT_USAGE`, `ACCESS_HISTORY`, and `LOGIN_HISTORY`.
- You can track **user activity, object access, role changes, and sensitive data usage**.
- **Automated dashboards and Tasks** allow for continuous monitoring.
- Integration with **external observability tools** ensures enterprise compliance readiness.
