# Chapter 10: Snowflake Data Types

Understanding how Snowflake stores and interprets data is essential for designing efficient schemas and writing accurate queries. This chapter explores all data types—structured, semi-structured, and specialized—with practical code examples.

## 10.1 Overview

- Snowflake provides a rich set of data types that support:  
- Traditional structured data (numbers, strings, dates, booleans)  
- Semi-structured data (JSON, Avro, Parquet, ORC via VARIANT, OBJECT, ARRAY)  
- Specialized data (binary, geography, etc.)

Every column in a Snowflake table has a defined data type, which determines how the system:  
- Stores data  
- Interprets values  
- Performs calculations and comparisons
---

## 10.2 Numeric Data Types

Snowflake supports multiple numeric types for integers, decimals, and floating-point numbers.  

| **Type**                                                          | **Alias**            | **Description**                                      | **Example**    |
| ----------------------------------------------------------------- | -------------------- | ---------------------------------------------------- | -------------- |
| `NUMBER(p, s)`                                                    | `DECIMAL`, `NUMERIC` | Fixed-point number with precision `p` and scale `s`. | `NUMBER(10,2)` |
| `INT`, `INTEGER`, `BIGINT`, `SMALLINT`, `TINYINT`, `BYTEINT`      | —                    | Integer types (aliases of `NUMBER` with zero scale). | `INTEGER`      |
| `FLOAT`, `FLOAT4`, `FLOAT8`, `DOUBLE`, `DOUBLE PRECISION`, `REAL` | —                    | Floating-point numbers (approximate precision).      | `FLOAT`        |  

Example:
```sql
CREATE OR REPLACE TABLE NUMERIC_EXAMPLE (
    order_id INT,
    price NUMBER(10,2),
    tax_rate FLOAT
);

INSERT INTO NUMERIC_EXAMPLE VALUES 
(1001, 1250.50, 0.18),
(1002, 850.75, 0.15);  
```

---
## 10.3 String Data Types  

| **Type**                              | **Description**                                     | **Example**   |
| ------------------------------------- | --------------------------------------------------- | ------------- |
| `VARCHAR`                             | Variable-length string (up to 16 MB).               | `'Snowflake'` |
| `CHAR`, `CHARACTER`, `STRING`, `TEXT` | Fixed or variable-length string aliases.            | `'Data'`      |
| `BINARY`                              | Stores raw bytes; used for files or encrypted data. | `BINARY` data |  

Example:
```sql
CREATE OR REPLACE TABLE STRING_EXAMPLE (
    username VARCHAR(50),
    description STRING,
    photo_data BINARY
);

INSERT INTO STRING_EXAMPLE (username, description)
VALUES ('VENKAT', 'Snowflake learner');  
```
---
## 10.4 Date and Time Data Types  

| **Type**        | **Description**                    | **Example**                    |
| --------------- | ---------------------------------- | ------------------------------ |
| `DATE`          | Stores date (YYYY-MM-DD).          | `'2025-10-13'`                 |
| `TIME`          | Stores time of day.                | `'14:35:00'`                   |
| `TIMESTAMP_NTZ` | Timestamp (no time zone).          | `'2025-10-13 12:30:00'`        |
| `TIMESTAMP_LTZ` | Timestamp with local time zone.    | `'2025-10-13 12:30:00 +05:30'` |
| `TIMESTAMP_TZ`  | Timestamp with explicit time zone. | `'2025-10-13 12:30:00 UTC'`    |  

Example:
```sql
CREATE OR REPLACE TABLE TIME_EXAMPLE (
    created_on TIMESTAMP_NTZ,
    updated_on TIMESTAMP_LTZ
);

INSERT INTO TIME_EXAMPLE 
VALUES (CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());
```
---
## 10.5 Boolean Data Type

Represents logical **TRUE** or **FALSE** values.

Useful for filters and flags.

```sql
CREATE OR REPLACE TABLE BOOLEAN_EXAMPLE (
    user_id INT,
    is_active BOOLEAN
);


INSERT INTO BOOLEAN_EXAMPLE VALUES (1, TRUE), (2, FALSE);
```
---

## 10.6 Semi-Structured Data Types

Snowflake natively supports JSON, Avro, Parquet, and ORC using special types:

`VARIANT` → Stores semi-structured data (like JSON)  
`OBJECT` → Key-value pairs  
`ARRAY` → Ordered list of elements  


Example: Working with JSON data

```sql
CREATE OR REPLACE TABLE SEMI_EXAMPLE (data VARIANT);

INSERT INTO SEMI_EXAMPLE 
SELECT PARSE_JSON('{"name":"Venkat","skills":["SQL","Snowflake","Python"]}');

SELECT 
    data:name::STRING AS name,
    data:skills[0]::STRING AS first_skill
FROM SEMI_EXAMPLE;
```

✅ Output:  
| name   | first_skill |
| ------ | ----------- |
| Venkat | SQL         |    
---

## 10.7 Geography Data Type

The GEOGRAPHY type stores geospatial data such as:
- Points  
- Lines
- Polygons

Example:
```sql
CREATE OR REPLACE TABLE GEO_EXAMPLE (location GEOGRAPHY);

INSERT INTO GEO_EXAMPLE 
VALUES (TO_GEOGRAPHY('POINT(-122.4194 37.7749)'));

SELECT ST_ASWKT(location) AS wkt_representation FROM GEO_EXAMPLE;
```

✅ Output:

POINT (-122.4194 37.7749)

---  

## 10.8 Data Type Conversion

Snowflake supports explicit and implicit data type conversions.

**Explicit Cast:**
```sql
SELECT CAST('123.45' AS NUMBER(5,2));
```
**Implicit Conversion:**

```sql
SELECT '100' + 50;  -- Snowflake automatically converts string to number
```
---
## 10.9 Best Practices

✅ Choose the right data type:

Use precise types (NUMBER(10,2)) instead of generic (FLOAT).

✅ Leverage VARIANT for flexibility:

Especially useful when working with evolving JSON schemas.

✅ Use DATE/TIMESTAMP with time zones when integrating global data.

✅ Avoid unnecessary conversions — they can slow down queries. 

---

## 10.10 Summary  

| **Category**    | **Common Types**             | **Use Case**                   |
| --------------- | ---------------------------- | ------------------------------ |
| Numeric         | `NUMBER`, `FLOAT`, `INT`     | Financial or calculated values |
| String          | `VARCHAR`, `STRING`          | Names, descriptions            |
| Date/Time       | `DATE`, `TIMESTAMP_LTZ`      | Timestamps, logging            |
| Boolean         | `BOOLEAN`                    | Flags, status                  |
| Semi-structured | `VARIANT`, `OBJECT`, `ARRAY` | JSON, logs, metadata           |
| Specialized     | `BINARY`, `GEOGRAPHY`        | Raw data, geo coordinates      |  

✅ Key Takeaways

- Snowflake provides rich and flexible data types for both structured and semi-structured data.  
- Always define explicit precision and scale for numeric fields.  
- Use VARIANT for JSON and dynamic data.  
- Ensure data type consistency between staging and target tables to prevent load failures.
  

 

