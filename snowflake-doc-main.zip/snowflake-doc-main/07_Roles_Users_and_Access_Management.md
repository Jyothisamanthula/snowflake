# 🛡️ Chapter 7: Roles, Users, and Access Management

---

## 7.1 Objective

In this chapter, you’ll learn:
- Snowflake’s **Role-Based Access Control (RBAC)** model  
- How to create and manage **users, roles, and privileges**  
- Hierarchical role structures  
- Security best practices for enterprise environments  

---

## 7.2 Overview of Access Management

Snowflake uses a **role-based security model**.  
Permissions are granted to **roles**, and **roles are assigned to users** — not directly to objects.


🔹 This design makes it easy to manage permissions for large teams.

---

## 7.3 Key Snowflake Entities

| Entity | Description |
|---------|--------------|
| **User** | An individual account that connects to Snowflake |
| **Role** | A collection of privileges that define what users can do |
| **Privilege** | The specific access right (e.g., SELECT, INSERT) |
| **Object** | Any Snowflake entity (database, schema, table, warehouse) |

---

## 7.4 Default Roles

When you sign up for Snowflake, you get several **system-defined roles**.

| Role | Description |
|------|--------------|
| **ACCOUNTADMIN** | Has full control of the Snowflake account |
| **SECURITYADMIN** | Manages roles and grants |
| **USERADMIN** | Creates users and assigns roles |
| **SYSADMIN** | Creates databases, schemas, and warehouses |
| **PUBLIC** | Default role for all users with minimal privileges |

✅ **Best Practice:**  
Use `SYSADMIN` for object creation and `ACCOUNTADMIN` only for administrative operations.

---

## 7.5 Viewing Current Role and Privileges

```sql
-- View current role
SELECT CURRENT_ROLE();

-- View all available roles
SHOW ROLES;
-- Show current grants
SHOW GRANTS TO ROLE SYSADMIN;
```
Example Output:
```pgsql
+---------------+---------------+--------------------+
| CREATED_ON    | ROLE          | GRANTED_TO         |
+---------------+---------------+--------------------+
| 2025-10-10    | SYSADMIN      | ACCOUNTADMIN       |
+---------------+---------------+--------------------+
```
---
## 7.6 Creating and Managing Roles

**Create a New Role**
```sql
CREATE ROLE ANALYST_ROLE COMMENT = 'Read-only access to analytical tables';
```

**Assign Privileges to Role**
```sql
GRANT USAGE ON DATABASE DEMO_DB TO ROLE ANALYST_ROLE;
GRANT USAGE ON SCHEMA DEMO_DB.PUBLIC TO ROLE ANALYST_ROLE;
GRANT SELECT ON ALL TABLES IN SCHEMA DEMO_DB.PUBLIC TO ROLE ANALYST_ROLE;
```
**Assign Role to User**
```sql
GRANT ROLE ANALYST_ROLE TO USER JOHN_DOE;
```
**Verify Grants**
```sql
SHOW GRANTS TO ROLE ANALYST_ROLE;
```
---
## 7.7 Creating and Managing Users
**Create a User**

```sql
CREATE USER JOHN_DOE
  PASSWORD = 'StrongPass#123'
  DEFAULT_ROLE = ANALYST_ROLE
  MUST_CHANGE_PASSWORD = TRUE
  COMMENT = 'Business analyst for Finance department';
```
**Modify a User**
```sql
ALTER USER JOHN_DOE SET DEFAULT_WAREHOUSE = WH_TRAINING;
```
**Drop a User**
```sql
DROP USER IF EXISTS JOHN_DOE;
```
**List All Users**
```sql
SHOW USERS;
```
---
## 7.8 Assigning Multiple Roles to a User

A single user can have **multiple roles**, but only one can be **active** at a time.

```sql
GRANT ROLE DATA_ENGINEER_ROLE TO USER JOHN_DOE;
GRANT ROLE ANALYST_ROLE TO USER JOHN_DOE;

-- Switch active role
USE ROLE ANALYST_ROLE;
```

✅ To list all roles assigned to your user:

```sql
SHOW GRANTS TO USER JOHN_DOE;
```


## 7.9 Role Hierarchy

Roles can inherit privileges from other roles — forming a hierarchy.

```markdown
ACCOUNTADMIN
   ├── SECURITYADMIN
   │      ├── USERADMIN
   └── SYSADMIN
          └── CUSTOM_ROLES (e.g., DATA_ENGINEER_ROLE, ANALYST_ROLE)
```

**Example: Create a Custom Hierarchy**
```sql
CREATE ROLE DATA_ENGINEER_ROLE;
CREATE ROLE DATA_LEAD_ROLE;

-- Assign hierarchy
GRANT ROLE DATA_ENGINEER_ROLE TO ROLE DATA_LEAD_ROLE;
GRANT ROLE DATA_LEAD_ROLE TO ROLE SYSADMIN;
```
**Verify**
```sql
SHOW GRANTS TO ROLE DATA_LEAD_ROLE;
```
---
## 7.10 Granting Privileges on Objects

| Object Type   | Example Privileges             |
| ------------- | ------------------------------ |
| **Database**  | CREATE SCHEMA, USAGE           |
| **Schema**    | CREATE TABLE, USAGE            |
| **Table**     | SELECT, INSERT, UPDATE, DELETE |
| **Warehouse** | USAGE, MONITOR, OPERATE        |

Example:

```sql
GRANT SELECT, INSERT ON TABLE DEMO_DB.PUBLIC.SALES TO ROLE DATA_ENGINEER_ROLE;
```

Revoke privilege:

```sql
REVOKE INSERT ON TABLE DEMO_DB.PUBLIC.SALES FROM ROLE ANALYST_ROLE;
````

## 7.11 Managing Role Grants and Revokes
**View All Grants**
```sql
SHOW GRANTS;
```
**View Grants to a Specific Role**
```sql
SHOW GRANTS TO ROLE SYSADMIN;
```
**Revoke Role**
```sql
REVOKE ROLE ANALYST_ROLE FROM USER JOHN_DOE;
```
## 7.12 Best Practices for Role and Access Management

✅ **1.** Use role hierarchy — Avoid granting privileges directly to users.  
✅ **2.** Apply least privilege principle — Grant only required access.  
✅ **3.** Separate environments — Different roles for DEV, UAT, and PROD.  
✅ **4.** Use custom roles for teams (e.g., ETL_ROLE, ANALYST_ROLE).  
✅ **5.** Regularly audit roles and privileges using ACCOUNT_USAGE views.  

Example Audit Query:
```sql
SELECT *
FROM SNOWFLAKE.ACCOUNT_USAGE.GRANTS_TO_ROLES
WHERE ROLE_NAME LIKE '%ADMIN%'
ORDER BY CREATED_ON DESC;
```
---
## 7.13 Real-World Example: Department-Based Roles

| Department      | Role Name    | Privileges                       |
| --------------- | ------------ | -------------------------------- |
| **Finance**     | FIN_ROLE     | SELECT, INSERT on Finance schema |
| **Analytics**   | ANALYST_ROLE | SELECT only                      |
| **Engineering** | ENG_ROLE     | CREATE TABLES, RUN ETL           |
| **Security**    | SEC_ROLE     | MANAGE USERS & ROLES             |  

Implementation Example:

```sql
CREATE ROLE FIN_ROLE;
GRANT USAGE ON SCHEMA DEMO_DB.FINANCE TO ROLE FIN_ROLE;
GRANT SELECT, INSERT ON ALL TABLES IN SCHEMA DEMO_DB.FINANCE TO ROLE FIN_ROLE;
GRANT ROLE FIN_ROLE TO USER FIN_USER;
```
---
## 7.14 Resetting Roles and Privileges

If roles or grants become inconsistent, reset them:

```sql
REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA DEMO_DB.PUBLIC FROM ROLE ANALYST_ROLE;
REVOKE ROLE ANALYST_ROLE FROM USER JOHN_DOE;
DROP ROLE ANALYST_ROLE;
```

Then recreate cleanly.

## 7.15 Visual Summary

```pgsql
+-------------------+
|   ACCOUNTADMIN    |
+---------+---------+
          |
   +------+------+
   |  SECURITYADMIN |
   |     (creates users, roles) |
   +------+------+
          |
   +------+------+
   |   SYSADMIN   |
   | (creates DBs, schemas, tables) |
   +------+------+
          |
   +------+------+
   |  CUSTOM ROLES |
   | (DATA_ENGINEER, ANALYST, etc.) |
   +-------------+

```

## 7.16 Summary

✅ You learned:

 - The RBAC model and hierarchy in Snowflake

- How to create and manage users, roles, and privileges

- Real-world examples of enterprise role design

- Best practices for secure access control
