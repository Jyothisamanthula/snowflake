# 📘 Chapter 21: Time Travel and Data Recovery

## 🎯 Chapter Overview

Snowflake’s **Time Travel** feature allows users to **query**, **clone**, and **restore data from historical points in time**, providing a safety net for accidental data loss or corruption.

Combined with **Fail-safe**, Snowflake ensures high durability, traceability, and recoverability for enterprise-grade systems.

In this chapter, we will cover:

- Understanding Time Travel  
- Retention periods and limits    
- Querying historical data  
- Restoring dropped tables or schemas    
- Cloning with Time Travel  
- Fail-safe and data recovery options  
- Hands-on mini project with HR dataset    

---

## 📖 Table of Contents

**1.** What is Time Travel?  
**2.** Snowflake Data Retention Periods    
**3.** Querying Historical Data  
**4.** Undropping and Restoring Tables  
**5.** Zero-Copy Cloning with Time Travel    
**6.** Fail-Safe and Data Durability  
**7.** Hands-On Project: Recover Deleted HR Data    
**8.** Best Practices and Cost Considerations  
**9.** Summary  

---

## 1️⃣ What is Time Travel?

Time Travel enables you to **access historical versions of data** (tables, schemas, or databases) for a defined period — up to **90 days** depending on your Snowflake edition.

You can:

- Query old versions of tables.  
- Restore accidentally dropped objects.  
- Clone tables or schemas from a specific timestamp.  
- Recreate deleted data without restoring backups manually.  

---

## 2️⃣ Snowflake Data Retention Periods  

| Edition                             | Retention Period |
| ----------------------------------- | ---------------- |
| Standard / Enterprise               | Up to 1 day      |
| Business Critical                   | Up to 7 days     |
| Enterprise for Sensitive Data (ESD) | Up to 90 days    |  


You can **set retention** period during or after table creation.

```sql
CREATE OR REPLACE TABLE sales_data (
  id INT, amount NUMBER, region STRING
)
DATA_RETENTION_TIME_IN_DAYS = 7;
```


Modify retention later:

```sql
ALTER TABLE sales_data SET DATA_RETENTION_TIME_IN_DAYS = 3;
```
---

## 3️⃣ Querying Historical Data

Snowflake supports **SELECT queries at specific points in time** using these clauses:

- **AT | BEFORE** keyword  
- Use **timestamp**, **offset (seconds)**, or **statement ID**

**Example 1 — Using Timestamp**

```sql

SELECT * FROM sales_data AT (TIMESTAMP => '2025-10-13 10:00:00');
```

**Example 2 — Using Offset**

```sql

SELECT * FROM sales_data BEFORE (OFFSET => -3600);
```

(Shows data from one hour ago)

**Example 3 — Using Statement ID**

```sql
SELECT * FROM sales_data BEFORE (STATEMENT => '01ae01a6-0000-8f51-0000-43f0004c0d16');
```

🔍 Useful for undoing mistakes — e.g., an accidental delete or update.

---

## 4️⃣ Undropping and Restoring Tables

When a table, schema, or database is dropped, it’s still available within the **Time Travel retention period**.

**Restore Dropped Table**

```sql
UNDROP TABLE sales_data;
```

**Restore Dropped Schema**

```sql
UNDROP SCHEMA finance_schema;
```

**Restore Dropped Database**

```sql
UNDROP DATABASE analytics_db;
```


⚠️ Note:
After the retention period expires, the object enters **Fail-safe**, where only Snowflake support can restore it.  

---

## 5️⃣ Zero-Copy Cloning with Time Travel

Time Travel also powers **Zero-Copy Cloning** — a way to create instant copies of tables or databases from a specific point in time.

```sql
CREATE OR REPLACE TABLE sales_clone
CLONE sales_data AT (TIMESTAMP => '2025-10-13 09:00:00');
```

Or clone before a destructive change:

```sql
CREATE TABLE backup_sales CLONE sales_data BEFORE (STATEMENT => '01ae01a6-0000-8f51-0000-43f0004c0d16');
```

✅ Cloning is **metadata-only**, so it’s fast and space-efficient.  
It’s ideal for **sandbox testing**, **point-in-time analysis**, or **data audit trails**.

---

## 6️⃣ Fail-Safe and Data Durability

**Fail-safe** is a **7-day read-only period** that begins **after the Time Travel period expires**.  
It’s designed for **Snowflake-managed** recovery only — customers can’t directly access it.  

| Phase           | Duration  | Access Type | Purpose               |
| --------------- | --------- | ----------- | --------------------- |
| **Time Travel** | 1–90 days | Customer    | Query, clone, restore |
| **Fail-safe**   | 7 days    | Snowflake   | Recovery support      |  

📘 Example Timeline:

```sql
Retention: 3 days
Fail-safe: +7 days

→ Day 0: Data dropped
→ Day 0–3: Customer can UNDROP / CLONE
→ Day 4–10: Snowflake can recover (Fail-safe)
```
---

## 7️⃣ Hands-On Mini Project: Recover Deleted HR Data

**🎯 Objective**

Demonstrate Time Travel by accidentally deleting and restoring employee data.

**Step 1 — Create and Load Table**

```sql
CREATE OR REPLACE TABLE hr_employees (
  emp_id STRING,
  emp_name STRING,
  salary NUMBER,
  department STRING
)
DATA_RETENTION_TIME_IN_DAYS = 2;

INSERT INTO hr_employees VALUES
('E001', 'Venkat', 90000, 'Finance'),
('E002', 'Asha', 85000, 'HR'),
('E003', 'Ravi', 70000, 'IT');
```

**Step 2 — Verify Data**

```sql
SELECT * FROM hr_employees;
```

**Step 3 — Accidental Delete**

```sql
DELETE FROM hr_employees WHERE department = 'Finance';
```

Oops! 😨 We deleted a record.


**Step 4 — Recover Using Time Travel**

```sql
-- View table before deletion
SELECT * FROM hr_employees BEFORE (STATEMENT => LAST_QUERY_ID());
```

**Step 5 — Restore Data with Clone**

```sql
CREATE OR REPLACE TABLE hr_restore CLONE hr_employees BEFORE (STATEMENT => LAST_QUERY_ID());
```

**Step 6 — Verify Restoration**

```sql
SELECT * FROM hr_restore;
```


✅ The deleted data is now restored successfully.  

---

## 8️⃣ Best Practices and Cost Considerations

🔹 Use **Time Travel** for **accidental recovery** and **historical analysis**, not as a backup solution.  
🔹 Longer retention → higher storage cost (based on historical data changes).  
🔹 Apply shorter retention to transient or temporary tables:  

```sql
CREATE TRANSIENT TABLE temp_sales (...) DATA_RETENTION_TIME_IN_DAYS = 0;
```

🔹 Monitor retention using:  

```sql
SHOW PARAMETERS LIKE 'DATA_RETENTION_TIME_IN_DAYS' IN TABLE sales_data;
```

🔹 Use cloning before risky operations (e.g., large delete/update).  
🔹 For compliance-critical tables, use **90-day retention** and **Fail-safe** as a backup safety net.  

---

## 🧠 Summary  

| Feature               | Description                                          |
| --------------------- | ---------------------------------------------------- |
| **Time Travel**       | Query and restore data from a historical point       |
| **Retention Period**  | 1–90 days depending on edition                       |
| **Fail-safe**         | 7-day Snowflake-managed recovery                     |
| **Zero-Copy Cloning** | Create point-in-time copies instantly                |
| **Key Use Cases**     | Undo deletes, audit, restore tables, sandbox testing |

---

## 🔑 Key Takeaways

- Time Travel allows **point-in-time** recovery without backup scripts.  
- Fail-safe provides a **final layer of recovery** managed by Snowflake.  
- Combine Time Travel with **cloning** for instant data restoration.  
- Shorten retention for transient datasets to reduce cost.  
- Always **test and validate recovery strategy** in your environment.  
