# Chapter 29: Monitoring, Logging, and Cost Optimization in Snowflake  

## 29.1 Overview

As your Snowflake environment scales, **monitoring and cost optimization** become critical to ensure reliability, efficiency, and predictable spend.
Snowflake provides a rich set of **system views, usage history tables, query profiling tools**, and **resource monitors** for fine-grained visibility.

In this chapter, we’ll explore:

- Monitoring query performance and resource usage
- Logging user and system activity
- Setting up resource monitors
- Optimizing compute, storage, and query design for cost savings

---

## 29.2 Monitoring Snowflake System Activity

Snowflake’s **ACCOUNT_USAGE** and **INFORMATION_SCHEMA** views contain detailed metadata about:  
- Queries
- Warehouses
- Storage
- Users
- Billing and credit usage  

**Key Monitoring Views**  

| View                                                 | Description                               |
| ---------------------------------------------------- | ----------------------------------------- |
| `SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY`              | Lists all queries executed in the account |
| `SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY` | Shows credit usage per warehouse          |
| `SNOWFLAKE.ACCOUNT_USAGE.LOGIN_HISTORY`              | Tracks user logins and client types       |
| `SNOWFLAKE.ACCOUNT_USAGE.SESSION_HISTORY`            | Captures session details                  |
| `SNOWFLAKE.ACCOUNT_USAGE.METERING_HISTORY`           | Provides credit consumption by category   |  

---

**Example: Identify Long-Running Queries** 

```sql
SELECT
    query_id,
    user_name,
    warehouse_name,
    execution_status,
    total_elapsed_time/1000 AS duration_seconds,
    start_time
FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
WHERE total_elapsed_time > 300000  -- >5 minutes
ORDER BY duration_seconds DESC;
```

**Example: Top Resource-Consuming Warehouses**  

```sql
SELECT
    warehouse_name,
    SUM(credits_used) AS total_credits,
    SUM(credits_used)*CREDIT_COST_USD AS cost_usd
FROM SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY
WHERE start_time >= DATEADD('day', -30, CURRENT_TIMESTAMP())
GROUP BY warehouse_name
ORDER BY total_credits DESC;
```
---

## 29.3 Query Profile and Query Execution Plans

Snowflake’s **Query Profile** (in the web UI or via Snowsight) helps visualize:

- Execution steps
- Data scanned vs returned
- Bottlenecks and pruning efficiency

**Tips for Using Query Profile**  

- Watch for **large scan volumes** — optimize clustering or micro-partitions.
- Check **“Spill to Remote Storage”** — indicates insufficient memory.
- Review **JOIN order** and **filter pushdown** effectiveness.

You can access the query profile with:

```sql
SELECT SYSTEM$GET_QUERY_HISTORY('<query_id>');
```
---

## 29.4 Logging and Auditing  

Snowflake provides native logging for:

- User activity
- Session usage
- Data access events
- Role and privilege changes

**Example: Login Tracking**

```sql
SELECT
    event_timestamp,
    user_name,
    client_ip,
    is_success
FROM SNOWFLAKE.ACCOUNT_USAGE.LOGIN_HISTORY
ORDER BY event_timestamp DESC;
```

**Example: Role Privilege Audit**

```sql
SELECT
    grantee_name,
    privilege,
    granted_on,
    name AS object_name,
    granted_by
FROM SNOWFLAKE.ACCOUNT_USAGE.GRANTS_TO_ROLES
WHERE privilege IN ('SELECT', 'USAGE');
```

These logs support **compliance, forensics,** and **governance reporting**.  

---

## 29.5 Resource Monitors — Prevent Overspending

Resource monitors allow you to set **credit usage thresholds** for warehouses or accounts.  

**Create a Resource Monitor**  

```sql
CREATE OR REPLACE RESOURCE MONITOR monitor_wh
WITH CREDIT_QUOTA = 500
TRIGGERS ON 80 PERCENT DO NOTIFY
          ON 100 PERCENT DO SUSPEND
          ON 110 PERCENT DO SUSPEND_IMMEDIATE;
```

**Assign to a Warehouse**  

```sql
ALTER WAREHOUSE compute_wh
SET RESOURCE_MONITOR = monitor_wh;
```


This automatically **notifies or suspends** a warehouse when usage exceeds thresholds — protecting you from runaway costs.  

--- 

## 29.6 Cost Optimization Strategies

Snowflake’s pay-per-use model offers flexibility but requires planning.  
Let’s look at key **optimization levers** for compute, storage, and query design.

**1️⃣ Compute Optimization**  

✅ Use Auto-Suspend and Auto-Resume

```sql
ALTER WAREHOUSE compute_wh
SET AUTO_SUSPEND = 60  -- seconds
    AUTO_RESUME = TRUE;
```

Suspends the warehouse after 60 seconds of inactivity — no credits consumed while idle.

✅ Use Appropriate Warehouse Sizes

- Start small and scale up dynamically.  
- Use **multi-cluster warehouses** only when concurrent workloads demand it.  

✅ Monitor Query Concurrency

- Use **Warehouse Load Graphs** to identify queuing.  
- Consider **separate warehouses** for ETL vs BI workloads.  

**2️⃣ Storage Optimization**

- Use **Time Travel retention** carefully (default 1 day; can increase to 90 days).  
- Periodically **drop unused transient or temp tables**.  
- Leverage **storage integrations** with S3, GCS, or Azure Blob for archiving.

```sql
ALTER DATABASE mydb SET DATA_RETENTION_TIME_IN_DAYS = 3;
```

**3️⃣ Query Optimization**

- Use **clustering keys** to improve partition pruning.  
- Avoid `SELECT *`; query only required columns.  
- Use **materialized views** for pre-computation of frequent queries.  
- Periodically **recluster** large tables.  

```sql
ALTER TABLE sales RECLUSTER;  
```

---

## 29.7 Monitoring Snowflake Costs with Snowsight and SQL

Snowflake’s **Snowsight UI** provides built-in cost dashboards:  

- Credit usage per warehouse  
- Storage cost by database  
- Query performance insights  
- Role-based access monitoring  

Alternatively, build a custom **billing dashboard**:  

```sql
SELECT
    TO_DATE(start_time) AS usage_date,
    warehouse_name,
    SUM(credits_used) AS total_credits,
    SUM(credits_used) * CREDIT_COST_USD AS estimated_cost
FROM SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY
WHERE start_time >= DATEADD('day', -30, CURRENT_TIMESTAMP())
GROUP BY 1, 2
ORDER BY usage_date;
```
---

## 29.8 Automating Cost Alerts

You can automate cost alerts using:

- **Snowflake Tasks + Email integrations** (via external functions)  
- **Resource Monitors**  
- **Third-party observability tools** (e.g., DataDog, Prometheus, or Sigma)
  
**Example: Notify Admin via External Function**  

```sql
CREATE OR REPLACE TASK notify_cost_overrun
WAREHOUSE = compute_wh
SCHEDULE = 'USING CRON 0 8 * * * UTC'
AS
CALL send_email_if_cost_exceeds_threshold();
```  

Combine with **AWS Lambda** or **Azure Function** for automated alerts.  

---

## 29.9 Building a Cost & Performance Dashboard (Hands-On)
Objective

Create a Snowflake dashboard that shows:

- Daily credit usage  
- Query performance by user  
- Warehouse utilization trend  

**Steps**

1️⃣ Create a Reporting Schema

```sql
CREATE SCHEMA monitoring;
```  

2️⃣ Create a Reporting Table  

```sql
CREATE OR REPLACE TABLE monitoring.daily_cost_summary AS
SELECT
    TO_DATE(start_time) AS usage_date,
    warehouse_name,
    SUM(credits_used) AS total_credits
FROM SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY
GROUP BY 1, 2;
```  

3️⃣ Automate with a Task

```sql
CREATE OR REPLACE TASK task_refresh_cost_summary
SCHEDULE = 'USING CRON 0 0 * * * UTC'
AS
INSERT INTO monitoring.daily_cost_summary
SELECT
    TO_DATE(start_time),
    warehouse_name,
    SUM(credits_used)
FROM SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY
WHERE TO_DATE(start_time) = CURRENT_DATE()
GROUP BY 1, 2;
```  

4️⃣ Visualize in **Snowsight** or **Tableau/Power BI**.

---

## 29.10 Best Practices      

| Category       | Best Practice                                     |
| -------------- | ------------------------------------------------- |
| **Compute**    | Use auto-suspend/resume and right-size warehouses |
| **Storage**    | Limit Time Travel and clean up transient data     |
| **Queries**    | Review Query Profile and avoid inefficient joins  |
| **Monitoring** | Use ACCOUNT_USAGE and TASK_HISTORY views          |
| **Governance** | Implement Resource Monitors and alerts            |
| **Automation** | Schedule reports and anomaly detection tasks      |  

---


## 29.11 Summary

- Snowflake provides **native monitoring and auditing** via `ACCOUNT_USAGE` and `INFORMATION_SCHEMA`.  
- **Resource Monitors** protect against credit overuse.  
- Regularly **analyze Query History** for slow or costly operations.  
- Optimize warehouses, storage, and SQL design for sustainable performance.  
- Use **Tasks** and **External Functions** for proactive alerting and governance.  
