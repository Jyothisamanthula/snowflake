# 📘 Chapter 1: Introduction to Snowflake

---

## 1.1 What Is Snowflake?

**Snowflake** is a fully managed, cloud-native **data warehousing platform** that allows you to store, process, and analyze massive volumes of data—both structured and semi-structured—without managing infrastructure.

Snowflake combines the performance of a traditional data warehouse with the flexibility of the cloud.

**Key ideas**

- **Elastic compute** via *Virtual Warehouses*  
- **Centralized, scalable storage** on AWS / Azure / GCP  
- **Automatic optimization** and **pay-per-use pricing**  
- **Zero maintenance**—no servers, clusters, or indexes to manage  

---

## 1.2 Why Snowflake Exists

Traditional data warehouses were built for on-prem environments, making them expensive to scale and hard to maintain.  
Snowflake was designed to overcome these challenges by separating **compute** from **storage** and delivering the entire stack as a **cloud service (SaaS)**.

---

## 1.3 Key Features

| Feature | Description |
|----------|--------------|
| **Separation of Compute and Storage** | Scale compute independently of storage. |
| **Multi-Cluster Architecture** | Run multiple workloads without contention. |
| **Zero-Copy Cloning** | Instantly duplicate databases / tables without extra storage. |
| **Time Travel** | Query historical data up to 90 days back. |
| **Secure Data Sharing** | Share live data across accounts without copying. |
| **Automatic Scaling** | Warehouses auto-scale based on demand. |
| **Semi-Structured Support** | Natively query JSON, Parquet, Avro, XML. |
| **Cross-Cloud Availability** | Operates on AWS, Azure, and GCP. |

---

## 1.4 Evolution of Data Warehousing

| Generation | Characteristics | Examples |
|-------------|-----------------|-----------|
| **1st Gen (On-Prem)** | Fixed hardware, costly, limited scale | Oracle DW, Teradata |
| **2nd Gen (Cloud-Hosted)** | Managed but still static | AWS Redshift, early BigQuery |
| **3rd Gen (Cloud-Native)** | Elastic, pay-per-use, serverless | **Snowflake** |

Snowflake represents the *third generation* of modern data platforms—fully cloud-native, elastic, and self-optimizing.

---

## 1.5 Snowflake Architecture Overview

Snowflake is composed of **three logical layers**:

1. **Database Storage Layer** – Stores compressed, encrypted data in cloud storage.  
2. **Compute Layer (Virtual Warehouses)** – Executes queries and transformations.  
3. **Cloud Services Layer** – Handles authentication, metadata, optimization, and security.
---
| Layer | Description |
|--------|-------------|
| **Cloud Services** | Authentication, Metadata, Optimizer |
| **Compute (Virtual Warehouses)** | Multi-cluster query processing |
| **Database Storage Layer** | Secure, compressed data on cloud |



Each layer operates independently, enabling true elasticity.

---

## 1.6 How Snowflake Differs from Traditional Systems

| Aspect | Traditional DW | Snowflake |
|---------|----------------|------------|
| **Infrastructure** | On-prem / static VMs | Fully managed SaaS |
| **Scaling** | Manual, downtime required | Automatic / instant |
| **Data Sharing** | File exports | Secure live sharing |
| **Maintenance** | Manual patches & tuning | Zero maintenance |
| **Cost Model** | Fixed hardware | Pay-as-you-go |
| **Performance Tuning** | Indexes, partitions | Self-optimizing |

---

## 1.7 Summary of Data Types

Snowflake handles multiple data categories.  
Snowflake supports most standard SQL data types.  
The following table summarizes the supported categories, types, and notes:

| **Category** | **Type(s)** | **Notes** |
|---------------|-------------|------------|
| **Numeric Data Types** | `NUMBER` | Default precision and scale are (38,0). |
|  | `DECIMAL`, `NUMERIC` | Synonymous with `NUMBER`. |
|  | `INT`, `INTEGER`, `BIGINT`, `SMALLINT`, `TINYINT`, `BYTEINT` | Synonymous with `NUMBER`, except precision and scale can’t be specified. |
|  | `FLOAT`, `FLOAT4`, `FLOAT8` | [1] |
|  | `DOUBLE`, `DOUBLE PRECISION`, `REAL` | Synonymous with `FLOAT`. [1] |
| **String & Binary Data Types** | `VARCHAR` | Default length is 16,777,216 bytes. Maximum length is 134,217,728 bytes. |
|  | `CHAR`, `CHARACTER` | Synonymous with `VARCHAR`, but default length is `VARCHAR(1)`. |
|  | `STRING`, `TEXT` | Synonymous with `VARCHAR`. |
|  | `BINARY`, `VARBINARY` | `VARBINARY` is synonymous with `BINARY`. |
| **Logical Data Types** | `BOOLEAN` | Supported for accounts provisioned after Jan 25, 2016. |
| **Date & Time Data Types** | `DATE` | — |
|  | `DATETIME` | Synonymous with `TIMESTAMP_NTZ`. |
|  | `TIME` | — |
|  | `TIMESTAMP` | Alias for one of the TIMESTAMP variations (`TIMESTAMP_NTZ` by default). |
|  | `TIMESTAMP_LTZ` | TIMESTAMP with local time zone; time zone not stored. |
|  | `TIMESTAMP_NTZ` | TIMESTAMP with no time zone; time zone not stored. |
|  | `TIMESTAMP_TZ` | TIMESTAMP with time zone. |
| **Semi-Structured Data Types** | `VARIANT`, `OBJECT`, `ARRAY` | Used for semi-structured data like JSON, Avro, Parquet. |
| **Structured Data Types** | `ARRAY`, `OBJECT`, `MAP` | Used for structured or nested data representations. |
| **Unstructured Data Types** | `FILE` | Used for documents, images, videos (via external stages). |
| **Geospatial Data Types** | `GEOGRAPHY`, `GEOMETRY` | Supports geospatial data formats. |
| **Vector Data Types** | `VECTOR` | Supports vector data for AI/ML use cases. |

---

## 1.8 Your First Snowflake Session

### Step 1 – Create Database and Schema

```sql
CREATE DATABASE demo_db;
CREATE SCHEMA demo_db.demo_schema;
```

### Step 2 – Create a Table
```sql
CREATE OR REPLACE TABLE demo_schema.employees (
    emp_id INT,
    emp_name STRING,
    department STRING,
    salary NUMBER(10,2)
);
```

### Step 3 – Insert Sample Data
```sql
INSERT INTO demo_schema.employees VALUES
(1, 'John', 'Finance', 55000),
(2, 'Mary', 'Engineering', 72000),
(3, 'Raj', 'HR', 48000);
```

### Step 4 – Query the Table
```sql
SELECT * FROM demo_schema.employees;
```

### Step 5 – Perform Analytics
```sql
SELECT department, AVG(salary) AS avg_salary
FROM demo_schema.employees
GROUP BY department;
```


✅ Tip:
Snowflake caches query results—re-running the same query is nearly instantaneous.

## 1.9 Benefits at a Glance

⚙️ Elastic Scaling – scale up / down instantly  
🔒 Secure by Design – encryption, MFA, role hierarchies  
🧠 No Maintenance – automatic optimization & patching  
💰 Cost Efficiency – pay only for compute seconds used  
🌍 Cross-Cloud – AWS, Azure, GCP interoperability  
🧩 Developer Friendly – SQL, Python (Snowpark), Java support  

## 1.10 Common Terminology

| **Term** | **Meaning** |
|-----------|-------------|
| **Warehouse** | Compute resource that runs queries. |
| **Database** | Logical container for schemas / tables. |
| **Schema** | Namespace within a database. |
| **Stage** | Location for data loading / unloading (internal or external). |
| **Micro-partition** | Internal storage unit (~16 MB compressed). |
| **Result Cache** | Stores previous query results for fast re-execution. |


## 1.11 Best Practices for Beginners

✅ Use `AUTO_SUSPEND` and `AUTO_RESUME` on warehouses to save cost.  
✅ Always qualify object names as `DATABASE.SCHEMA.TABLE`.  
✅ Keep raw / staging / production data in **separate schemas**.  
✅ Leverage **Time Travel** before dropping tables.  
✅ Start with **Small** warehouse size and scale as needed.  


Example:

```sql
CREATE WAREHOUSE wh_demo
  WITH WAREHOUSE_SIZE = 'SMALL'
  AUTO_SUSPEND = 300
  AUTO_RESUME = TRUE;
```

