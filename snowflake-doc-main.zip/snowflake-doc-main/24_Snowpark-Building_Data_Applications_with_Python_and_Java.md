# 📘 Chapter 24: Snowpark — Building Data Applications with Python and Java  

**🎯 Chapter Overview**  


Snowflake’s **Snowpark** is a revolutionary developer framework that brings **data engineering and application development directly into Snowflake**.  
Instead of moving data out to external compute environments (like Spark or Pandas), you can now process and transform data **in Snowflake itself** using **Python, Java, or Scala** — leveraging Snowflake’s elastic compute and security.
  
This chapter explains:  
- What Snowpark is and why it matters  
- Core concepts and architecture  
- Using Snowpark with Python and Java  
- Working with DataFrames and UDFs  
- Real-time examples for data transformation and ML inference  
- Best practices and optimization tips

---

## 📖 Table of Contents

**1.** Introduction to Snowpark  
**2.** Snowpark Architecture  
**3.** Snowpark vs. Traditional Data Processing  
**4.** Snowpark Setup and Environment  
**5.** Working with DataFrames  
**6.** Creating and Registering UDFs (User Defined Functions)  
**7.** Snowpark for Java Developers  
**8.** Hands-On Project — Data Cleansing and Transformation  
**9.** Integrating Snowpark with Machine Learning  
**10.** Best Practices & Optimization  
**11.** Summary  

---

## 1️⃣ Introduction to Snowpark  

**What is Snowpark?**

Snowpark is a developer framework provided by Snowflake that lets you:  
- Write data pipelines using **Python, Java, or Scala**  
- Run transformations **inside Snowflake’s compute engine**  
- Avoid data movement (compute happens “where the data lives”)  
- Build **data apps and ML models** directly on Snowflake data  

It’s part of Snowflake’s goal to make the platform more **developer-friendly and programmable**.  

---

**💡 Example: Why Snowpark?**

Traditionally:

You extract data from Snowflake → load into Pandas/Spark → process → write back.  

With Snowpark:

You write **Python/Java** code once → run **inside Snowflake** → no data movement, faster, secure.  

---

## 2️⃣ Snowpark Architecture

Below is the simplified Snowpark data flow:

```css
[ Snowpark Client (Python / Java) ]
              ↓
      [ Snowpark API Layer ]
              ↓
      [ Snowflake Compute Engine ]
              ↓
         [ Snowflake Storage ]
```

Components:  
| Component             | Description                                          |
| --------------------- | ---------------------------------------------------- |
| **Client Library**    | Snowpark SDK for Python, Java, or Scala              |
| **Snowpark API**      | Exposes DataFrame and UDF interfaces                 |
| **Snowflake Compute** | Executes transformations within Snowflake warehouses |
| **Result Set**        | Returned to the client after query execution         |  


✅ No need to provision external clusters or Spark — Snowflake handles scaling and execution.  

---

## 3️⃣ Snowpark vs. Traditional Data Processing  
| Feature       | Traditional ETL     | Snowpark                    |
| ------------- | ------------------- | --------------------------- |
| Data Movement | Extracts data       | In-database compute         |
| Languages     | SQL-only            | Python, Java, Scala         |
| Environment   | Spark/Local         | Snowflake compute           |
| Scalability   | Limited by cluster  | Elastic via warehouse       |
| Governance    | Risky (data copies) | Fully governed in Snowflake |
| Performance   | Latency due to I/O  | Near-zero I/O latency       |  


## 4️⃣ Snowpark Setup and Environment  

**Prerequisites**

- Snowflake account with **WAREHOUSE** and **DATABASE** access
- Python 3.8+
- `snowflake-snowpark-python` package

**Installation** 

```bash
pip install "snowflake-snowpark-python[pandas]"
```

**Connecting to Snowflake**

```python
from snowflake.snowpark import Session

connection_params = {
    "account": "<your_account>",
    "user": "<username>",
    "password": "<password>",
    "role": "SYSADMIN",
    "warehouse": "COMPUTE_WH",
    "database": "SALES_DB",
    "schema": "PUBLIC"
}

session = Session.builder.configs(connection_params).create()
print("✅ Connected to Snowflake")
```
---

## 5️⃣ Working with DataFrames

In Snowpark, you can create DataFrames directly from Snowflake tables or inline data.

**Example — Load Table as DataFrame**

```python
df_sales = session.table("CUSTOMER_SALES")
df_sales.show()
```

**Filter and Transform**

```python
df_filtered = df_sales.filter(df_sales["AMOUNT"] > 1000)
df_agg = df_filtered.group_by("REGION").agg({"AMOUNT": "sum"})
df_agg.show()
```

**Write Back to Snowflake**

```python
df_agg.write.mode("overwrite").save_as_table("SALES_BY_REGION")
```


Everything runs **inside Snowflake**, not locally — keeping performance high.  

---

## 6️⃣ Creating and Registering UDFs

You can define custom business logic using Python or Java as **User-Defined Functions** (UDFs).

**Example — Python UDF**

```python
from snowflake.snowpark.functions import udf

@udf
def apply_discount(amount: float) -> float:
    return amount * 0.9  # 10% discount

df_discounted = df_sales.with_column("DISCOUNTED_AMT", apply_discount(df_sales["AMOUNT"]))
df_discounted.show()
```

✅ Snowflake executes the function securely inside its compute engine.  


**Example — Java UDF**

```sql
CREATE OR REPLACE FUNCTION calc_tax(amount NUMBER)
RETURNS NUMBER
LANGUAGE JAVA
RUNTIME_VERSION = '11'
HANDLER = 'TaxCalculator.calculate'
AS
$$
class TaxCalculator {
  public static Double calculate(Double amount) {
    return amount * 0.18; // 18% tax
  }
}
$$;
```

Query:

```sql
SELECT calc_tax(1000);
```

---

## 7️⃣ Snowpark for Java Developers

Java developers can use the **Snowpark Java API** to create transformations programmatically.

**Example — Java Code Snippet**

```java

Session session = Session.builder().configs(connectionParameters).create();

DataFrame df = session.table("CUSTOMER_SALES");
DataFrame result = df.filter(col("AMOUNT").gt(1000))
                     .groupBy(col("REGION"))
                     .agg(sum(col("AMOUNT")).as("TOTAL_SALES"));

result.show();
```

Compile and run inside your Java application — Snowflake executes all operations on its compute layer.  

---


## 8️⃣ Hands-On Mini Project: Data Cleansing and Transformation 

**🎯 Goal:**

Use Snowpark to clean customer data, remove duplicates, and calculate sales summary.

**Step 1 — Create Sample Data**
```sql
CREATE OR REPLACE TABLE RAW_CUSTOMERS (
  CUST_ID STRING, NAME STRING, REGION STRING, AMOUNT NUMBER
);

INSERT INTO RAW_CUSTOMERS VALUES
('C1', 'John', 'US', 500),
('C2', 'Jane', 'US', 900),
('C1', 'John', 'US', 500),  -- duplicate
('C3', 'David', 'UK', 1200);
```

**Step 2 — Load Data with Snowpark**

```python
df_raw = session.table("RAW_CUSTOMERS")
df_unique = df_raw.drop_duplicates()
df_summary = df_unique.group_by("REGION").agg({"AMOUNT": "sum"})
df_summary.show()
```

Output:

| REGION | SUM(AMOUNT) |
| ------ | ----------- |
| US     | 1400        |
| UK     | 1200        |  


**Step 3 — Save Processed Data**

```python
df_summary.write.mode("overwrite").save_as_table("CLEANED_SALES_SUMMARY")
```


✅ Clean, transformed data — fully processed within Snowflake.

---

## 9️⃣ Integrating Snowpark with Machine Learning

Snowpark integrates seamlessly with **Snowflake ML** or external libraries (e.g., scikit-learn).

**Example — ML Inference with Python**  

```pytho
import joblib
from snowflake.snowpark.functions import udf

# Load trained model
model = joblib.load("model.pkl")

@udf
def predict_sales(amount: float) -> float:
    return model.predict([[amount]])[0]

df_pred = df_sales.with_column("PREDICTED_SALES", predict_sales(df_sales["AMOUNT"]))
df_pred.show()
```


✅ Snowflake executes the UDF for each row in parallel using **Snowpark runtime containers**.  

---  


## 🔟 Best Practices & Optimization 

| Category        | Recommendation                                                        |
| --------------- | --------------------------------------------------------------------- |
| **Performance** | Use vectorized operations and filter early                            |
| **Storage**     | Persist intermediate results using temporary tables                   |
| **UDFs**        | Keep logic lightweight; prefer SQL functions for simple operations    |
| **Security**    | Use Snowflake roles and masking policies with UDFs                    |
| **Testing**     | Develop locally, deploy using Snowpark Packaging (`snowpark package`) |
| **ML**          | Use Snowflake ML or external model registry for model storage         |  

---

## 🧠 Summary  

| Concept         | Description                                    |
| --------------- | ---------------------------------------------- |
| **Snowpark**    | Developer API for in-Snowflake data processing |
| **Languages**   | Python, Java, Scala                            |
| **Core Object** | Snowpark DataFrame                             |
| **Key Feature** | Compute runs inside Snowflake                  |
| **UDFs**        | Extend logic using Python/Java                 |
| **Integration** | ML, API apps, and real-time analytics          |  

---

## 🔑 Key Takeaways

- Snowpark brings programming to the data — not the other way around.
- Enables developers to build and deploy **data pipelines, ML models, and APIs** within Snowflake.
- Removes need for separate Spark clusters or external compute.
- Ideal for ***ETL, data quality, and ML inference** workloads.
- Snowpark + UDFs + Python = next-gen data applications on Snowflake.

