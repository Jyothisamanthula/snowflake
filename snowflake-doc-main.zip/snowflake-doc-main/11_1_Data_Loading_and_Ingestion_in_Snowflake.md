# 📘 11_1 Data Loading and Ingestion in Snowflake 

Efficient and secure data loading is at the core of every Snowflake-based architecture.  

Snowflake provides multiple methods to ingest structured, semi-structured, and unstructured data from **local systems**, **cloud storage**, and **real-time sources** — supporting both **batch** and **streaming** workflows.

---

## Overview of Data Loading Methods  

**🧩 What is Data Loading?**

Data loading is the process of bringing raw data into Snowflake tables for analytics, reporting, and transformations.  

Snowflake provides a variety of ingestion techniques to suit different data types, volumes, and latency requirements.  

**🔹 Snowflake Loading Approaches**  

| Loading Type                      | Description                                                            | Typical Use Case                        |
| --------------------------------- | ---------------------------------------------------------------------- | --------------------------------------- |
| **Bulk Loading**                  | High-volume batch ingestion using `COPY INTO`.                         | Initial loads, daily/weekly updates.    |
| **Continuous Loading (Snowpipe)** | Near real-time ingestion triggered by cloud events.                    | Streaming, IoT, operational data.       |
| **External Tables**               | Query cloud data directly without full ingestion.                      | Data lake integration, cost efficiency. |
| **Streams + Tasks**               | Automate incremental updates and transformations.                      | ETL/CDC pipelines.                      |
| **Third-Party Tools**             | Use ETL/ELT tools like Fivetran, Informatica, Matillion, DBT, Airbyte. | Enterprise orchestration.               |
| **Manual Inserts/Merges**         | Ad-hoc or small data corrections.                                      | Data patching or small updates.         |  


💡 Tip: Choose a loading method based on **data volume**, **frequency**, and **data type**.  

---

## Using COPY INTO and COPY Options

The `COPY INTO` command is the foundation for bulk data loading in Snowflake. It transfers data files from **stages** (internal or external) into target tables.  

**🧭 Syntax**  

```sql
COPY INTO <table_name>
FROM @<stage_name>/<path>
FILE_FORMAT = (TYPE='CSV' FIELD_OPTIONALLY_ENCLOSED_BY='"' SKIP_HEADER=1)
ON_ERROR = 'CONTINUE'
PURGE = FALSE;  
```

## ⚙️ Common COPY Options    

| Option            | Description                                    | Example                           |
| ----------------- | ---------------------------------------------- | --------------------------------- |
| `FILE_FORMAT`     | Specifies file type (CSV, JSON, PARQUET, etc.) | `FILE_FORMAT=(TYPE='CSV')`        |
| `ON_ERROR`        | Defines error-handling behavior                | `ON_ERROR='CONTINUE'`             |
| `PURGE`           | Deletes files after successful load            | `PURGE=TRUE`                      |
| `VALIDATION_MODE` | Validates files without loading                | `VALIDATION_MODE='RETURN_ERRORS'` |
| `FORCE`           | Reloads files even if already loaded           | `FORCE=TRUE`                      |
| `PATTERN`         | Loads only matching files (regex)              | `PATTERN='.*.csv'`                |  

**💡 Example**

```sql
COPY INTO SALES
FROM @MY_STAGE
FILE_FORMAT=(TYPE='CSV' FIELD_DELIMITER=',' SKIP_HEADER=1)
ON_ERROR='CONTINUE';
```

## Snowflake Stages

A **Stage** is a location in or outside Snowflake that temporarily holds data files before loading into tables.  
Stages can be internal (inside Snowflake) or **external** (cloud storage).

**🔹 Types of Stages**  

| Type                     | Description                         | Example                     | Use Case                      |
| ------------------------ | ----------------------------------- | --------------------------- | ----------------------------- |
| **User Stage**           | Each user has a private stage.      | `@~`                        | Small, temporary uploads.     |
| **Table Stage**          | Each table has an associated stage. | `@%sales`                   | Table-specific loads.         |
| **Named Internal Stage** | Created explicitly by users.        | `CREATE STAGE sales_stage;` | Centralized reusable staging. |
| **External Stage**       | References cloud storage.           | `@s3_stage`                 | Cloud-based ingestion.        |  

---
## Storage Integrations (Secure Cloud Access)

A **Storage Integration** securely connects Snowflake to external cloud storage without **exposing credentials**.

✅ Benefits

- No need to store cloud keys in scripts.
- Centralized, role-based access.
- Works across multiple users and roles.

  ---

## 📦 Snowflake Stages & Storage Integrations – Complete Examples

Snowflake stages act as intermediate locations to store or access files before loading data into tables.
They can be:

- Internal Stages (managed by Snowflake)  
- External Stages (in cloud storage like S3, Azure Blob, or GCS)

--- 

## 🧱 1. User Stage

Each Snowflake user automatically gets a **personal stage** named `@~`.  
This is useful for **quick testing or small file uploads**.  


**🧩 Example: Using User Stage** 

```sql
-- Upload local file to user stage
PUT file://C:/data/customers.csv @~;

-- View uploaded file
LIST @~;

-- Create target table
CREATE OR REPLACE TABLE customers (
  id INT,
  name STRING,
  city STRING
);

-- Load data into table
COPY INTO customers
FROM @~
FILE_FORMAT = (TYPE='CSV' FIELD_OPTIONALLY_ENCLOSED_BY='"' SKIP_HEADER=1)
ON_ERROR='CONTINUE';
```

✅ Notes

- Files are private to the user.
- Best suited for **ad-hoc or one-time loads**.

---

## 🧱 2. Table Stage

Each table automatically has its own **table-specific stage** (`@%table_name`).  
This stage is linked directly to the table.  

**🧩 Example: Using Table Stage**  

```sql
-- Create target table
CREATE OR REPLACE TABLE sales (
  order_id INT,
  product STRING,
  price NUMBER,
  region STRING
);

-- Upload file directly to table stage
PUT file://C:/data/sales_jan.csv @%sales;

-- View staged files
LIST @%sales;

-- Load from table stage
COPY INTO sales
FROM @%sales
FILE_FORMAT = (TYPE='CSV' SKIP_HEADER=1 FIELD_OPTIONALLY_ENCLOSED_BY='"')
ON_ERROR='CONTINUE';
```  

**✅ Notes**

- Automatically created with each table.
- Best for **isolated loads per table**.
- Automatically dropped when the table is dropped.

---

## 🧱 3. Named Internal Stage

A **Named Internal Stage** is explicitly created by the user.  
It resides within Snowflake-managed storage and is reusable across tables or schemas.  

**🧩 Example: Internal Stage**  

```sql
-- Create a reusable internal stage
CREATE OR REPLACE STAGE company_stage
FILE_FORMAT = (TYPE='CSV' SKIP_HEADER=1);

-- Upload files to stage
PUT file://C:/data/products.csv @company_stage;
PUT file://C:/data/orders.csv @company_stage;

-- View files in the stage
LIST @company_stage;

-- Create target table
CREATE OR REPLACE TABLE products (
  product_id INT,
  product_name STRING,
  price NUMBER
);

-- Load data from the stage
COPY INTO products
FROM @company_stage
FILE_FORMAT = (TYPE='CSV')
ON_ERROR='CONTINUE';
```  

**✅ Notes**

- Stored inside Snowflake (fully encrypted).  
- Best for **shared, reusable staging environments**.  
- Managed automatically by Snowflake — no cloud setup needed.

---

## ☁️ 4. External Stage (with Storage Integration)

External stages reference files stored in **cloud storage** (S3, Azure Blob, or GCS).  
They require **storage integrations** for secure, credential-free access.   


## 🌩️ Storage Integration + External Stage Examples  

**🟢 4.1 AWS S3 Integration & Stage**  

**Step 1️⃣ — Create Storage Integration**  

```sql
CREATE OR REPLACE STORAGE INTEGRATION s3_integration
TYPE = EXTERNAL_STAGE
STORAGE_PROVIDER = S3
ENABLED = TRUE
STORAGE_AWS_ROLE_ARN = 'arn:aws:iam::123456789012:role/snowflake_s3_role'
STORAGE_ALLOWED_LOCATIONS = ('s3://my-company-data/sales/');
```

**Step 2️⃣ — Grant Role Access** 

```sql
GRANT USAGE ON INTEGRATION s3_integration TO ROLE data_engineer;
```

**Step 3️⃣ — Create External Stage**  

```sql
CREATE OR REPLACE STAGE s3_sales_stage
URL = 's3://my-company-data/sales/'
STORAGE_INTEGRATION = s3_integration
FILE_FORMAT = (TYPE='CSV' SKIP_HEADER=1);
```

**Step 4️⃣ — Load Data from S3**  

```sql
CREATE OR REPLACE TABLE sales (
  order_id INT,
  product STRING,
  price NUMBER,
  order_date DATE
);

COPY INTO sales
FROM @s3_sales_stage
FILE_FORMAT = (TYPE='CSV' SKIP_HEADER=1)
ON_ERROR='CONTINUE';
```

**✅ Notes**

- The AWS IAM role must trust Snowflake’s external ID (provided by Snowflake after integration creation).  
- Ideal for **secure enterprise S3 data ingestion.**

--- 


**🔵 4.2 Azure Blob Integration & Stage**  

**Step 1️⃣ — Create Storage Integration**  

```sql
CREATE OR REPLACE STORAGE INTEGRATION azure_integration
TYPE = EXTERNAL_STAGE
STORAGE_PROVIDER = AZURE
ENABLED = TRUE
STORAGE_ACCOUNT = 'myazureaccount'
STORAGE_ALLOWED_LOCATIONS = ('azure://mycontainer.blob.core.windows.net/data/');
```

**Step 2️⃣ — Grant Role Access**  

```sql
GRANT USAGE ON INTEGRATION azure_integration TO ROLE data_engineer;
```

**Step 3️⃣ — Create External Stage**  

```sql
CREATE OR REPLACE STAGE azure_sales_stage
URL = 'azure://mycontainer.blob.core.windows.net/data/'
STORAGE_INTEGRATION = azure_integration
FILE_FORMAT = (TYPE='CSV' SKIP_HEADER=1);
```

**Step 4️⃣ — Load Data from Azure Blob**  

```sql
CREATE OR REPLACE TABLE azure_sales (
  id INT,
  product STRING,
  quantity INT,
  amount NUMBER
);

COPY INTO azure_sales
FROM @azure_sales_stage
FILE_FORMAT = (TYPE='CSV')
ON_ERROR='CONTINUE';
```


**✅ Notes**

- Uses Azure **Service Principal** or **SAS Token** authentication (handled via integration).
- Perfect for **Azure-native ecosystems**.

---

**🟣 4.3 Google Cloud Storage (GCS) Integration & Stage**  

**Step 1️⃣ — Create Storage Integration**  

```sql
CREATE OR REPLACE STORAGE INTEGRATION gcs_integration
TYPE = EXTERNAL_STAGE
STORAGE_PROVIDER = GCS
ENABLED = TRUE
STORAGE_ALLOWED_LOCATIONS = ('gcs://mycompany-data/sales/');
```

**Step 2️⃣ — Grant Access**  

```sql
GRANT USAGE ON INTEGRATION gcs_integration TO ROLE data_engineer;
```

**Step 3️⃣ — Create External Stage**  

```sql
CREATE OR REPLACE STAGE gcs_sales_stage
URL = 'gcs://mycompany-data/sales/'
STORAGE_INTEGRATION = gcs_integration
FILE_FORMAT = (TYPE='PARQUET');
```

**Step 4️⃣ — Load Data from GCS**  

```sql
CREATE OR REPLACE TABLE gcs_sales (
  order_id INT,
  region STRING,
  amount NUMBER
);

COPY INTO gcs_sales
FROM @gcs_sales_stage
FILE_FORMAT = (TYPE='PARQUET')
ON_ERROR='CONTINUE';
```


**✅ Notes**  

- Integration handles authentication using **GCP IAM** roles.
- Recommended for **GCS-hosted lakehouse architectures.**

---

## 💡 5. Verification & Maintenance  

**🧾 List Files in Any Stage**  

```sql
LIST @s3_sales_stage;
LIST @azure_sales_stage;
LIST @gcs_sales_stage;
LIST @company_stage;
```

**🧠 Preview Metadata**

```sql
SELECT METADATA$FILENAME, METADATA$ROW_COUNT
FROM TABLE(INFORMATION_SCHEMA.LOAD_HISTORY_BY_STAGE(
  STAGE_NAME=>'@s3_sales_stage'
));
```

**🧹 Remove Files (Optional)**  

```sql
REMOVE @company_stage PATTERN='.*.csv';
```

---

## 🧠 Summary Table  

| Stage Type                 | Location           | Requires Integration? | Example Reference                    |
| -------------------------- | ------------------ | --------------------- | ------------------------------------ |
| **User Stage**             | Snowflake internal | ❌                     | `@~`                                 |
| **Table Stage**            | Snowflake internal | ❌                     | `@%table_name`                       |
| **Named Internal Stage**   | Snowflake internal | ❌                     | `CREATE STAGE company_stage;`        |
| **External Stage (S3)**    | AWS S3             | ✅                     | `CREATE STAGE s3_sales_stage ...`    |
| **External Stage (Azure)** | Azure Blob         | ✅                     | `CREATE STAGE azure_sales_stage ...` |
| **External Stage (GCS)**   | Google Cloud       | ✅                     | `CREATE STAGE gcs_sales_stage ...`   |  

---

✅ Key Takeaways

- Use **internal stages** for simplicity, **external stages** for cloud-scale integration.
- **Storage Integrations** manage cloud credentials securely — no hardcoded keys.
- Combine **stages + COPY INTO** for batch loads, or **stages + Snowpipe** for real-time ingestion.
- Always verify with `LIST` and monitor load history via `LOAD_HISTORY` views.
