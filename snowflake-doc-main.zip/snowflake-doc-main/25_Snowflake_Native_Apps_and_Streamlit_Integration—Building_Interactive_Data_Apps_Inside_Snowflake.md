# 📘 Chapter 25: Snowflake Native Apps and Streamlit Integration — Building Interactive Data Apps Inside Snowflake  

## 🎯 Chapter Overview

Snowflake has evolved from being just a cloud data warehouse into a **complete data application platform**.
With **Snowflake Native Apps** and **Streamlit Integration**, developers can now build and distribute interactive, **secure, and data-rich applications directly inside Snowflake** — no external servers or dashboards required.

This chapter covers:  

- What Snowflake Native Apps are  
- How Streamlit integrates natively with Snowflake  
- Key components and architecture  
- Hands-on project: building a real-time interactive dashboard  
- Packaging and publishing your app in the Snowflake Marketplace  

---

📖 Table of Contents

**1.** Introduction to Snowflake Native Apps  
**2.** Understanding Streamlit Integration  
**3.** Native App Architecture  
**4.** Setting Up Your Environment  
**5.** Building Your First Snowflake Native App  
**6.** Embedding Streamlit for Interactive Visuals  
**7.** Mini Project — Sales Analytics Dashboard  
**8.** Publishing Apps to the Snowflake Marketplace  
**9.** Security and Governance for Apps  
**10.** Best Practices and Performance Tips  
**11.** Summary  

---


## 1️⃣ Introduction to Snowflake Native Apps

**Snowflake Native Apps** allow you to build and distribute **fully managed, deployable apps** that run inside a consumer’s Snowflake account.  

**🔍 Key Advantages**

✅ No external infrastructure required  
✅ Secure execution within Snowflake’s governance model  
✅ App code and data remain in the consumer’s account  
✅ Monetizable through the Snowflake Marketplace  

---

## 2️⃣ Understanding Streamlit Integration

**Streamlit**, now part of Snowflake, is a **Python-based open-source app framework** for quickly building interactive web dashboards.  

**🎨 Streamlit in Snowflake lets you:**

- Create interactive UIs directly connected to Snowflake data  
- Run Streamlit code without separate servers  
- Embed Streamlit apps in Snowflake Native Apps  
- Use Snowflake authentication and role-based access for end-users

---

## 3️⃣ Native App Architecture  

```pgsql
+---------------------------------------------+
|              Snowflake Native App            |
|---------------------------------------------|
|  Streamlit UI Layer  → Interactive Dashboard |
|  Snowpark Logic Layer → Python/SQL processing |
|  Data Layer → Snowflake Tables & Views        |
|---------------------------------------------|
|        Runs entirely within Snowflake        |
+---------------------------------------------+
```  


**Key Components**  

| Component         | Description                                                                          |
| ----------------- | ------------------------------------------------------------------------------------ |
| **App Package**   | Code + metadata deployed as Snowflake objects (Stages, Procedures, Streamlit files). |
| **Streamlit App** | Frontend interface for data interaction.                                             |
| **Snowpark**      | Handles data logic and transformations.                                              |
| **Marketplace**   | Distribution platform for sharing/selling apps.                                      |  

---


## 4️⃣ Setting Up Your Environment  

**Requirements**

- Snowflake account with Streamlit enabled (`ACCOUNTADMIN` role)
- Warehouse (e.g., `COMPUTE_WH`)
- `Snowflake CLI` and `snowflake-snowpark-python` installed  

**Optional: Local Testing**
```bash
pip install "streamlit snowflake-snowpark-python"
```  

**Check Streamlit Availability**

```sql
SHOW STREAMLIT;
```  

**If not enabled:**

```sql
ALTER ACCOUNT SET ENABLE_STREAMLIT = TRUE;
```
---

## 5️⃣ Building Your First Snowflake Native App  

**Step 1: Create a New Database and Schema**  

```sql
CREATE OR REPLACE DATABASE APP_DB;
CREATE OR REPLACE SCHEMA APP_DB.PUBLIC;
```

**Step 2: Create a Stage for App Files**  

```sql
CREATE OR REPLACE STAGE app_stage;
```

**Step 3: Upload Streamlit Files** 

Use the Snowflake Web UI or CLI:

```bash
PUT file://app/streamlit_app.py @APP_DB.PUBLIC.app_stage overwrite=true;
```

**Step 4: Create the Streamlit App Object**  

```sql
CREATE OR REPLACE STREAMLIT APP_DB.PUBLIC.SALES_DASHBOARD
  ROOT_LOCATION = @APP_DB.PUBLIC.app_stage
  MAIN_FILE = 'streamlit_app.py';
```
---
  
## 6️⃣ Embedding Streamlit for Interactive Visuals  

**Example** `streamlit_app.py`:

```python
import streamlit as st
from snowflake.snowpark import Session

st.title("📊 Snowflake Sales Dashboard")

connection_params = {
  "account": "<your_account>",
  "user": "<username>",
  "password": "<password>",
  "warehouse": "COMPUTE_WH",
  "database": "SALES_DB",
  "schema": "PUBLIC"
}

session = Session.builder.configs(connection_params).create()
df = session.table("SALES").to_pandas()

region = st.selectbox("Select Region", sorted(df["REGION"].unique()))
filtered = df[df["REGION"] == region]

st.bar_chart(filtered.groupby("PRODUCT")["SALES_AMOUNT"].sum())
st.write("Data Preview:", filtered.head())
```


✅ This creates an interactive dashboard that runs **inside Snowflake** — users can select a region and view real-time sales visualizations.

---

## 7️⃣ Hands-On Mini Project — Sales Analytics Dashboard  

**Project Goal**

Create a real-time interactive sales dashboard using Snowpark and Streamlit embedded in Snowflake.    

Data Model    

| Column       | Type   | Description             |
| :----------- | :----- | :---------------------- |
| ORDER_ID     | STRING | Unique order identifier |
| REGION       | STRING | Sales region            |
| PRODUCT      | STRING | Product category        |
| SALES_AMOUNT | NUMBER | Order value             |
| ORDER_DATE   | DATE   | Date of order           |  
  

**Step 1: Create Source Table**  

```sql

CREATE OR REPLACE TABLE SALES (
  ORDER_ID STRING,
  REGION STRING,
  PRODUCT STRING,
  SALES_AMOUNT NUMBER,
  ORDER_DATE DATE
);

INSERT INTO SALES VALUES
('O1','US','Shoes',300,'2025-09-10'),
('O2','US','Bags',150,'2025-09-12'),
('O3','EU','Shoes',400,'2025-09-11'),
('O4','EU','Bags',180,'2025-09-13');
```

**Step 2: Create Streamlit App**  

```python
import streamlit as st
from snowflake.snowpark import Session
import pandas as pd

st.title("💰 Real-Time Sales Analytics")

session = Session.builder.configs({
  "account": "<your_account>",
  "user": "<user>",
  "password": "<password>",
  "warehouse": "COMPUTE_WH",
  "database": "APP_DB",
  "schema": "PUBLIC"
}).create()

df = session.table("SALES").to_pandas()

date_filter = st.date_input("Select Date", value=pd.to_datetime("2025-09-12"))
filtered = df[df["ORDER_DATE"] <= date_filter]

st.line_chart(filtered.groupby("REGION")["SALES_AMOUNT"].sum())
```


✅ Output: A live chart that filters sales based on selected dates.  

---


## 8️⃣ Publishing Apps to the Snowflake Marketplace

Once tested, you can publish apps using the **Snowflake Native App Framework**.

**Packaging**

```bash
snowflake app package create --name sales_dashboard --stage @APP_DB.PUBLIC.app_stage
```

**Deployment**

```sql
CREATE APPLICATION PACKAGE SALES_ANALYTICS
  FROM @APP_DB.PUBLIC.app_stage;
```


✅ Your app can now be shared securely with consumers or listed in the Marketplace.  

---


## 9️⃣ Security and Governance for Apps    


| Feature             | Description                                                                |
| :------------------ | :------------------------------------------------------------------------- |
| **Data Privacy**    | Apps run within the consumer’s account — no data leaves their environment. |
| **Access Control**  | Managed through Snowflake roles and policies.                              |
| **Code Isolation**  | Each app is sandboxed from others.                                         |
| **Version Control** | Apps can be updated or rolled back through package versions.               |  

---  


## 🔟 Best Practices and Performance Tips  

| Category    | Recommendation                                                  |
| :---------- | :-------------------------------------------------------------- |
| Performance | Pre-aggregate data for fast visual loads                        |
| UI Design   | Use Streamlit layouts for responsive dashboards                 |
| Security    | Avoid hard-coding credentials; use Snowflake secrets management |
| Scalability | Use caching where possible in Streamlit                         |
| Deployment  | Version apps using `APP_VERSION` and test in dev schema         |  


---

## 🧠 Summary

| Concept                   | Description                                          |
| :------------------------ | :--------------------------------------------------- |
| **Snowflake Native Apps** | Apps that run natively inside Snowflake accounts.    |
| **Streamlit Integration** | Interactive Python dashboards embedded in Snowflake. |
| **Snowpark**              | Backend logic layer for data processing inside apps. |
| **Marketplace**           | Platform to share and monetize your apps.            |  

---

## 🔑 Key Takeaways

- Snowflake + Streamlit = interactive data apps with no external servers.  
- Build secure, governed apps that execute within the data platform.  
- Combine **Snowpark logic + Streamlit UI** for real-time analytics.
- Distribute apps easily through the Snowflake Marketplace.
