# ⚙️ Chapter 4: Snowflake Architecture Deep Dive

---

## 4.1 Overview

In this chapter, we’ll explore the **inner workings of Snowflake’s architecture**, diving into how data is stored, processed, and optimized across its three key layers:

1. **Storage Layer** – How Snowflake stores and manages data efficiently  
2. **Compute Layer** – How virtual warehouses execute queries  
3. **Cloud Services Layer** – How metadata, optimization, and security are orchestrated

We’ll also cover **micro-partitions**, **clustering**, and **caching** in detail with working SQL examples.

---

## 4.2 Storage Layer – Inside the Data Foundation

The **Storage Layer** is responsible for storing all data loaded into Snowflake. It’s completely **managed, compressed, encrypted, and optimized** automatically.

### 🔹 Key Characteristics

- Columnar storage (optimized for analytical queries)
- Automatically compressed
- Encrypted with AES-256
- Stored in immutable **micro-partitions**
- Replicated across availability zones for durability

---

### 🧱 Micro-Partitions: The Core Storage Unit

Snowflake breaks data into small, immutable blocks called **micro-partitions** (typically 50MB–500MB in size).

Each micro-partition stores:
- Column values
- Min/Max statistics
- Data distribution
- Metadata for query pruning

This enables Snowflake’s **metadata-driven query pruning**, meaning only relevant micro-partitions are scanned.

#### Example:

```sql
-- Create demo table
CREATE OR REPLACE TABLE SALES (
  ORDER_ID INT,
  REGION STRING,
  AMOUNT NUMBER(10,2),
  ORDER_DATE DATE
);

-- Load sample data
INSERT INTO SALES VALUES
(1, 'EAST', 100.50, '2025-01-01'),
(2, 'WEST', 200.75, '2025-02-10'),
(3, 'NORTH', 150.00, '2025-03-15');

-- View storage metrics
SELECT *
FROM TABLE(INFORMATION_SCHEMA.TABLE_STORAGE_METRICS('SALES_DB.PUBLIC.SALES'));
```

🧠 Each insert automatically creates new micro-partitions; older ones remain immutable.
--
🔍 Query Pruning Example

When you filter data, Snowflake automatically skips irrelevant micro-partitions.

```sql
SELECT * FROM SALES WHERE REGION = 'EAST';
```

Internally:

- The optimizer reads partition metadata

- It checks which micro-partitions contain REGION='EAST'

- Only those partitions are scanned

Result: ⚡ **Faster performance and lower cost**
---
📂 Storage Lifecycle

**1.** Data is staged in **external/internal stages**

**2.** Loaded into Snowflake via COPY INTO

**3.** Transformed into micro-partitions

**4.** Compressed, encrypted, and stored

**5.** Metadata registered in the **Cloud Services Layer**

```sql
COPY INTO SALES
FROM @aws_stage
FILE_FORMAT = (TYPE = 'CSV' FIELD_OPTIONALLY_ENCLOSED_BY='"')
ON_ERROR = 'CONTINUE';

```
✅ You don’t manage files — Snowflake handles the transformation.
---
## 4.3 Compute Layer – Virtual Warehouses in Action

The Compute Layer executes queries using Virtual Warehouses (VWH).
Each warehouse is an independent compute cluster with dedicated CPU, memory, and SSD cache.

🧮 Warehouse Properties
```sql
CREATE OR REPLACE WAREHOUSE WH_SALES
  WITH WAREHOUSE_SIZE = 'MEDIUM'
  AUTO_SUSPEND = 300
  AUTO_RESUME = TRUE
  INITIALLY_SUSPENDED = TRUE;
```

**AUTO_SUSPEND** → Saves cost when idle

**AUTO_RESUME** → Instantly restarts on demand

**WAREHOUSE_SIZE** → Determines compute power

**MULTI-CLUSTER** → Handles concurrent load automatically

🔁 Multi-Cluster Scaling Example

```sql
ALTER WAREHOUSE WH_SALES
  SET MIN_CLUSTER_COUNT = 1
      MAX_CLUSTER_COUNT = 3
      SCALING_POLICY = 'ECONOMY';
```

**How it works:**

- When concurrency increases → extra clusters spin up

- When queries finish → clusters shut down

- Transparent to users — no manual intervention

🧠 Perfect for organizations with mixed workloads (ETL + BI + API).

🧩 Compute Caching

Snowflake employs three layers of caching to maximize performance:
| Cache Type           | Layer          | Description                    | Persistence              |
| -------------------- | -------------- | ------------------------------ | ------------------------ |
| **Result Cache**     | Cloud Services | Stores query results           | 24 hours                 |
| **Local Disk Cache** | Compute        | Stores micro-partitions on SSD | Until warehouse restarts |
| **Metadata Cache**   | Services       | Caches metadata & statistics   | Persistent               |

Example:
```sql
-- First execution: scans storage
SELECT COUNT(*) FROM SALES;

-- Second execution: served instantly from result cache
SELECT COUNT(*) FROM SALES;
```

💡 If the underlying table hasn’t changed, the result cache returns instantly with zero cost.

🧠 How Queries Use Cache
```text
1️⃣ User runs a query
2️⃣ Cloud Services checks Result Cache
3️⃣ If not found → Compute checks Local Cache
4️⃣ If still not found → Data fetched from Storage
5️⃣ Result cached for future queries
```

Each warehouse has its own SSD cache, so switching warehouses resets cache usage.

💰 Compute Cost Optimization Tips

- **1.** Enable **AUTO_SUSPEND** to pause idle warehouses

- **2.** Create dedicated warehouses for heavy ETL jobs

- **3.** Use **multi-cluster** only when concurrency justifies it

- **4.** Monitor usage via:

```sql
SHOW WAREHOUSE_USAGE LIKE 'WH_SALES';
```
---
## 4.4 Cloud Services Layer – The Intelligent Brain

The Cloud Services Layer handles all coordination, metadata, and governance operations.

🔹 Responsibilities
| Function                            | Description                                       |
| ----------------------------------- | ------------------------------------------------- |
| **Authentication & Access Control** | MFA, SSO, and RBAC enforcement                    |
| **Metadata Management**             | Table definitions, micro-partition stats, lineage |
| **Query Optimization**              | Query parsing, plan generation, pruning           |
| **Resource Management**             | Auto-suspend/resume, cluster allocation           |
| **Security Services**               | Encryption key management, network policies       |


🔍 Query Optimization Example

When you run a query, Snowflake’s optimizer:

**1.** Analyzes metadata

**2.** Determines relevant partitions

**3.** Builds execution plan

**4.** Pushes workload to virtual warehouses

```sql
EXPLAIN SELECT REGION, SUM(AMOUNT)
FROM SALES
GROUP BY REGION;
```

The output includes:

- Pruning steps

- Execution plan tree

- Estimated cost
  
---
🧾 Metadata Access Example

You can directly query metadata using Information Schema or Account Usage views.

```sql
SELECT
  TABLE_CATALOG,
  TABLE_SCHEMA,
  TABLE_NAME,
  ROW_COUNT,
  BYTES
FROM SNOWFLAKE.ACCOUNT_USAGE.TABLES
WHERE DELETED IS NULL
ORDER BY BYTES DESC;
```

📊 Gives visibility into table sizes and growth patterns.  

---
🧱 Metadata Use Cases

- Data lineage tracking

- Cost optimization (size trends)

- Detecting stale tables

- Storage and performance tuning

🔐 Security Services

Snowflake’s security features are embedded in the services layer:

- Role-Based Access Control (RBAC)

- Multi-Factor Authentication (MFA)

- Network policies and IP whitelisting

- Key rotation and encryption management

```sql
CREATE NETWORK POLICY corp_policy
  ALLOWED_IP_LIST = ('10.10.10.0/24', '52.22.33.44')
  BLOCKED_IP_LIST = ('0.0.0.0/0');

ALTER ACCOUNT SET NETWORK_POLICY = corp_policy;
```

🔒 Security and governance are applied globally and automatically.

----
## 4.5 Putting It All Together – End-to-End Query Flow

Let’s visualize a query’s full lifecycle through all layers.

```text
1️⃣ User submits query via Web UI / Python / BI Tool
2️⃣ Cloud Services authenticates user and parses query
3️⃣ Query plan optimized using metadata
4️⃣ Compute warehouse retrieves necessary micro-partitions from storage
5️⃣ Data processed and cached locally
6️⃣ Result returned to Cloud Services
7️⃣ Result stored in Result Cache for 24 hours
```

🎯 Goal: Maximum performance with minimal compute usage.

---
## 4.6 Monitoring and Metadata Introspection
🧠 Query History
```sql
SELECT
  QUERY_ID,
  USER_NAME,
  WAREHOUSE_NAME,
  EXECUTION_STATUS,
  TOTAL_ELAPSED_TIME
FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
WHERE START_TIME >= DATEADD('day', -1, CURRENT_TIMESTAMP())
ORDER BY START_TIME DESC;
```

✅ Helps track slow queries and usage trends.

---
📊 Warehouse Load Monitoring
```sql
SELECT
  WAREHOUSE_NAME,
  AVG_RUNNING,
  AVG_QUEUED_LOAD,
  AVG_QUEUED_PROVISIONING
FROM SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_LOAD_HISTORY
WHERE START_TIME > DATEADD('hour', -24, CURRENT_TIMESTAMP());
```

Use this to:

- Detect under/over-provisioning

- Fine-tune warehouse sizes

---
💾 Storage Metrics
```sql
SELECT
  TABLE_NAME,
  ACTIVE_BYTES / 1024 / 1024 AS SIZE_MB,
  MICRO_PARTITIONS
FROM SNOWFLAKE.ACCOUNT_USAGE.TABLE_STORAGE_METRICS
WHERE TABLE_SCHEMA = 'PUBLIC';
```

Provides insights into storage efficiency and partitioning.

---
## 4.7 Summary

In this deep dive, we explored:

✅ Storage Layer – Micro-partitions, pruning, compression, encryption  
✅ Compute Layer – Virtual warehouses, caching, scaling  
✅ Cloud Services Layer – Metadata, optimization, and governance  
✅ End-to-End Query Flow – How data moves across layers  
✅ Monitoring & Optimization – Key SQL examples for visibility  

Snowflake’s **separation of compute and storage**, combined with **intelligent metadata services**, makes it a next-generation data platform — simple, fast, and secure.
