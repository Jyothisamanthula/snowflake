# Chapter 13: Zero-Copy Cloning — Use Cases and Performance

## 13.1 Introduction

One of Snowflake’s most powerful and unique features is **Zero-Copy Cloning**.  
It allows you to instantly create a **copy of a database, schema, or table** without physically duplicating the underlying data.

This feature enables faster testing, development, and analytics — all without consuming additional storage costs or impacting production data.

---

## 13.2 What is Zero-Copy Cloning?

Zero-copy cloning is the process of creating a **logical copy** of an object (database, schema, or table) that shares the same underlying micro-partitions of data.

When a clone is created:
- Snowflake does **not** duplicate data physically.
- It references existing data storage.
- Any subsequent modifications in the clone or the source create new micro-partitions (Copy-on-Write behavior).

This means cloning is **instant** and **cost-efficient**.

---

## 13.3 How Zero-Copy Cloning Works Internally

Snowflake’s **micro-partition architecture** stores data in immutable blocks.

When you clone an object:
- The clone initially points to the **same micro-partitions** as the source.
- If data changes in either object (insert/update/delete), only the **modified micro-partitions** are written separately.
- This is known as **Copy-on-Write (CoW)**.

### Visualization:  

```
Source Table
├── MP1
├── MP2
└── MP3

Clone Table
├── MP1 (shared)
├── MP2 (shared)
└── MP3 (shared)
```



```yaml 
If an update happens to `MP2` in the clone:
- Snowflake creates a **new version** of `MP2` only in the clone.
- Storage remains shared for unmodified partitions.
```
---

## 13.4 Supported Clone Objects

Zero-copy cloning supports the following object types:

| Object Type | Supported |
|--------------|------------|
| Database | ✅ |
| Schema | ✅ |
| Table | ✅ |
| External Table | ❌ (not yet supported for cloning) |
| Materialized View | ❌ |
| Streams & Tasks | ✅ (when cloning schema or database) |
| Views | ✅ (copied logically as definitions) |

---

## 13.5 Syntax and Examples

### Clone a Database
```sql
CREATE DATABASE DEV_CLONE CLONE PROD_DB;
```

✅ Creates a full clone of the PROD_DB database including all schemas, tables, and objects.

**Clone a Schema**
```sql
CREATE SCHEMA SALES_CLONE CLONE PROD_DB.SALES;
```

**Clone a Table**
```sql
CREATE TABLE SALES_JAN_CLONE CLONE SALES_JAN;
```

**Clone Specific Point-in-Time Snapshot**
```
CREATE TABLE SALES_CLONE CLONE SALES AT (TIMESTAMP => '2024-12-31 23:59:59');
```

This is extremely useful for **time travel and auditing** scenarios.

---  

## 13.6 Key Use Cases
**1. Testing and Development Environments**

Developers can clone production data instantly for testing without impacting live systems.  
CREATE DATABASE DEV_CLONE CLONE PROD_DB;


Benefits:
- Instant provisioning  
- No additional storage cost  
- Full dataset availability for QA/UAT  

**2. Backup and Recovery**

Cloning can be used to simulate backups for a specific point-in-time.

```sql
CREATE SCHEMA SALES_BACKUP CLONE SALES AT (TIMESTAMP => '2024-12-01 00:00:00');
```

Use this to analyze data before/after changes or rollback operations.

**3. Data Science and Analytics**

Data scientists can experiment with models using cloned datasets.

```sql
CREATE DATABASE ANALYTICS_CLONE CLONE PROD_ANALYTICS;
```

No waiting for data copying or ETL processes.

**4. Version Control of Data**

You can maintain multiple data versions for comparison or regression testing.

```sql
CREATE TABLE SALES_V1 CLONE SALES;
CREATE TABLE SALES_V2 CLONE SALES;
```

Then compare versions easily:

```sql
SELECT * FROM SALES_V2
MINUS
SELECT * FROM SALES_V1;
```

**5. Hotfix or Emergency Patching**

Clone production data into a sandbox environment to safely apply hotfixes or transformations.

```sql
CREATE SCHEMA PROD_HOTFIX CLONE PROD_DB.PUBLIC;
```
---

## 13.7 Cloning and Time Travel

Snowflake integrates Zero-Copy Cloning with Time Travel, allowing cloning at historical points.

Example:

```sql
CREATE TABLE SALES_AUDIT CLONE SALES BEFORE (STATEMENT => '01a0e0a4-040d-4d2b-bbd5-611b8c62f5d3');
```

This lets you reconstruct the state of your table before a specific DML statement was executed.

---
## 13.8 Performance and Cost Considerations  

| Aspect             | Behavior                                                      |
| ------------------ | ------------------------------------------------------------- |
| **Storage**        | Minimal additional cost until data diverges                   |
| **Performance**    | Clones perform as fast as originals (shared micro-partitions) |
| **Concurrency**    | Independent read/write operations                             |
| **Maintenance**    | Clones can be dropped independently                           |
| **Data Retention** | Cloned data respects Time Travel settings of the source       |  

Example Benchmark  

| Operation               | Time Taken | Storage Growth |
| ----------------------- | ---------- | -------------- |
| Clone 1TB Database      | 2 seconds  | ~0 MB          |
| Clone + Modify 10% Data | 2 seconds  | 100 GB         |  

---

## 13.9 Limitations and Best Practices
Limitations

- Cannot clone external tables or materialized views.  
- Does not clone temporary or transient tables if their retention has expired.  
- Cloning large databases may take longer for metadata operations.  
- Time travel retention must overlap for successful historical cloning.

  **Best Practices**

✅ Use cloning for **environment provisioning** (Dev/Test/UAT).  
✅ Combine cloning + time travel for **data recovery**.  
✅ Drop unused clones to reduce **storage cost growth**.  
✅ Regularly monitor **STORAGE_USAGE_HISTORY** for clone footprint.  

---

## 13.10 Monitoring Clones

To find all cloned objects in your account:

```sql
SELECT 
  DATABASE_NAME,
  CLONE_GROUP_ID,
  CREATED,
  OWNER,
  IS_TRANSIENT
FROM SNOWFLAKE.ACCOUNT_USAGE.DATABASES
WHERE CLONE_GROUP_ID IS NOT NULL;
```

To check storage usage by clone:

```sql
SELECT * FROM SNOWFLAKE.ACCOUNT_USAGE.STORAGE_USAGE_HISTORY;
```
---

## 13.11 Advanced Scenario — Clone Automation with Streams & Tasks

You can automate cloning for backup or version management using Snowflake tasks:

```sql
CREATE OR REPLACE TASK DAILY_CLONE_TASK
WAREHOUSE = 'COMPUTE_WH'
SCHEDULE = 'USING CRON 0 0 * * * UTC'
AS
CREATE DATABASE PROD_CLONE_{{CURRENT_DATE()}} CLONE PROD_DB;
```

This will create a daily clone of your production database automatically.

---
## 13.12 Summary

Zero-Copy Cloning is a game-changing feature of Snowflake — enabling instant, storage-efficient duplication of data environments.

Key Takeaways:
- Cloning uses copy-on-write, not physical duplication.  
- Ideal for Dev/Test/Backup scenarios.  
- Integrated with Time Travel for point-in-time cloning.  
- Performance remains identical to the source object.  
- Minimal storage cost until data diverges.  
