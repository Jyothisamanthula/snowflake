# 📘 Chapter 22: Snowflake Fail-safe and Data Replication for Disaster Recovery (DR)

## 🎯 Chapter Overview

Even with Time Travel and zero-copy cloning, enterprises need **disaster recovery (DR)** capabilities for extreme cases such as regional outages, accidental data deletion beyond retention, or full cloud provider failures.

Snowflake provides **Fail-safe** and **Data Replication** to protect data and ensure business continuity across regions and cloud platforms.

This chapter covers:

- What is Fail-safe and when it applies  
- Understanding the Data Lifecycle in Snowflake  
- Data Replication (Account, Database, Object-level)  
- Failover and Failback mechanisms  
- Multi-region disaster recovery architecture  
- Hands-on mini DR setup project  
- Best practices and cost considerations  

---

## 📖 Table of Contents

**1.** Introduction to Fail-safe  
**2.** The Snowflake Data Lifecycle  
**3.** Understanding Fail-safe Behavior  
**4.** Data Replication Overview  
**5.** Enabling Cross-Region Database Replication  
**6.** Setting Up Failover and Failback  
**7.** Hands-On Mini Project: Multi-Region DR Setup  
**8.** Monitoring, Validation, and Best Practices  
**9.** Summary

---

## 1️⃣ Introduction to Fail-safe

**Fail-safe** is Snowflake’s **final layer of data protection**, designed to recover data that can no longer be restored through Time Travel.
It is not **user-accessible** — only **Snowflake Support** can perform recovery during this phase.

- Duration: **7 days** (fixed, cannot be changed)
- Access: **Snowflake-managed only**
- Purpose: Protect data in case of catastrophic failure or operator error
  

**🧩 Example:**  
If you drop a table and it stays deleted beyond your Time Travel period (say 3 days), it moves into Fail-safe for 7 more days.  

---


## 2️⃣ The Snowflake Data Lifecycle 

| Phase           | Description                               | Duration  | Access         |
| --------------- | ----------------------------------------- | --------- | -------------- |
| **Active Data** | Data currently available in tables        | Unlimited | Full           |
| **Time Travel** | Retains historical data for undo/recovery | 1–90 days | Customer       |
| **Fail-safe**   | Final data protection layer               | 7 days    | Snowflake only |  


**📘 Illustration Example:**

```sql
Day 0: Table dropped
Day 1–3: Time Travel available (user can restore)
Day 4–10: Fail-safe active (Snowflake support only)
After Day 10: Data permanently deleted
```
---

## 3️⃣ Understanding Fail-safe Behavior

Fail-safe is **not meant for routine recovery** but for **emergency restoration** when data loss is unrecoverable through Time Travel.

Key properties:

- Snowflake retains deleted data in secure internal storage.  
- Data in Fail-safe is **read-only**.  
- Only Snowflake engineers can recover it upon request.  
- Restored data may take **hours or days** depending on size.  

**📘 Important Note:**
Fail-safe is available only for **Permanent tables**.  
**Temporary** and **Transient** tables bypass Fail-safe entirely.

---

## 4️⃣ Data Replication Overview

While Fail-safe protects data from loss,**Data Replication** provides **business continuity** by maintaining **live**, **synchronized copies** of your data across regions or cloud providers.

Snowflake supports:

- **Database Replication**   
- **Account Replication**    
- **Failover and Failback**    

**Use cases:**

- Cross-region disaster recovery  
- Geo-distributed analytics  
- Multi-cloud data sharing  
- Read replicas for latency optimization

---

## 5️⃣ Enabling Cross-Region Database Replication

You can replicate any database across Snowflake accounts in **different regions** or **cloud platforms**.

**Step 1 — Create a Primary Database**

```sql
CREATE OR REPLACE DATABASE finance_db;
```
**Step 2 — Grant Replication Privilege**

```sql
GRANT REPLICATION ON DATABASE finance_db TO ROLE ACCOUNTADMIN;
```
**Step 3 — Create a Secondary Database (Target Region)**

```sql
CREATE DATABASE finance_db_secondary
AS REPLICA OF finance_db AT ORGANIZATION '<org_name>';
```

**Step 4 — Refresh Replicated Data**

```sql
ALTER DATABASE finance_db_secondary REFRESH;
```

⏱️ This synchronizes changes from the primary to the secondary database.

---

## 6️⃣ Setting Up Failover and Failback

Snowflake enables automatic or manual **failover** between replicated databases in case of regional downtime.

**Enable Failover**

```sql
ALTER DATABASE finance_db ENABLE FAILOVER TO ACCOUNTS <target_account>;
```

**Perform Failover (Switch Roles)**

```sql
SYSTEM$FAILOVER_DATABASE('finance_db', 'finance_db_secondary');
```

Now the secondary database becomes **primary**, allowing full read-write operations.

**Failback (Reverting)**

Once the original region is back online:

```sql
SYSTEM$FAILBACK_DATABASE('finance_db_secondary', 'finance_db');
```

✅ Data synchronization is handled automatically.

---

## 7️⃣ Hands-On Mini Project: Multi-Region DR Setup

**🎯 Objective**

Set up **replication and failover** between two Snowflake accounts:

- **Primary**: AWS `ap-south-1` (Mumbai)  
- **Secondary**: AWS `ap-southeast-1` (Singapore)

  

**Step 1 — Create Database in Primary Account**

```sql
CREATE OR REPLACE DATABASE sales_data;
USE DATABASE sales_data;
CREATE OR REPLACE TABLE transactions (
  order_id STRING,
  amount NUMBER,
  region STRING,
  order_date DATE
);

INSERT INTO transactions VALUES
('O1001', 500, 'IN', '2025-10-13'),
('O1002', 1200, 'SG', '2025-10-13');
```

**Step 2 — Enable Replication**

```sql
ALTER DATABASE sales_data ENABLE REPLICATION TO ACCOUNTS 'ORG1.ACCOUNT2';
```

**Step 3 — Create Secondary Database in Target Account**  

```sql
CREATE DATABASE sales_data_replica AS REPLICA OF ORG1.ACCOUNT1.sales_data;
```

**Step 4 — Validate Replication**  

```sql
SELECT COUNT(*) FROM sales_data_replica.INFORMATION_SCHEMA.TABLES;
```  
**Step 5 — Perform Failover**

Simulate a failover to Singapore:

```sql
SYSTEM$FAILOVER_DATABASE('sales_data', 'sales_data_replica');
```

**Step 6 — Update Data in Secondary and Failback**  

```sql
INSERT INTO sales_data_replica.transactions VALUES ('O1003', 900, 'SG', '2025-10-14');
SYSTEM$FAILBACK_DATABASE('sales_data_replica', 'sales_data');
```  

✅ Data is automatically synced back to the primary.  

---

## 8️⃣ Monitoring, Validation, and Best Practices  

**Monitoring Replication Status**

```sql
SHOW REPLICATION ACCOUNTS;
SHOW DATABASES LIKE '%_replica%';
```

**Validate Sync Health**  

```sql
SELECT SYSTEM$DATABASE_REFRESH_PROGRESS('sales_data_replica');
```
---

## Best Practices

✅ Use **Business Critical Edition** for cross-region replication.  
✅ Keep **Fail-safe enabled** for critical tables.  
✅ Regularly **test failover and failback** operations.  
✅ Enable **Network Policies** and **MFA** for secure DR environments.  
✅ Use **Account Replication** for enterprise-wide protection.  
✅ Store replication metadata in a **monitoring dashboard** (e.g., Streamlit or Power BI).  

---

## 🧠 Summary

| Feature              | Description                                         |
| -------------------- | --------------------------------------------------- |
| **Fail-safe**        | Final 7-day Snowflake-managed recovery window       |
| **Replication**      | Copy data across regions/clouds for DR or analytics |
| **Failover**         | Promote secondary database during outage            |
| **Failback**         | Revert operations to original region post-recovery  |
| **Supported Scopes** | Database and Account-level                          |
| **Edition Required** | Enterprise or higher                                |  

---



## 🔑 Key Takeaways

- Fail-safe is the **last resort for recovery**, managed by Snowflake engineers.  
- Data replication enables **cross-region and multi-cloud resilience**.  
- You can **failover and failback** seamlessly between regions.  
- Regular DR testing ensures **RPO/RTO** objectives are met.  
- Combine **Fail-safe + Replication** for robust business continuity planning.  
