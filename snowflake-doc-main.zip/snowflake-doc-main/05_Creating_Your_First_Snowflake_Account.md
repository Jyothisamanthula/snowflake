# 🧭 Chapter 5: Creating Your First Snowflake Account and Running Your First Query

---

## 5.1 Objective

In this chapter, you’ll:
- Create a free Snowflake trial account  
- Explore the web interface (Snowsight)  
- Create your first database, schema, and table  
- Load sample data and run your first SQL queries  
- Understand key account and role concepts

---

## 5.2 Snowflake Editions Overview

Before signing up, you’ll choose from different **Snowflake Editions**, which determine available features and pricing.

| Edition | Target Users | Key Features |
|----------|---------------|---------------|
| **Standard** | Small teams | Basic features, secure data sharing |
| **Enterprise** | Medium orgs | Multi-cluster warehouses, materialized views |
| **Business Critical** | Regulated industries | Enhanced encryption, compliance, data masking |
| **Virtual Private Snowflake (VPS)** | Enterprises | Dedicated infrastructure for isolation |

🧠 *The 30-day free trial usually comes with **Enterprise Edition** and $400 credits.*

---

## 5.3 Step 1: Sign Up for Snowflake

1. Go to [https://signup.snowflake.com](https://signup.snowflake.com)
2. Select your **Cloud Provider** (AWS, Azure, or GCP)
3. Choose a **Region** close to your users (e.g., `AWS - Asia Pacific (Mumbai)`)
4. Enter:
   - Your work email
   - Company name
   - First & last name
5. Submit the form → You’ll receive an activation email
6. Click the activation link and set your **username & password**

✅ After setup, you’ll be redirected to **Snowsight**, Snowflake’s modern web interface.

---

## 5.4 Step 2: Explore Snowsight (Web Interface)

Snowsight organizes your environment into main sections:

| Section | Description |
|----------|--------------|
| **Databases** | View and manage databases, schemas, and tables |
| **Worksheets** | Write and execute SQL queries |
| **Warehouses** | Create and monitor compute clusters |
| **Data Marketplace** | Access shared datasets |
| **Admin** | Manage roles, users, and usage metrics |

🧭 **Navigation Tip:**  
Use the **left sidebar** to switch between data objects and SQL worksheets.

---

## 5.5 Step 3: Create Your First Virtual Warehouse

A **warehouse** is your compute engine. Without it, queries can’t run.

```sql
-- Create a small warehouse
CREATE OR REPLACE WAREHOUSE WH_TRAINING
  WITH WAREHOUSE_SIZE = 'XSMALL'
  AUTO_SUSPEND = 120
  AUTO_RESUME = TRUE;
```

| Parameter        | Description                                         |
| ---------------- | --------------------------------------------------- |
| `WAREHOUSE_SIZE` | Determines compute capacity                         |
| `AUTO_SUSPEND`   | Time (in seconds) after which idle warehouse pauses |
| `AUTO_RESUME`    | Automatically resumes when a query runs             |

✅ After creation, start the warehouse manually or let it auto-resume.

---
## 5.6 Step 4: Create Database and Schema

Snowflake stores all your objects under databases and schemas.

```sql
-- Create a database and schema
CREATE OR REPLACE DATABASE DEMO_DB;
CREATE OR REPLACE SCHEMA DEMO_DB.PUBLIC;
```

Check your location:

```sql
-- Verify your context
SELECT CURRENT_DATABASE(), CURRENT_SCHEMA();
```

Output:
```diff
+--------------------+------------------+
| CURRENT_DATABASE() | CURRENT_SCHEMA() |
+--------------------+------------------+
| DEMO_DB            | PUBLIC           |
+--------------------+------------------+
```
---

## 5.7 Step 5: Create Your First Table

Now, let’s create a sample table for sales data.

```sql
CREATE OR REPLACE TABLE DEMO_DB.PUBLIC.SALES (
  ORDER_ID INT,
  REGION STRING,
  PRODUCT STRING,
  AMOUNT NUMBER(10,2),
  ORDER_DATE DATE
);
```

Confirm creation:

```sql
SHOW TABLES IN SCHEMA DEMO_DB.PUBLIC;
```

✅ You’ll see your SALES table listed.

## 5.8 Step 6: Insert Sample Data

You can insert a few sample rows manually.

```sql
INSERT INTO DEMO_DB.PUBLIC.SALES VALUES
(1, 'EAST', 'LAPTOP', 800.00, '2025-01-01'),
(2, 'WEST', 'MOBILE', 600.00, '2025-02-15'),
(3, 'SOUTH', 'TABLET', 450.00, '2025-03-10');
```

Verify data:

```sql
SELECT * FROM DEMO_DB.PUBLIC.SALES;
```

Output:
```diff
+----------+--------+----------+--------+------------+
| ORDER_ID | REGION | PRODUCT  | AMOUNT | ORDER_DATE |
+----------+--------+----------+--------+------------+
| 1        | EAST   | LAPTOP   | 800.00 | 2025-01-01 |
| 2        | WEST   | MOBILE   | 600.00 | 2025-02-15 |
| 3        | SOUTH  | TABLET   | 450.00 | 2025-03-10 |
+----------+--------+----------+--------+------------+
```
---
## 5.9 Step 7: Run Your First Analytical Query

Try aggregating sales by region:

```sql
SELECT REGION, SUM(AMOUNT) AS TOTAL_SALES
FROM DEMO_DB.PUBLIC.SALES
GROUP BY REGION
ORDER BY TOTAL_SALES DESC;
```

Expected Output:
```diff
+--------+-------------+
| REGION | TOTAL_SALES |
+--------+-------------+
| EAST   | 800.00      |
| WEST   | 600.00      |
| SOUTH  | 450.00      |
+--------+-------------+
```

✅ Congratulations — you’ve executed your first Snowflake query!

---

## 5.10 Step 8: Understanding Roles and Privileges

Snowflake uses Role-Based Access Control (RBAC).
Each user operates under a role, which grants specific privileges.

Common Roles
| Role             | Description                               |
| ---------------- | ----------------------------------------- |
| **ACCOUNTADMIN** | Full access (for setup and configuration) |
| **SYSADMIN**     | Can create databases, warehouses          |
| **PUBLIC**       | Default role with minimal privileges      |
| **USERADMIN**    | Manages users and roles                   |

Example:
```sql
-- Check current role
SELECT CURRENT_ROLE();

-- Grant permissions
GRANT USAGE ON DATABASE DEMO_DB TO ROLE SYSADMIN;
GRANT ALL PRIVILEGES ON SCHEMA DEMO_DB.PUBLIC TO ROLE SYSADMIN;
```

🧠 Always use least-privilege principle in production.

---
## 5.11 Step 9: Using Built-In Sample Datasets

Snowflake provides public datasets to explore analytics quickly.

```sql
USE ROLE SYSADMIN;
USE DATABASE SNOWFLAKE_SAMPLE_DATA;
SHOW SCHEMAS;

-- Query sample TPCH data
SELECT
  O_ORDERPRIORITY,
  COUNT(*) AS ORDER_COUNT
FROM TPCH_SF1.ORDERS
GROUP BY O_ORDERPRIORITY
ORDER BY ORDER_COUNT DESC;
```

Output (sample):
```diff
+----------------+-------------+
| O_ORDERPRIORITY | ORDER_COUNT |
+----------------+-------------+
| 5-LOW           | 10500       |
| 1-URGENT        | 10320       |
| 2-HIGH          | 10045       |
+----------------+-------------+
```

💡 Great for testing performance and analytics functions.
---
## 5.12 Step 10: Saving and Sharing Worksheets

You can save your SQL scripts for future use:

**1.** Click Worksheet → Save As → My First Snowflake Script

**2.** Add comments and titles for readability

**3** Optionally share with teammates using role-based permissions

---
## 5.13 Troubleshooting Common Setup Issues
| Issue                | Cause                 | Solution                           |
| -------------------- | --------------------- | ---------------------------------- |
| ❌ Query blocked      | No active warehouse   | Start or resume your warehouse     |
| ⚠️ No privileges     | Role restrictions     | Switch to SYSADMIN or ACCOUNTADMIN |
| ❗ Copy command fails | File format mismatch  | Define correct delimiter/format    |
| 💰 Credit depletion  | Trial credits expired | Contact Snowflake for extension    |

---
## 5.14 Summary

✅ You have successfully:

- Created a Snowflake account

- Set up your first warehouse, database, schema, and table

- Loaded and queried data

- Explored roles and privileges

- Used built-in sample datasets

🎯 You’re now ready to build ETL pipelines, dashboards, and data sharing setups in Snowflake.
