# 📘 Chapter 28: Real-Time Streaming and Change Data Capture (CDC) with Snowflake and Kafka  

## 🎯 Chapter Overview  

In today’s world of dynamic business operations, **real-time data processing** is no longer optional — it’s essential.
Snowflake offers multiple mechanisms to **ingest and process streaming data** with **low latency**, enabling near real-time analytics.

In this chapter, you will learn:

- The difference between batch and real-time ingestion  
- How to capture **changes (CDC)** from source databases    
- How to stream data using **Kafka, Snowpipe, and Snowpipe Streaming API**    
- How to integrate Snowflake with **Kafka Connect**  
- How to design a **real-time analytics architecture** in Snowflake  
- Hands-on mini-project using Kafka + Snowflake  

---

## 📖 Table of Contents

**1.** What is Real-Time Streaming?  
**2.** Understanding Change Data Capture (CDC)  
**3.** Snowflake’s Real-Time Ingestion Options  
**4.** Snowpipe Overview  
**5.** Snowpipe Streaming (Low-Latency Ingestion)  
**6.** Apache Kafka Integration with Snowflake  
**7.** CDC from Databases (PostgreSQL, MySQL, Oracle)  
**8.** Building a Real-Time Analytics Architecture  
**9.** Hands-On Project — Kafka + Snowflake Real-Time Sales Dashboard  
**10.** Best Practices and Performance Tuning  
**11.** Summary    

---


## 1️⃣ What is Real-Time Streaming?  

**🕒 Traditional vs Real-Time**

| Ingestion Type | Frequency                          | Latency          | Example Use Case                         |
| :------------- | :--------------------------------- | :--------------- | :--------------------------------------- |
| **Batch**      | Scheduled intervals (hourly/daily) | Minutes to hours | Daily sales aggregation                  |
| **Streaming**  | Continuous flow                    | Seconds          | Real-time fraud detection, stock trading |  

  
Real-time streaming means **data flows into Snowflake continuously** — allowing instant insights and dashboards that reflect live updates.  

---

## 2️⃣ Understanding Change Data Capture (CDC)  

**Change Data Capture (CDC)** refers to identifying and capturing **data changes (INSERT, UPDATE, DELETE)** in real-time from source systems.  

**💡 Why CDC Matters**

- Minimizes load by ingesting only **changed records**  
- Enables **real-time synchronization** between operational DBs and Snowflake  
- Supports **incremental updates** in analytics and ML pipelines  

**🔹 Common CDC Tools**  

| Tool                  | Description                                             |
| :-------------------- | :------------------------------------------------------ |
| **Debezium**          | Open-source CDC framework for MySQL, PostgreSQL, Oracle |
| **Fivetran / HVR**    | Managed CDC connectors                                  |
| **Snowflake Streams** | Native CDC inside Snowflake for internal tables         |  

---

## 3️⃣ Snowflake’s Real-Time Ingestion Options  

| Method                 | Description                          | Use Case                                 |
| :--------------------- | :----------------------------------- | :--------------------------------------- |
| **COPY INTO**          | Bulk load (batch)                    | Periodic ingestion from files            |
| **Snowpipe**           | Auto-load from cloud storage         | Near real-time ingestion (1–2 min delay) |
| **Snowpipe Streaming** | Low-latency ingestion API (<1 sec)   | High-frequency streams from Kafka, Spark |
| **Kafka Connector**    | Integrate directly with Kafka topics | Enterprise real-time ingestion           |  

  
## 4️⃣ Snowpipe Overview

**Snowpipe** automates continuous data loading from cloud storage (S3, Azure, GCS).

**🔹 How It Works**

**1.** Files are uploaded to stage  
**2.** Notification event triggers Snowpipe  
**3.** Data is automatically loaded into target tables    


**Example — Create Snowpipe**  

```sql
CREATE OR REPLACE PIPE sales_pipe
AS
COPY INTO SALES_STREAM
FROM @my_s3_stage/sales
FILE_FORMAT = (TYPE = CSV, SKIP_HEADER=1);
```

**Example — Enable Auto Ingest**  

```sql
CREATE NOTIFICATION INTEGRATION my_s3_integration
TYPE = QUEUE
ENABLED = TRUE
DIRECTION = INBOUND;
```

## 5️⃣ Snowpipe Streaming (Low-Latency Ingestion)

Introduced to address **sub-second latency, Snowpipe Streaming** allows inserting data directly into Snowflake **without file staging**.  

**🧩 Benefits**

- Real-time data loading directly via API
- Bypasses S3 / GCS staging
- Ideal for Kafka, Spark, or custom microservices
  

**Python Example — Using Snowpipe Streaming SDK**  

```python
from snowflake.snowpark import Session
from snowflake.snowpark.files import SnowflakeFile
from snowflake.snowpipe_streaming import StreamWriter

connection_parameters = {
  "account": "<account_name>",
  "user": "<user>",
  "password": "<password>",
  "role": "SYSADMIN",
  "warehouse": "STREAM_WH",
  "database": "SALES_DB",
  "schema": "PUBLIC"
}

session = Session.builder.configs(connection_parameters).create()
writer = StreamWriter(session=session, table="REALTIME_SALES")

for i in range(1000):
    writer.write({
        "order_id": i,
        "customer_id": f"CUST-{i}",
        "amount": 100 + i
    })

writer.close()
```

✅ Data is streamed in **milliseconds**, bypassing cloud stage uploads.  

---

## 6️⃣ Apache Kafka Integration with Snowflake

Snowflake provides a **Kafka Connector** that continuously streams data from Kafka topics into Snowflake tables.  

**🔹 Architecture**  

```css
Kafka → Snowflake Kafka Connector → Snowpipe Streaming → Target Table
```

**🔹 Steps to Configure**  

**Step 1: Install Connector (Confluent Hub)**  

```bash
confluent-hub install snowflakeinc/snowflake-kafka-connector:latest
```

**Step 2: Define Connector Configuration (JSON)**  

```json
{
  "name": "snowflake-connector",
  "connector.class": "com.snowflake.kafka.connector.SnowflakeSinkConnector",
  "topics": "sales_events",
  "snowflake.url.name": "abc123.snowflakecomputing.com",
  "snowflake.user.name": "SNOWFLAKE_USER",
  "snowflake.private.key": "<private_key>",
  "snowflake.database.name": "STREAM_DB",
  "snowflake.schema.name": "PUBLIC",
  "snowflake.table.name": "REALTIME_SALES",
  "buffer.count.records": "1000",
  "buffer.flush.time": "60"
}
```

**Step 3: Deploy the Connector**  

```bash
curl -X POST -H "Content-Type: application/json" \
--data @connector-config.json \
http://localhost:8083/connectors
```


✅ Snowflake automatically handles schema evolution and ingestion.  

---


##  7️⃣ CDC from Databases (PostgreSQL, MySQL, Oracle)

Use **Debezium** or **Fivetran** to stream changes from OLTP systems into Kafka, then ingest into Snowflake.

**Example — Debezium PostgreSQL Connector**  

```json
{
  "name": "pg-connector",
  "connector.class": "io.debezium.connector.postgresql.PostgresConnector",
  "database.hostname": "localhost",
  "database.port": "5432",
  "database.user": "cdc_user",
  "database.password": "cdc_pass",
  "database.dbname": "sales_db",
  "topic.prefix": "pg_sales",
  "plugin.name": "pgoutput"
}
```


✅ Each row change generates an event → sent to Kafka → pushed into Snowflake.  

---


## 8️⃣ Building a Real-Time Analytics Architecture  

**🧱 Reference Architecture**  

```lua
+-------------------+       +-----------------+        +-----------------+
|  Source Databases | --->  |  Kafka Topics   | --->   | Snowflake Table |
+-------------------+       +-----------------+        +-----------------+
                                |                            |
                                |     Snowpipe Streaming      |
                                +------------+----------------+
                                             |
                                     +-------v------+
                                     | BI Dashboards |
                                     +---------------+

```

**Components:**  

- **Debezium / Fivetran** → capture CDC
- **Kafka** → event broker
- **Snowflake Kafka Connector** → stream to Snowflake
- **Snowflake Streams + Tasks** → downstream ETL
- **Tableau / Power BI** → live analytics

---


## 9️⃣ Hands-On Project — Real-Time Sales Dashboard (Kafka + Snowflake)  

**🧰 Objective**

Stream live sales data from Kafka to Snowflake and visualize in BI.

**Steps**  

**Step 1: Create Target Table**  

```sql
CREATE OR REPLACE TABLE REALTIME_SALES (
  ORDER_ID STRING,
  CUSTOMER_ID STRING,
  AMOUNT FLOAT,
  EVENT_TIME TIMESTAMP_NTZ
);
```

**Step 2: Setup Kafka Topic**  

```bash
kafka-topics.sh --create --topic sales_events --bootstrap-server localhost:9092
```

**Step 3: Produce Streaming Data**  

```bash
kafka-console-producer.sh --topic sales_events --bootstrap-server localhost:9092
>{"order_id":"O1001","customer_id":"C001","amount":450.75,"event_time":"2025-10-13T09:45:00"}
```

**Step 4: Configure Snowflake Kafka Connector**

Use JSON config (as shown in Section 6).  

**Step 5: Query Real-Time Data**  

```sql
SELECT
  ORDER_ID,
  CUSTOMER_ID,
  AMOUNT,
  EVENT_TIME
FROM REALTIME_SALES
ORDER BY EVENT_TIME DESC;
```

**Step 6: Create Materialized View**  

```sql
CREATE MATERIALIZED VIEW SALES_SUMMARY AS
SELECT CUSTOMER_ID, SUM(AMOUNT) AS TOTAL_SPENT
FROM REALTIME_SALES
GROUP BY CUSTOMER_ID;
```

✅ Now, connect Power BI or Tableau to this view for **live sales monitoring**.  


## 🔟 Best Practices and Performance Tuning  

| Area                 | Best Practice                                       |
| :------------------- | :-------------------------------------------------- |
| **Latency**          | Use Snowpipe Streaming for sub-second loads         |
| **Buffer Size**      | Tune Kafka buffer count and flush time              |
| **Schema Evolution** | Enable auto schema detection in Snowflake connector |
| **Error Handling**   | Enable DLQs (Dead Letter Queues) for bad messages   |
| **Governance**       | Mask sensitive columns using DDM                    |
| **Monitoring**       | Use Snowflake’s `LOAD_HISTORY` view for load status |  

---

## 11. Summary

| Concept                       | Description                                   |
| :---------------------------- | :-------------------------------------------- |
| **Real-Time Streaming**       | Continuous ingestion for immediate analytics  |
| **CDC (Change Data Capture)** | Tracks row-level changes from source DBs      |
| **Snowpipe**                  | Automated near-real-time ingestion            |
| **Snowpipe Streaming**        | Low-latency API-based streaming               |
| **Kafka Connector**           | Direct integration for event-driven pipelines |  

---


## 🧠 Key Takeaways : 

- Snowflake provides a **complete streaming architecture** for modern data needs.  
- **Snowpipe Streaming** and **Kafka** Connector bring near-zero-latency ingestion.  
- CDC pipelines with Debezium and Kafka enable real-time analytics.  
- Combining Snowflake Streams, Tasks, and BI tools completes the real-time data stack.  
