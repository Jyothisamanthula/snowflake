# 📘 Chapter 26: Machine Learning with Snowflake and External Integrations (Snowflake ML, SageMaker, Vertex AI)  


## 🎯 Chapter Overview  


Machine Learning (ML) is no longer separate from data — it’s becoming an **integrated part of the data lifecycle**.  
With **Snowflake ML**, and seamless integration with **AWS SageMaker, Google Vertex AI**, and other frameworks, Snowflake now allows teams to **train, deploy, and infer models directly on Snowflake data** — without massive data movement.

This chapter explains:

- What Snowflake ML is and how it works  
- How to prepare data for ML inside Snowflake  
- How to train models natively and externally  
- How to integrate with AWS SageMaker and Vertex AI  
- Real-world ML use cases  
- Hands-on project: Customer Churn Prediction    

---

## 📖 Table of Contents

**1.** Introduction to Machine Learning in Snowflake  
**2.** What is Snowflake ML?  
**3.** Snowflake ML Architecture  
**4.** Preparing Data for Machine Learning  
**5.** Using Snowpark for ML Feature Engineering  
**6.** Training Models inside Snowflake (Snowflake ML)  
**7.** Integrating with AWS SageMaker  
**8.** Integrating with Google Vertex AI  
**9** Hands-On Mini Project — Customer Churn Prediction  
**10.** Model Deployment and Inference  
**11.** Best Practices  
**12.** Summary  

---


## 1️⃣ Introduction to Machine Learning in Snowflake

Snowflake’s goal is to make **AI and ML accessible directly where data resides**.
Instead of exporting data into Pandas or Spark, you can now:

- Train ML models **inside Snowflake** (using Snowflake ML)  
- Or **connect to external ML platforms** like SageMaker or Vertex AI  
- Or use **Snowpark** for data prep and model inference in Python  

✅ The result: No complex ETL or data duplication — **ML runs on governed, secure Snowflake data**.  

---

## 2️⃣ What is Snowflake ML?

**Snowflake ML** is an integrated suite of capabilities for:

- Feature engineering and storage
- Model training and deployment
- Model inference directly inside Snowflake

It brings **end-to-end machine learning** *inside* the data platform.

---

## 🔍 Key Components  

| Component                 | Description                                              |
| :------------------------ | :------------------------------------------------------- |
| **Snowpark ML**           | Python SDK for model training & inference                |
| **Feature Store**         | Central repository for storing reusable features         |
| **Model Registry**        | Tracks trained models and versions                       |
| **In-DB Inference**       | Run predictions using registered models inside Snowflake |
| **External Integrations** | Connects to AWS SageMaker, Vertex AI, Azure ML, etc.     |  

---  

## 3️⃣ Snowflake ML Architecture  

```pgsql
+---------------------------------------------------+
|                 Snowflake ML Stack                |
|---------------------------------------------------|
|  Streamlit Apps / External Clients (Dashboards)   |
|---------------------------------------------------|
|  Model Inference Layer (UDFs, Snowpark ML)        |
|  Model Registry + Feature Store                   |
|---------------------------------------------------|
|  Data Layer (Snowflake Tables, Views)             |
|---------------------------------------------------|
|  External Connectors: SageMaker | Vertex | Databricks |
+---------------------------------------------------+
```

✅ **Everything operates securely within the Snowflake data plane** — with optional offloading to cloud ML services.  

---  


## 4️⃣ Preparing Data for Machine Learning

Before ML training, your data must be:

- Cleaned
- Normalized
- Feature-engineered
  

**Example — Data Prep**  

```sql
CREATE OR REPLACE TABLE CUSTOMER_DATA AS
SELECT
  CUSTOMER_ID,
  AGE,
  INCOME,
  TENURE,
  SPENDING_SCORE,
  CHURN_FLAG
FROM RAW_CUSTOMER;  
```


Then use Snowpark Python to transform features.

```python
from snowflake.snowpark import Session
from snowflake.snowpark.functions import col, when_

session = Session.builder.configs(connection_params).create()

df = session.table("CUSTOMER_DATA")
df = df.with_column("HIGH_INCOME", when_(col("INCOME") > 75000, 1).otherwise(0))
df = df.drop("INCOME")
df.show()
```

✅ All preprocessing occurs inside Snowflake compute — no data export needed.  

---  

## 5️⃣ Using Snowpark for ML Feature Engineering

**Snowpark DataFrames** are ideal for scalable feature creation.  

**Example — Feature Transformation**  

```python
from snowflake.snowpark.functions import mean, stddev

# Feature scaling
avg_age = df.agg(mean(col("AGE")).alias("avg")).collect()[0]["avg"]
df_scaled = df.with_column("AGE_NORM", (col("AGE") - avg_age))
```


You can store features in a **Feature Store** for reuse across multiple ML models:

```python
df_scaled.write.save_as_table("CUSTOMER_FEATURES", mode="overwrite")   
```

---


## 6️⃣ Training Models Inside Snowflake (Snowflake ML)

With Snowflake ML, you can train directly in Snowflake’s compute layer.  

**Example — Training Logistic Regression Model**  

```python
from snowflake.ml.modeling.linear_model import LogisticRegression
from snowflake.ml.utils.connection_params import SnowflakeLoginOptions

model = LogisticRegression(label_cols=["CHURN_FLAG"])
model.fit(df_scaled)
model.save("CUSTOMER_CHURN_MODEL")  
```


✅ Model and metadata are stored securely in Snowflake’s **Model Registry**.   

---  


## 7️⃣ Integrating with AWS SageMaker  

If you prefer using SageMaker for training:

**1.** Create an external stage to S3.  
**2.** Export features from Snowflake to S3.  
**3.** Train models in SageMaker using the exported dataset.  


**Example — Export Data to S3** 

```sql
COPY INTO 's3://ml-bucket/customer_features/'
FROM CUSTOMER_FEATURES
FILE_FORMAT = (TYPE = CSV, FIELD_OPTIONALLY_ENCLOSED_BY='"')
OVERWRITE = TRUE;
```


**Example — Connect Snowflake to SageMaker** 

Use `boto3` within Python:  


```python
import boto3
sagemaker = boto3.client('sagemaker')

# Launch training job
response = sagemaker.create_training_job(
    TrainingJobName='customer-churn-snowflake',
    AlgorithmSpecification={'TrainingImage': 'xgboost', 'TrainingInputMode': 'File'},
    InputDataConfig=[{'DataSource': {'S3DataSource': {'S3Uri': 's3://ml-bucket/customer_features/'}}}],
    OutputDataConfig={'S3OutputPath': 's3://ml-bucket/output/'},
    ResourceConfig={'InstanceType': 'ml.m5.xlarge', 'InstanceCount': 1, 'VolumeSizeInGB': 20}
)
```


✅ You can bring the trained model back into Snowflake using external function integration.  

---

## 8️⃣ Integrating with Google Vertex AI

**Vertex AI** provides end-to-end ML pipelines on GCP.  
Snowflake’s external function feature allows direct interaction.  


**Example — External Function Setup**  

```sql

CREATE OR REPLACE EXTERNAL FUNCTION vertex_predict(
  age FLOAT, tenure FLOAT, spending FLOAT
)
RETURNS FLOAT
API_INTEGRATION = vertex_integration
HEADERS = ( 'Authorization' = 'Bearer <token>' )
MAX_BATCH_ROWS = 50
AS 'https://vertex.googleapis.com/v1/projects/myproject/models/churn:predict';
```

**Call Vertex Model from Snowflake**  

```sql

SELECT CUSTOMER_ID, vertex_predict(AGE, TENURE, SPENDING_SCORE)
FROM CUSTOMER_FEATURES;

```


✅ Predictions from Vertex AI flow directly back into Snowflake tables — no manual data transfers.  


---

## 9️⃣ Hands-On Mini Project — Customer Churn Prediction  

**🎯 Goal** 


Build and deploy a churn prediction model using Snowflake ML and integrate results with SageMaker.

**Step 1 — Prepare Data**  

```sql
CREATE OR REPLACE TABLE CUSTOMER_TRAIN AS
SELECT CUSTOMER_ID, AGE, TENURE, SPENDING_SCORE, CHURN_FLAG
FROM RAW_CUSTOMER;
```

**Step 2 — Train Model (Snowflake ML)**  

```python
from snowflake.ml.modeling.linear_model import LogisticRegression

model = LogisticRegression(label_cols=["CHURN_FLAG"])
model.fit(df_scaled)
model.save("CHURN_MODEL_V1")
```  

**Step 3 — Predict**  

```python
predictions = model.predict(df_scaled)
predictions.show()
```


**Step 4 — Save Results**  

```python
predictions.write.save_as_table("CUSTOMER_CHURN_PREDICTIONS", mode="overwrite")
```


✅ Full training and inference happen in Snowflake.  


---

## 🔟 Model Deployment and Inference

Deployed models can be called like SQL functions:

```sql
SELECT CUSTOMER_ID, PREDICT_CHURN(AGE, TENURE, SPENDING_SCORE)
FROM CUSTOMER_FEATURES;
```  

Or used in **Streamlit** dashboards for live predictions.

---

## 🧩 Real-World Use Cases  


| Industry      | Use Case                  | Description                                       |
| :------------ | :------------------------ | :------------------------------------------------ |
| Retail        | Customer Churn Prediction | Identify customers likely to cancel subscriptions |
| Finance       | Fraud Detection           | Real-time transaction anomaly detection           |
| Healthcare    | Risk Scoring              | Predict patient risk scores from claims data      |
| Manufacturing | Predictive Maintenance    | Detect machine failure patterns                   |  

---  


## 🔧 Best Practices  

  
| Area        | Recommendation                                                |
| :---------- | :------------------------------------------------------------ |
| Data Prep   | Use Snowpark for scalable feature engineering                 |
| Security    | Avoid data export when possible — prefer in-platform training |
| Governance  | Store all models in the Snowflake Model Registry              |
| Performance | Filter and sample before training large datasets              |
| Cost        | Use appropriately sized warehouses for training workloads     |  


---

## 🧠 Summary

| Concept                   | Description                                                |
| :------------------------ | :--------------------------------------------------------- |
| **Snowflake ML**          | Built-in feature store, model registry, and in-DB training |
| **Snowpark ML**           | SDK for Python-based ML directly in Snowflake              |
| **External Integrations** | SageMaker, Vertex AI, Databricks, Azure ML                 |
| **In-DB Inference**       | Predict with models stored inside Snowflake                |
| **Governance**            | Centralized model lifecycle and data access control        |  



---

## 🔑 Key Takeaways

- Snowflake ML enables **native training and inference** — no data movement.
- You can integrate with **SageMaker or Vertex AI** for advanced modeling.
- Feature store and model registry simplify model lifecycle management.
- Combine with **Streamlit** for real-time AI dashboards.
