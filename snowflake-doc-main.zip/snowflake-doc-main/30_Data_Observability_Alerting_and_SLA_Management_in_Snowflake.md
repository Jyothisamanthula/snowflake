# Chapter 30: Data Observability, Alerting, and SLA Management in Snowflake  

## 30.1 Overview

In modern data engineering, **data observability** ensures that your data pipelines are **reliable, accurate, and timely**.  
Snowflake provides tools, system views, and integrations to help track data freshness, quality, and performance — essential for meeting **SLAs (Service Level Agreements)** and **SLOs (Service Level Objectives)**.

This chapter covers:  

- What Data Observability means in Snowflake  
- Tracking data quality, freshness, and lineage  
- Setting up alerts using Tasks and External Functions  
- Building SLA dashboards  
- Integrating Snowflake with third-party observability tools

---

## 30.2 What is Data Observability?

**Data Observability** is the practice of continuously monitoring your data systems to ensure they are:

- Accurate
- Fresh
- Complete
- Consistent
- Reliable

It extends the concept of application observability (logs, metrics, traces) into the **data domain**.  

---

## 30.3 Key Pillars of Data Observability  

| Pillar        | Description                                                   |
| ------------- | ------------------------------------------------------------- |
| **Freshness** | Ensures data is updated as expected.                          |
| **Volume**    | Monitors completeness — detects missing or duplicate records. |
| **Schema**    | Detects unintended schema drift (e.g., missing columns).      |
| **Quality**   | Checks for nulls, invalid values, or outliers.                |
| **Lineage**   | Tracks upstream/downstream dependencies for traceability.     |  

---
## 30.4 Monitoring Data Freshness

You can monitor when data was last loaded into a table using Snowflake metadata.  

**Example: Check Data Load Freshness**  

```sql
SELECT
    table_name,
    MAX(last_altered) AS last_load_time,
    DATEDIFF('minute', MAX(last_altered), CURRENT_TIMESTAMP()) AS minutes_since_load
FROM SNOWFLAKE.INFORMATION_SCHEMA.TABLES
WHERE table_schema = 'PUBLIC'
GROUP BY table_name
ORDER BY minutes_since_load;
```  

✅ Helps identify stale tables that haven’t been updated on schedule.  

---

## 30.5 Data Quality Checks  

**Create a Data Quality Audit Table**

```sql
CREATE OR REPLACE TABLE monitoring.data_quality_checks (
    check_name STRING,
    table_name STRING,
    check_status STRING,
    row_count NUMBER,
    error_count NUMBER,
    check_time TIMESTAMP_NTZ
);
```

**Insert Quality Check Results**  

```sql
INSERT INTO monitoring.data_quality_checks
SELECT
    'Null Check on CUSTOMER_ID' AS check_name,
    'CUSTOMERS' AS table_name,
    CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS check_status,
    COUNT(*) AS row_count,
    SUM(CASE WHEN CUSTOMER_ID IS NULL THEN 1 ELSE 0 END) AS error_count,
    CURRENT_TIMESTAMP() AS check_time
FROM SALES_DB.PUBLIC.CUSTOMERS;
```

**View Failed Checks**  

```sql
SELECT * FROM monitoring.data_quality_checks WHERE check_status = 'FAIL';
```

These results can trigger alerts or dashboards for data reliability.  

---

## 30.6 Schema Drift Detection

Schema changes can break downstream processes. Use Snowflake metadata to detect changes in structure.

```sql
SELECT
    table_name,
    column_name,
    data_type,
    created,
    last_altered
FROM SNOWFLAKE.INFORMATION_SCHEMA.COLUMNS
WHERE table_schema = 'PUBLIC'
ORDER BY last_altered DESC;
```  

You can automate this check daily using a **Task**, and compare results with a stored baseline schema.  

---

## 30.7 Data Lineage Tracking

While Snowflake doesn’t yet natively visualize full lineage, it exposes dependency metadata via `OBJECT_DEPENDENCIES` and query history.

**Example: Identify Dependencies**  

```sql
SELECT
    referring_object_name AS downstream_object,
    referenced_object_name AS upstream_object
FROM SNOWFLAKE.ACCOUNT_USAGE.OBJECT_DEPENDENCIES
WHERE referenced_object_domain = 'TABLE';
```

✅ Helps trace the impact of table or view changes across your pipeline.  

---

## 30.8 Alerting in Snowflake

You can implement automated alerts for data or performance anomalies using:

- **Tasks** (for scheduled execution)  
- **External Functions** (for notifications)  
- **Third-party services** (AWS SNS, Slack, PagerDuty, etc.)  

**Example: Create an Alert for Data Delay**  

```sql
CREATE OR REPLACE TASK alert_data_delay
SCHEDULE = 'USING CRON 0 * * * * UTC'  -- Every hour
AS
DECLARE
  v_last_load_time TIMESTAMP;
BEGIN
  SELECT MAX(last_altered) INTO :v_last_load_time
  FROM SNOWFLAKE.INFORMATION_SCHEMA.TABLES
  WHERE table_name = 'CUSTOMER_TRANSACTIONS';
  
  IF DATEDIFF('hour', v_last_load_time, CURRENT_TIMESTAMP()) > 2 THEN
    CALL send_alert_email('Data Delay', 'CUSTOMER_TRANSACTIONS is stale.');
  END IF;
END;
```  

Combine this with an **AWS Lambda** or **Azure Function** for email/SMS alert delivery.  

---

## 30.9 Setting Up SLA Dashboards  

**Step 1: Define SLAs**

Example SLAs:

- Data available by **6 AM UTC daily**
- Load success rate > **99.5%**
- Query performance < **5 seconds average**

**Step 2: Create SLA Metrics Table**  

```sql
CREATE TABLE monitoring.sla_metrics (
    process_name STRING,
    sla_target STRING,
    actual_value STRING,
    sla_status STRING,
    checked_at TIMESTAMP_NTZ
);
```

**Step 3: Automate SLA Checks**  

```sql
CREATE OR REPLACE TASK task_sla_monitor
SCHEDULE = 'USING CRON 0 6 * * * UTC'
AS
INSERT INTO monitoring.sla_metrics
SELECT
    'Daily ETL Load',
    'Completed by 6 AM UTC',
    CASE WHEN MAX(last_altered) >= DATEADD('hour', -1, CURRENT_TIMESTAMP())
         THEN 'ON TIME' ELSE 'DELAYED' END AS actual_value,
    CASE WHEN MAX(last_altered) >= DATEADD('hour', -1, CURRENT_TIMESTAMP())
         THEN 'PASS' ELSE 'FAIL' END AS sla_status,
    CURRENT_TIMESTAMP()
FROM SALES_DB.PUBLIC.CUSTOMER_TRANSACTIONS;
```  

**Step 4: Visualize in Snowsight or Power BI**  

You can connect the `monitoring.sla_metrics` table to a BI tool to display SLA compliance trends.  

---

## 30.10 Integration with Observability Tools

Snowflake can integrate with enterprise observability and monitoring platforms:  

| Tool                           | Purpose                                        |
| ------------------------------ | ---------------------------------------------- |
| **DataDog / New Relic**        | Query and warehouse metrics                    |
| **Monte Carlo / Bigeye**       | End-to-end data observability                  |
| **Alation / Collibra**         | Data lineage and governance                    |
| **Sigma / Tableau / Power BI** | SLA and data health dashboards                 |
| **CloudWatch / Stackdriver**   | Monitor external integrations and compute jobs |

**Integration Example: DataDog**

- Configure Snowflake’s **Account Usage API** as a data source.  
- Push metrics such as query count, credits consumed, load freshness.  
- Set custom DataDog monitors (e.g., “Alert if data freshness > 2 hours”).

---

## 30.11 SLA Reporting Dashboard (Hands-On Project)  

**Objective**

Build an automated SLA dashboard that monitors daily data loads and query latency.

**Step 1: Create SLA Table**  

```sql
CREATE OR REPLACE TABLE monitoring.daily_sla_report AS
SELECT
    TO_DATE(start_time) AS run_date,
    warehouse_name,
    COUNT(*) AS total_queries,
    AVG(total_elapsed_time/1000) AS avg_duration_sec,
    SUM(CASE WHEN execution_status = 'SUCCESS' THEN 1 ELSE 0 END) AS success_count,
    SUM(CASE WHEN execution_status != 'SUCCESS' THEN 1 ELSE 0 END) AS failure_count
FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
WHERE start_time >= DATEADD('day', -7, CURRENT_TIMESTAMP())
GROUP BY 1, 2;
```

**Step 2: Automate Refresh**  

```sql
CREATE OR REPLACE TASK task_refresh_sla_report
SCHEDULE = 'USING CRON 0 0 * * * UTC'
AS
INSERT INTO monitoring.daily_sla_report
SELECT
    TO_DATE(start_time),
    warehouse_name,
    COUNT(*),
    AVG(total_elapsed_time/1000),
    SUM(CASE WHEN execution_status = 'SUCCESS' THEN 1 ELSE 0 END),
    SUM(CASE WHEN execution_status != 'SUCCESS' THEN 1 ELSE 0 END)
FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
WHERE TO_DATE(start_time) = CURRENT_DATE()
GROUP BY 1, 2;
```

**Step 3: Visualize**  

In Snowsight, plot:

✅ SLA compliance % = (success_count / total_queries) × 100  
🚀 Average query duration  
🕒 Load delay trends  

---

## 30.12 Best Practices  

| Category        | Recommendation                                                |
| --------------- | ------------------------------------------------------------- |
| **Freshness**   | Monitor `last_altered` timestamps for critical tables         |
| **Quality**     | Build automated NULL / duplicate / range checks               |
| **Alerting**    | Use Tasks + External Functions for proactive alerts           |
| **SLAs**        | Store SLA results in a dedicated monitoring schema            |
| **Integration** | Connect to observability platforms for centralized visibility |  

---

## 30.13 Summary

- Data Observability ensures that data is **trustworthy, timely, and high-quality**.
- Use **ACCOUNT_USAGE, INFORMATION_SCHEMA**, and **Tasks** for automated checks.
- Establish **alerting mechanisms** for anomalies and SLA breaches.
- Build dashboards for operational visibility and compliance.
- Integrate with enterprise **observability tools** to achieve unified monitoring.
