## 1️⃣ Why and When Should I Consider Airflow?

Airflow is not for everything. It’s for **orchestrating workflows** that:

- Have **multiple steps**
- Need to run on a **schedule** (e.g., daily, hourly, monthly)
- Must **handle failures** and automatically retry  
- Need **visibility** (UI, logs, success/failure state)
- Often involve **external systems**: databases, cloud storage, APIs, ML servers

### Use Airflow when:

- You’re building ETL pipelines:

 	- Extract from APIs + databases
  	- Transform using Python/Spark
	- Load into a data warehouse (Snowflake, BigQuery, Redshift)  
  
- You’re building ML pipelines:

  - Prepare data → Train model → Evaluate → Save → Deploy

- You want **reliable automation**:

	- Daily reports
	- File ingestion
	- Backups
	- Syncing data between systems

### Don’t use Airflow when:

- You just want a **simple script** run occasionally.
- You need **low-latency, event-based** streaming (Kafka/Flink is better).
- You want to process **data in real time, per event** (Airflow is batch-oriented).

**Think of Airflow as:**

	🧠 “The conductor of an orchestra” – it doesn’t play instruments, it coordinates them.

---

## 2️⃣ What is Airflow?

**Apache Airflow is:**

	A platform to author, schedule, and monitor workflows, written as Python code.

**Key characteristics:**

- **Code-as-configuration:** DAGs are Python scripts, version-controllable in Git.
- **Web UI:** visualize DAGs, task statuses, logs.
- **Extensible:** plugins, custom operators/hooks.
- **Scalable:** runs on one machine or a distributed cluster (Celery/Kubernetes).

Workflows in Airflow are defined as **DAGs** – Directed Acyclic Graphs.

---

## 3️⃣ Key Components

At runtime, Airflow consists of several parts working together:  

```pgsql
   ┌───────────┐
   │ Webserver │ → UI to monitor, trigger, debug tasks
   └─────┬─────┘
         │
   ┌─────▼─────┐
   │ Scheduler │ → Determines when tasks should run
   └─────┬─────┘
         │
   ┌─────▼────────┐
   │ Executor     │ → Runs the task code (Local/Celery/K8s)
   └─────┬────────┘
         │
 Metadata Database (Postgres/MySQL)
 Stores DAG runs, XComs, Task states, Logs
```

**3.1 Webserver**

- A **Flask-based web application**.
- Provides the **Airflow UI:**
	- View DAGs and tasks
	- Check logs
	- Trigger DAGs manually
	- Pause/unpause DAGs
	- Configure Connections / Variables
-	Makes it easy to monitor your workflows.

**3.2 Scheduler**

- The **brain** of Airflow.  
- Continuously:
	- Reads DAG definitions
	- Determines what should run now based on:
		- `start_date`
		- `schedule_interval`
		- `current time`

	- Creates **Task Instances** (task + run date)
	- Pushes runnable tasks to the **Executor**

**Handles:**

- Backfill
- Catchup
- Retries
- SLAs

--- 

**3.3 Executor**

The **Executor** decides **where/how** tasks actually run.

Common executors:

**SequentialExecutor** – single process, good for dev.  
**LocalExecutor** – parallel tasks on one machine (multiprocessing).  
**CeleryExecutor** – distributed across multiple workers.  
**KubernetesExecutor** – launches each task in its own Kubernetes pod.


---

**3.4 Metadata Database (Postgres / MySQL)**

- Airflow uses an SQL database to store:
- DAGs & Task instances
- Run states (success, failed, retry, skipped)
- XComs (small data shared between tasks)
- Variables & Connections metadata
- Logs metadata (path references)

Most often: **PostgreSQL** in production.  

---


## 4️⃣ Basic Concepts of Airflow

We’ll go one-by-one.

**4.1 DAGs (Directed Acyclic Graphs)**

A **DAG** is:

- A graph of **tasks**.
- With **edges** representing dependencies (“run B after A”).
- **Acyclic** ⇒ no loops (you can’t depend on yourself in a cycle).

Visually:
```text
start → extract_data → transform_data → load_data → end
```

Code example:

```python
from airflow import DAG
from datetime import datetime, timedelta

default_args = {
    "retries": 1,
}

with DAG(
    dag_id="example_etl",
    start_date=datetime(2024, 1, 1),
    schedule=timedelta(days=1),
    default_args=default_args,
    catchup=False,
) as dag:
    # define tasks here
    pass
```

- `start_date` – when scheduling begins.  
- `schedule / schedule_interval` – how often to run.  
- `catchup` – whether to schedule **past** runs.  

Each time Airflow runs the DAG, it creates a **DAG Run**.

---

**4.2 Tasks**

A **Task** is a **single unit of work** inside a DAG.  
Each task is usually created from an **Operator**.

**Examples:**

`download_data` – Python function to fetch data.  
`run_sql` – executes a SQL query.  
`send_notification` – sends Slack/Email.    


**Every task has:**

- `task_id` – unique name within the DAG.  
- An operator (defining what it does).  
- Config like retries, timeout, SLA.  

---

**4.3 Operators**


In Airflow:

**Operator = a template for a task**

A **Task** is one instance of an operator in a DAG.
The Operator defines what that task does.

Example mental model:

```text
Operator  →  Class / Template (e.g. PythonOperator)
Task      →  Object created from that class (e.g. train_model_task)
```

Code:  

```python
from airflow.operators.python import PythonOperator

def train_model():
    print("Training model...")

train_model_task = PythonOperator(
    task_id="train_model",
    python_callable=train_model
)
```  

- `PythonOperator` → Operator  
- `train_model_task` → Task (specific usage of the operator)  

**Main Categories of Operators**

You’ll often see operators grouped into these conceptual types:

**1. Action Operators** – Do something (run code/commands)  
**2. Transfer Operators** – Move data between systems  
**3. Sensors** – Wait for condition (special Operator type)  
**4. Deferrable Operators** – Async version of some Sensors/Operators  
**5. Provider-specific Operators** – For AWS, GCP, Azure, etc.  
**6. Custom Operators** – Your own operators built on BaseOperator

Let’s go through them in detail.    

---

### Action Operators:

They perform an action:

- Run a shell command
- Run Python function
- Run SQL
- Call an API
- Trigger another DAG

**Common examples:**  

| Operator                | What it does             |
| ----------------------- | ------------------------ |
| `BashOperator`          | Runs bash/shell commands |
| `PythonOperator`        | Runs Python functions    |
| `EmailOperator`         | Sends emails             |
| `MySqlOperator`         | Executes SQL on MySQL    |
| `PostgresOperator`      | Executes SQL on Postgres |
| `TriggerDagRunOperator` | Triggers another DAG     |  

**Example: BashOperator**  

```python
from airflow.operators.bash import BashOperator

clean_tmp_task = BashOperator(
    task_id='clean_temp_files',
    bash_command='rm -rf /tmp/*'
)
```  

**Example: PythonOperator**  

```python  
from airflow.operators.python import PythonOperator

def preprocess():
    print("Preprocessing data")

preprocess_task = PythonOperator(
    task_id='preprocess_data',
    python_callable=preprocess
)
```  

Use **Action Operators** when you want a task to "do work".  

---

### Transfer Operators:

They **move data** from one place to another.

Typical patterns:

- S3 → GCS
- GCS → BigQuery
- Local → S3
- MySQL → S3 etc.

**Example operators:**

| Operator                  | Action                     |
| ------------------------- | -------------------------- |
| `S3ToGCSOperator`         | Copy from AWS S3 to GCS    |
| `GCSToGCSOperator`        | Copy within GCS            |
| `S3FileTransformOperator` | Transform and upload to S3 |
| `MySqlToGCSOperator`      | SQL → GCS                  |
| `GcsToBigQueryOperator`   | GCS → BigQuery             |  


**Example: S3FileTransformOperator**  

```python  
from airflow.providers.amazon.aws.operators.s3_file_transform import S3FileTransformOperator

transform_task = S3FileTransformOperator(
    task_id='transform_file',
    source_s3_key='s3://my-bucket/raw/data.csv',
    dest_s3_key='s3://my-bucket/processed/data_clean.csv',
    transform_script='/opt/airflow/dags/scripts/clean_data.sh'
)
```  
Use **Transfer Operators** when the **main purpose** is data movement.  

---


### Sensors (Special kind of Operator):

  	Sensor = Operator that waits for something

They don’t do work, they **wait**:

- For a file to appear in S3
- For a table to be created in DB
- For an API to respond with 200
- For another DAG/task to finish

**Common Sensors**  

| Sensor               | Waits for…                           |
| -------------------- | ------------------------------------ |
| `FileSensor`         | File exists on filesystem            |
| `S3KeySensor`        | Object exists in S3                  |
| `ExternalTaskSensor` | Another DAG/task to finish           |
| `HttpSensor`         | API call returns successful response |  

**Example: S3KeySensor**  



```python  
from airflow.providers.amazon.aws.sensors.s3 import S3KeySensor

wait_for_file = S3KeySensor(
    task_id='wait_for_raw_data',
    bucket_name='my-bucket',
    bucket_key='raw/data.csv',
    poke_interval=60,   # check every 60 seconds
    timeout=60 * 60     # fail after 1 hour
)
```  

Use **Sensors** when your next task depends on some external event  

---

### Deferrable Operators:

**Problem with normal Sensors:**  
They block an Airflow worker slot while waiting, which **wastes resources**.

**Deferrable Operators** fix this:

- They “sleep” in an async way using triggerer
- They do not occupy a full worker process while waiting
- Great for long waits (files, external events, APIs)

**Examples:**

- `DateTimeSensorAsync`
- `S3KeySensorAsync`
- `ExternalTaskSensorAsync`

Use **Deferrable Operators** when tasks are mostly wait time, not CPU work.

---

### Provider Package Operators:

These are **integrations** for external systems, available via **provider packages**:

Examples:

- `airflow.providers.amazon.aws.operators.*`
- `airflow.providers.google.cloud.operators.*`
- `airflow.providers.cncf.kubernetes.operators.*`
- `airflow.providers.slack.operators.slack`

**Example: KubernetesPodOperator (from CNCF provider)**  

```python  
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator

run_model = KubernetesPodOperator(
    task_id='run_model',
    name='run-model',
    namespace='default',
    image='myimage:latest',
    cmds=['python', 'run_model.py']
)
```  

These are still Action/Transfer/Sensor types but **specific to cloud platforms and tools**.  

---
  
### Custom Operators:

Sometimes built-in operators are not enough.  
Then you **create your own**, by extending BaseOperator.

**Simple Example:**  

```python 
from airflow.models.baseoperator import BaseOperator

class PrintMessageOperator(BaseOperator):
    def __init__(self, message: str, **kwargs):
        super().__init__(**kwargs)
        self.message = message

    def execute(self, context):
        print(f"Message from custom operator: {self.message}")
```  

**Use it in DAG:**  

```python  
hello_task = PrintMessageOperator(
    task_id='say_hello',
    message='Hello Airflow!'
)
```
Custom operators are powerful when you have **repeated logic** used in many DAGs.

---


**4.4 Task Dependencies**

Dependencies tell Airflow **in what order to run tasks**.

Common patterns:

```python
task1 >> task2           # task1 before task2
task1 >> [task2, task3]  # task1 before both task2 and task3
[task2, task3] >> task4  # task4 waits for both

# or with methods
task1.set_downstream(task2)
task3.set_upstream(task1)
```

This builds your **DAG graph**.  

---

**4.5 XComs (Cross-Communication)**

XComs are a way for tasks to **share small bits of data**.

Workflow:

- One task **pushes** a value.
- Another task **pulls** it.

Example:

```python
from airflow.operators.python import PythonOperator
from airflow import DAG

dag = DAG("xcom_example")

def train_model(ti):
    model_path = "/tmp/model.pkl"
    ti.xcom_push(key="model_path", value=model_path)

def deploy_model(ti):
    path = ti.xcom_pull(key="model_path", task_ids="train_model")
    print("Using model at:", path)

train_task = PythonOperator(
    task_id="train_model",
    python_callable=train_model,
    dag=dag,
)

deploy_task = PythonOperator(
    task_id="deploy_model",
    python_callable=deploy_model,
    dag=dag,
)

train_task >> deploy_task
```
🔴 Don’t use XCom for big objects (e.g., dataframes) – store them in S3/DB and pass location via XCom.

--- 

**4.6 TaskFlow API**

TaskFlow API is a more Pythonic way to define DAGs using decorators (@dag, @task).

Instead of `PythonOperator`, you do:

```python
from airflow.decorators import dag, task
from datetime import datetime

@dag(start_date=datetime(2024,1,1), schedule="@daily", catchup=False)
def ml_pipeline():

    @task
    def load_data():
        return [1, 2, 3]

    @task
    def transform(data):
        return [x * 2 for x in data]

    @task
    def save(result):
        print("Saving:", result)

    raw = load_data()
    processed = transform(raw)
    save(processed)

ml_dag = ml_pipeline()
```  
Benefits:

- Dependencies are implied by function calls.
- XComs are automatically used under the hood.
- Code is more readable & maintainable.   

---  

**4.7 Scheduling**

Airflow runs tasks **based on schedules**.

You set scheduling via `schedule_interval` (or `schedule` in newer versions):

Examples:  
- @daily` – once every day
- `@hourly` – once every hour
- `@once` – run only once
- Cron: `"0 2 * * *"` – every day at 2 AM
- `timedelta(days=1)` – run every day

Two important concepts:

**Catchup**

If `catchup=True` and your `start_date` was 7 days ago, Airflow will schedule runs for **all past intervals**.

If `catchup=False`, Airflow only schedules from now onwards.

**Backfill**

Manual command to create and run historical DAG runs:

```bash
airflow backfill -s 2024-01-01 -e 2024-01-05 my_dag
```  
---  
**4.8 Variables**

Variables are **key-value configuration** stored in Airflow metadata DB.

Uses:

- Store config like:
 	- API tokens  
    - paths
	- thresholds
- Override logic per environment (dev/stage/prod)

Example:

```python
from airflow.models import Variable

threshold = Variable.get("ALERT_THRESHOLD", default_var="0.8")
```  
You can manage them from:

- Airflow UI → Admin → Variables
- Environment variables
- CLI  

---  



**4.9 Triggers and Trigger Rules**

**Trigger rules** control when a task is **allowed** to run, based on its upstream tasks.

Common values:

- `all_success` (default): all upstream tasks must succeed.
- `one_success`: at least one upstream task must succeed.
- `all_failed`: run only if all upstream tasks failed.
- `none_failed`: no upstream task failed (can be skipped/success).

Example:  

```python
from airflow.operators.python import PythonOperator

notify = PythonOperator(
    task_id="notify_failure",
    python_callable=send_alert,
    trigger_rule="one_failed",
)
```  

This will run `notify_failure` if any upstream task fails.  

---    

**4.10 Connections**

Connections store **credentials & endpoints** safely.

Each connection has:

- Conn ID (e.g. my_postgres)
- Host, Port
- Username/Password
- Extra JSON (for configs)

Setup:

- Airflow UI → Admin → Connections
- Env vars or config files.  


Then use in Hooks/Operators:  

```python
from airflow.providers.postgres.hooks.postgres import PostgresHook

hook = PostgresHook(postgres_conn_id="my_postgres")
conn = hook.get_conn()
```  

---  

**4.11 Hooks**

Hooks are **Python wrappers around external systems**.

They:

- Manage authentication
- Provide helper methods:
	- `download_file`
	- `run_query`
	- `upload_blob`

Examples:

- `PostgresHook`
- `S3Hook`
- `GCSHook`
- `MySqlHook`
- `HttpHook`

Hooks are used **inside Operators** or `PythonOperator` callables.  

---  

**4.12 Hooks vs Operators**

**Hook**

- Low-level.
- "How to talk to S3/Postgres/etc."
- No scheduling or task context – just connection & actions.

**Operator**

- High-level.
- Represents a task in DAG.
- Uses hooks internally to do work.

Example:  

```python
class MyPostgresOperator(BaseOperator):
    def execute(self, context):
        hook = PostgresHook(postgres_conn_id="pg_conn")
        hook.run("DELETE FROM table;")
```  

---  

**4.13 Datasets**

Datasets allow **data-aware scheduling**.

Instead of scheduling a DAG by time, you can say:

`“Run DAG B whenever dataset X is updated by DAG A.”`

Used for:

- Data-driven workflows.
- More explicit data dependencies across DAGs.  

---  


**4.14 Executors**

Determines **how tasks are executed**.  

| Executor           | Description                                |
| ------------------ | ------------------------------------------ |
| SequentialExecutor | One task at a time (for testing)           |
| LocalExecutor      | Parallel tasks on one machine              |
| CeleryExecutor     | Distributed execution via multiple workers |
| KubernetesExecutor | Each task runs in its own pod              |

Pick based on scale:

- Small lab: `LocalExecutor`  
- Medium cluster: `CeleryExecutor`  
- K8s-native: `KubernetesExecutor`  

--- 

**4.15 Provider Packages**

Airflow’s power comes from **provider packages**:

Examples:

- `apache-airflow-providers-amazon`
- `apache-airflow-providers-google`
- `apache-airflow-providers-microsoft-azure`
- `apache-airflow-providers-databricks`
- `apache-airflow-providers-cncf-kubernetes`

They provide:

- Operators
- Hooks
- Sensors
- Extras

For specific platforms.  

---

**4.16 Manage Flow of Tasks**

Managing flow includes:

**Branching:**
- Use BranchPythonOperator to choose a path.

**Task Groups:**

- Organize multiple tasks into a collapse-able unit in UI.

**Parallelism:**

 - Run tasks in parallel where no dependency exists.

**Trigger rules:**

 - Control behavior based on upstream outcomes.

Example branching:  

```python
from airflow.operators.branch import BranchPythonOperator

def choose_path(**context):
    if context['ds'] == '2024-01-01':
        return "special_task"
    return "normal_task"

branch = BranchPythonOperator(
    task_id="branch_logic",
    python_callable=choose_path,
)

branch >> [special_task, normal_task]
```  

---  

## 5️⃣ Advanced Concepts (Overview)

Some advanced but important topics:

**Dynamic DAGs:**

- Generate tasks dynamically based on config or input (e.g. one task per table).

**Custom XCom Backends:**

- Store large objects in S3 or external store with custom logic.

**Plugins:**

- Extend Airflow with your own:

	- View menus
	- Operators
	- Hooks

**Event-based Triggers:**

- Using webhooks or external APIs to trigger DAG runs.

**Scaling & HA:**

- Multi-scheduler setups, multi-worker clusters, KEDA for scaling on Kubernetes.  

---  

## 6️⃣ Airflow Best Practices

Some real-world rules teams follow:

**1. Idempotent tasks**

- Running a task twice should not break anything.  
- Example: load “incremental only” data, not whole table.  

**2. Atomic tasks**

- Each task should do one clear thing.
- Easier retries and debugging.

**3. Avoid heavy top-level code**  

- Don’t query DB or read big files at import time.
- That code runs every time scheduler parses DAGs.

**4. Use TaskFlow API where possible**

- Cleaner dependency handling.
- Fewer manual XCom calls.

**5. Use Variables & Connections**

- Don’t hard-code credentials or environment-specific paths.

**6. Keep DAGs small & focused**

- Easier to reason about.
- Faster parsing and scheduling.

**7. Proper logging**
- Always log important steps, inputs, outputs, and decisions.   


---

## 📘 Apache Airflow Jinja Templating — Complete Tutorial

Airflow uses **Jinja2 templating** to dynamically generate values such as file paths, SQL queries, timestamps, and parameters during **runtime**.  

This allows workflows to be flexible, parameterized, reusable, and environment-friendly.  

### 🧠 What is Jinja Templating in Airflow?

Jinja2 is a mini-template language that lets Airflow replace values dynamically when a task executes.  

```jinja
{{ ... }} → Inserts values / expressions
{% ... %} → Logic (loops, if-else)
```  
**Example – print execution date:**  

```python
bash_command="echo {{ ds }}"
```  

At runtime, Airflow replaces {{ ds }} with execution date, e.g.:  

```yaml
2025-02-10
```  
--- 
### 💡 Why Use Jinja in Airflow?

Because your workflows shouldn't be static.  

| Without Jinja ❌           | With Jinja ✔                       |
| ------------------------- | ---------------------------------- |
| Hard-coded SQL dates      | Automatic per execution date       |
| Static file paths         | Dynamic based on `{{ ds }}`        |
| Cannot parameterize logic | Variables & conditions become easy |  

Example:

```sql
SELECT * FROM sales WHERE date='{{ ds }}';
```  

Every run picks the correct date automatically.  

--- 

### 🧩 Where Can You Use Templating?  

| Component              | Supports Jinja |
| ---------------------- | -------------- |
| SQL scripts            | ✔              |
| Bash, Shell commands   | ✔              |
| File paths             | ✔              |
| PythonOperator kwargs  | ✔              |
| Email content          | ✔              |
| Custom Operator fields | ✔              |  

If a field is in templated_fields, Jinja can be used.  

--- 

### 🔥 Built-in Airflow Jinja Macros

Airflow provides many macros automatically in the Jinja context.  

**1. Execution Date & Time Macros**  

| Macro                     | Example                     | Meaning                     |
| ------------------------- | --------------------------- | --------------------------- |
| `{{ ds }}`                | `2025-02-10`                | Execution date (YYYY-MM-DD) |
| `{{ ds_nodash }}`         | `20250210`                  | Without dashes              |
| `{{ ts }}`                | `2025-02-10T02:00:00+00:00` | Execution ISO timestamp     |
| `{{ ts_nodash }}`         | `20250210T020000`           | Timestamp no separators     |
| `{{ ts_nodash_with_tz }}` | `20250210T020000+0000`      | Timestamp w/ timezone       |
| `{{ prev_ds }}`           | Yesterday                   | Previous run date           |
| `{{ next_ds }}`           | Tomorrow                    | Next run date               |
| `{{ yesterday_ds }}`      | -1 day shortcut             |                             |
| `{{ tomorrow_ds }}`       | +1 day shortcut             |                             |

**Usage in SQL:**  

```sql
WHERE run_date = '{{ ds }}';
```  
<br> 

**2. Data Interval Macros (Airflow 2.2+)**

Used for incremental ETL loads.  

| Macro                       | Meaning                        |
| --------------------------- | ------------------------------ |
| `{{ data_interval_start }}` | Start time of execution window |
| `{{ data_interval_end }}`   | End time of execution window   |  

```sql

WHERE ts BETWEEN '{{ data_interval_start }}' AND '{{ data_interval_end }}'

```    
<br>  

**3. Context Objects**

| Macro                               | Object                     |
| ----------------------------------- | -------------------------- |
| `{{ dag }}`                         | DAG object                 |
| `{{ task }}`                        | Task object                |
| `{{ ti }}` or `{{ task_instance }}` | Task instance (pull XCom)  |
| `{{ run_id }}`                      | Current DAG Run id         |
| `{{ logical_date }}`                | Exact time logic evaluated |
| `{{ dag_run }}`                     | DAG run object             |
| `{{ params }}`                      | Operator runtime params    |
| `{{ macros }}`                      | Access helper functions    |
| `{{ conf }}`                        | airflow.cfg access         |  

<br>  

**4. Utility Helper Macros — macros.***    

📅 Date Helpers  

| Function                                     | Use                    |
| -------------------------------------------- | ---------------------- |
| `macros.ds_add(ds, 3)`                       | Add days               |
| `macros.ds_add(ds, -5)`                      | Go back 5 days         |
| `macros.ds_format(ds,"%Y-%m-%d","%d-%m-%Y")` | Reformat date          |
| `macros.datetime()`                          | Create datetime        |
| `macros.timedelta(days=1)`                   | Time window operations |  


**Example:**  

```jinja

{{ macros.ds_add(ds, -7) }}   → last week date
```  
**Timezone conversion:**  

```jinja
{{ macros.as_timezone(logical_date, "Asia/Kolkata") }}
```  

<br>  

**5. Variables & Environment**  

| Object            | Meaning                    |
| ----------------- | -------------------------- |
| `var.value.<key>` | Airflow Variable as string |
| `var.json.<key>`  | Variable as JSON dict      |
| `env_var("NAME")` | Read OS env variable       |  

**Example:**  

```jinja
{{ var.value.API_KEY }}
{{ env_var("USERNAME") }}
```  

<br> 

**6. Dataset Macros (Airflow 2.4+)**  

| Macro                 | Meaning                  |
| --------------------- | ------------------------ |
| `dataset.uri`         | Dataset URI              |
| `dataset.last_update` | Last dataset update time |  

<br>

**7. Filters**

1️⃣ | ds — Convert datetime to YYYY-MM-DD

Default Airflow datetime includes time:  

```makefile
2025-02-10T08:00:00Z
```  

Applying filter:  

```jinja
{{ logical_date | ds }}
```  

Output:  

```yaml
2025-02-10
```  

2️⃣ | ds_nodash — Remove dashes  

```jinja
{{ ds }}
```    

returns:  

```yaml
2025-02-10
```  
But if you need a filename or partition value:  

```jinja
{{ ds | ds_nodash }}
```  

Output:
```yaml 
20250210
```  

<br> 

**8. XCom Pull Retrieval**  

```jinja
{{ ti.xcom_pull('extract_task') }}
```  
---  
### 🔥 How Airflow Renders Templates  

**Basic Example – BashOperator**  

```python
BashOperator(
    task_id="show_date",
    bash_command="echo {{ ds }}"
)
```  

Output at runtime:  
```bash
echo 2025-02-10
```  

**SQL Example**  

```python

query = """
SELECT * FROM orders
WHERE date = '{{ ds }}'
"""

PostgresOperator(
    task_id="load_orders",
    sql=query
)
```  

**File Path Example**  

```python
file_path="/data/raw/orders_{{ ds_nodash }}.csv"
```  

Output:

```text 
orders_20250210.csv 

```

**Loops & Conditions**  

```jinja
{% for i in range(3) %}
echo File {{ i }}
{% endfor %}
```  

```jinja
{% if ds.endswith('01') %}
echo New month processing!
{% endif %}
```  

**Passing Parameters**  

```python
PostgresOperator(
    task_id="dynamic_table",
    sql="SELECT * FROM {{ params.tablename }}",
    params={"tablename": "customers"}
)
``` 

---


### 🧪 Real-World ETL Example Using Macros  

```python

from airflow.decorators import dag, task
from datetime import datetime

@dag(schedule="@daily", start_date=datetime(2024,1,1), catchup=False)
def sales_pipeline():

    @task
    def extract():
        return "/source/sales_{{ ds }}.json"

    @task
    def transform(path):
        print("Processing:", path)

    @task
    def load():
        query = """
        INSERT INTO sales_partitioned
        SELECT * FROM staging
        WHERE load_date = '{{ ds }}';
        """
        return query

    transform(extract()) >> load()

sales_pipeline()
```  

---  


## First Airflow DAG:

```python

import textwrap
from datetime import datetime, timedelta

# Operators; we need this to operate!
from airflow.providers.standard.operators.bash import BashOperator

# The DAG object; we'll need this to instantiate a DAG
from airflow.sdk import DAG
with DAG(
    "tutorial",     # Name of the DAG
    # These args will get passed on to each operator
    # You can override them on a per-task basis during operator initialization
    default_args={
        "depends_on_past": False,
        "retries": 1,
        "retry_delay": timedelta(minutes=5),
        # 'queue': 'bash_queue',
        # 'pool': 'backfill',
        # 'priority_weight': 10,
        # 'end_date': datetime(2016, 1, 1),
        # 'wait_for_downstream': False,
        # 'execution_timeout': timedelta(seconds=300),
        # 'on_failure_callback': some_function, # or list of functions
        # 'on_success_callback': some_other_function, # or list of functions
        # 'on_retry_callback': another_function, # or list of functions
        # 'sla_miss_callback': yet_another_function, # or list of functions
        # 'on_skipped_callback': another_function, #or list of functions
        # 'trigger_rule': 'all_success'
    },
    description="A simple tutorial DAG",
    schedule=timedelta(days=1),
    start_date=datetime(2021, 1, 1),
    catchup=False,
    tags=["example"],
) as dag:

    # t1, t2 and t3 are examples of tasks created by instantiating operators
    t1 = BashOperator(
        task_id="print_date",
        bash_command="date",
    )

    t2 = BashOperator(
        task_id="sleep",
        depends_on_past=False,
        bash_command="sleep 5",
        retries=3,
    )
    t1.doc_md = textwrap.dedent(
        """\
    #### Task Documentation
    You can document your task using the attributes `doc_md` (markdown),
    `doc` (plain text), `doc_rst`, `doc_json`, `doc_yaml` which gets
    rendered in the UI's Task Instance Details page.
    ![img](https://imgs.xkcd.com/comics/fixing_problems.png)
    **Image Credit:** Randall Munroe, [XKCD](https://xkcd.com/license.html)
    """
    )

    dag.doc_md = __doc__  # providing that you have a docstring at the beginning of the DAG; OR
    dag.doc_md = """
    This is a documentation placed anywhere
    """  # otherwise, type it like this
    templated_command = textwrap.dedent(
        """
    {% for i in range(5) %}
        echo "{{ ds }}"
        echo "{{ macros.ds_add(ds, 7)}}"
    {% endfor %}
    """
    )

    t3 = BashOperator(
        task_id="templated",
        depends_on_past=False,
        bash_command=templated_command,
    )

    t1 >> [t2, t3]  
    
  ```


#### 🧠 Jinja Templating in Tasks

Airflow lets you use **dynamic values** in commands using Jinja.

Example inside a loop:  

```python

templated_command = """
{% for i in range(5) %}
    echo "{{ ds }}"                     # prints execution date
    echo "{{ macros.ds_add(ds, 7)}}"    # prints date + 7 days
{% endfor %}
"""
```

Useful for:

✔ dynamic dates  
✔ generated filenames  
✔ SQL partitions  
✔ incremental loads  

You may also define custom macros/filters if needed.  

<br>  


#### 📝 Adding Documentation

You can write documentation that appears in the UI.  

```python
t1.doc_md = "This prints the current date"
dag.doc_md = "This is a sample DAG"
```  

**Task docs support:** Text / Markdown / YAML / JSON  
**DAG docs support:** Markdown only  

Good docs make workflows easier to manage later.  

---

**Testing Your Pipeline**  

Now it’s time to test your pipeline! First, ensure that your script parses successfully. If you saved your code in tutorial.py within the Dags folder specified in your airflow.cfg, you can run:  

```python
python ~/airflow/dags/tutorial.py 

```  

If the script runs without errors, congratulations! Your Dag is set up correctly.

Let’s validate your script further by running a few commands:

```bash python

# initialize the database tables
airflow db migrate

# print the list of active Dags
airflow dags list

# prints the list of tasks in the "tutorial" Dag
airflow tasks list tutorial

# prints the graphviz representation of "tutorial" Dag
airflow dags show tutorial

```


**Testing Task Instances and Dag Runs**  

```bash
# command layout: command subcommand [dag_id] [task_id] [(optional) date]

# testing print_date
airflow tasks test tutorial print_date 2015-06-01

# testing sleep
airflow tasks test tutorial sleep 2015-06-01
```

You can also see how your templates get rendered by running:

```bash
# testing templated
airflow tasks test tutorial templated 2015-06-01
```

This command will provide detailed logs and execute your bash command.

Keep in mind that the airflow tasks test command runs task instances locally, outputs their logs to stdout, and doesn’t track state in the database. This is a handy way to test individual task instances.

Similarly, airflow dags test runs a single Dag run without registering any state in the database, which is useful for testing your entire Dag locally.


Notes:

🔹 tasks test runs locally  
🔹 No state is recorded in DB  
🔹 Useful for debugging
---  

## TaskFlow API DAG Deep Dive

| Workflow Style       | Also Known As                | How It Works                                                                           |
| -------------------- | ---------------------------- | -------------------------------------------------------------------------------------- |
| **Normal DAG**       | Operator-Based / Classic DAG | Tasks are created manually using Operators like `BashOperator`, `PythonOperator`, etc. |
| **TaskFlow API DAG** | Decorator-Based DAG          | Tasks are defined as simple Python functions using `@task` decorator.                  |

<br>

### 🟦 1. Normal DAG (Classic / Operator-Based)

You must manually create tasks like this:

```python
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime

def greet():
    print("Hello from Airflow")

with DAG("normal_dag", start_date=datetime(2024,1,1), schedule="@daily") as dag:

    task1 = PythonOperator(
        task_id="greet_task",
        python_callable=greet
    )

    task1
```  

### 🔍 Characteristics:

- Tasks defined using `PythonOperator`, `BashOperator`, etc.           
- You must pull/push XCom manually                                    
- Task dependencies must be written explicitly                        
- More boilerplate code                                               

### 🟩 2. TaskFlow API (Modern & Pythonic)

Instead of defining tasks using Operators, you write Python functions and convert them into tasks using @task. 

```python
from airflow.decorators import dag, task
from datetime import datetime

@dag(schedule="@daily", start_date=datetime(2024,1,1), catchup=False)
def taskflow_example():

    @task
    def say_hello():
        print("Hello from TaskFlow")

    say_hello()

taskflow_example()
```  

### 🔍 Characteristics:  
- Tasks created using `@task` decorator             
- Return values automatically move through XCom     
- Dependencies created just by using function calls 
- Cleaner, shorter, more readable  

### 🆚 Key Differences  

| Feature               | Normal DAG                  | TaskFlow API                              |
| --------------------- | --------------------------- | ----------------------------------------- |
| How tasks are defined | Using Operators             | Using Python functions                    |
| XCom handling         | Must push manually          | Automatic return/pass                     |
| Dependencies          | `task1 >> task2`            | `task1() >> task2()` or function chaining |
| Code size             | More boilerplate            | Minimal clean code                        |
| Best for              | Mixed tech (Bash/Spark/SQL) | Pure Python workflows                     |


#### 🧠 Biggest Advantage of TaskFlow
You can pass values between tasks like calling functions.  

**Normal DAG (manual XCom):**  

```python

def extract(**context):
    context['ti'].xcom_push(key="value", value=10)

def transform(**context):
    number = context['ti'].xcom_pull(key="value")
    print(number+1)
```

**TaskFlow API (automatic):**  

```python
@task
def extract():
    return 10            # ← automatically XCom

@task
def transform(num):
    print(num + 1)
```  

---
🔥 Full Comparison Example 


**Normal DAG Version**
```python
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime

def extract():
    return 5

def multiply(ti):
    num = ti.xcom_pull(task_ids="extract_task")
    print(num * 2)

with DAG("normal_vs_taskflow", start_date=datetime(2024,1,1), schedule="@daily") as dag:

    extract_task = PythonOperator(task_id="extract_task", python_callable=extract)
    multiply_task = PythonOperator(task_id="multiply_task", python_callable=multiply)

    extract_task >> multiply_task
```  

**Same workflow using TaskFlow API**  

```python
from airflow.decorators import dag, task
from datetime import datetime

@dag(start_date=datetime(2024,1,1), schedule="@daily")
def taskflow_dag():

    @task
    def extract():
        return 5

    @task
    def multiply(num):
        print(num * 2)

    multiply(extract())       # passing output as function input

taskflow_dag()
```  

✔ Cleaner  
✔ Shorter  
✔ More readable    

#### 🧾 Quick Summary  

| TaskFlow API                  | Normal DAG                            |
| ----------------------------- | ------------------------------------- |
| Modern, simple, less code     | Traditional, more verbose             |
| Python functions become tasks | Must define tasks using Operators     |
| Passing data is automatic     | Must push/pull XCom manually          |
| Best for ML/ETL Python logic  | Best for external system integrations |  

#### How to choose?

- If your workflow is mostly Python code → Use TaskFlow API  
- If you use many external services, Spark, SQL, Bash, REST, Kubernetes → Normal DAG   

---
### Python DAGs Examples

**1.LatestOnly.py** 


```phthon  
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.latest_only import LatestOnlyOperator
from airflow.operators.email_operator import EmailOperator
from airflow.utils.dates import days_ago

dag = DAG(
    'LatestOnly',
    default_args={'start_date': days_ago(3)},
    schedule_interval='0 2 * * *',
    catchup=True,
)

# Define tasks
task_a = PythonOperator(
    task_id='task_a',
    python_callable=lambda: print("Executing Task A"),
    dag=dag,
)

task_b = PythonOperator(
    task_id='task_b',
    python_callable=lambda: print("Executing Task B"),
    dag=dag,
)

# Send email based on success
send_email_completed = EmailOperator(
    task_id="send_email_completed",
    to="{{ var.value.get('support_email') }}",
    subject="UK Sales Data Load - Successful",
    html_content="UK Sales Data Load Completed Successfully.",
    dag=dag,
)

# Send email based on failure
send_email_failed = EmailOperator(
    task_id="send_email_failed",
    to="{{ var.value.get('support_email') }}",
    subject="UK Sales Data Load  - Failed",
    html_content="UK Sales Data Load Failed. Please check the logs for more details.",
    dag=dag,
    trigger_rule="all_failed",
)

# Task for LatestOnlyOperator branch
latest_only = LatestOnlyOperator(
    task_id="latest_only", 
    dag=dag)

# Connect tasks
task_a >> task_b >> send_email_failed
task_b >> latest_only >> send_email_completed  
```

**2.conditional_branching.py**

```python
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python_operator import PythonOperator, BranchPythonOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.utils.dates import days_ago

# Function to get file size
def get_file_size(file_path, ti):
    # Get file size in bytes
    with open(file_path, "rb") as f:
        file_size_bytes = len(f.read())

    # Convert bytes to gigabytes
    file_size_gb = file_size_bytes / (1024 ** 3)

    # Push file size to XCom
    ti.xcom_push(key='file_size', value=file_size_gb)

# Function to decide the branch
def decide_branch(ti):
    file_size = ti.xcom_pull(task_ids='check_file_size', key='file_size')
    return 'parallel_transform' if file_size > 10 else 'serial_transform'

# Serial transformation task
def serial_transform():
    # Add your serial transformation logic here
    print("Executing serial transformation")

# Serial load task
def serial_load():
    # Add your serial load logic here
    print("Executing serial load")

# Parallel transformation task
def parallel_transform():
    # Add your parallel transformation logic here
    print("Executing parallel transformation")

# Parallel load task
def parallel_load():
    # Add your parallel load logic here
    print("Executing parallel load")

dag = DAG(
    'conditional_branching',
    default_args={'start_date': days_ago(1)},
    schedule_interval='0 23 * * *',
    catchup=False
)

# Task to check file size
check_file_size = PythonOperator(
    task_id='check_file_size',
    python_callable=get_file_size,
    op_args=['/tmp/source_file_extrat.dat'],
    provide_context=True,
    dag=dag,
)

# Task to decide the branch
decide_branch_task = BranchPythonOperator(
    task_id='decide_branch',
    python_callable=decide_branch,
    provide_context=True,
    dag=dag,
)

# Define tasks for serial execution
serial_transform_task = PythonOperator(
    task_id='serial_transform',
    python_callable=serial_transform,
    dag=dag,
)

serial_load_task = PythonOperator(
    task_id='serial_load',
    python_callable=serial_load,
    dag=dag,
)

# Define tasks for parallel execution
parallel_transform_task = PythonOperator(
    task_id='parallel_transform',
    python_callable=parallel_transform,
    dag=dag,
)

parallel_load_task = PythonOperator(
    task_id='parallel_load',
    python_callable=parallel_load,
    dag=dag,
)

# Set up task dependencies
check_file_size >> decide_branch_task

# Serial branch
decide_branch_task >> serial_transform_task >> serial_load_task

# Parallel branch
decide_branch_task >> parallel_transform_task >> parallel_load_task  
```  

**3.custom_s3_trans.py**  

```python
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.hooks.S3_hook import S3Hook
from airflow.utils.dates import days_ago

# Define your custom transformation function using Hooks
def custom_transformation(bucketname, sourcekey, destinationkey):
    s3_hook = S3Hook(aws_conn_id='aws_conn')
    # Read S3 File
    content = s3_hook.read_key(bucket_name=bucketname, key=sourcekey)

    # Apply Custom Transformations
    transformed_content = content.upper()

    # Load S3 File
    s3_hook.load_string(transformed_content, bucket_name=bucketname, key=destinationkey)

# Define DAG
dag = DAG(
    'cust_s3_trans',
    default_args={'start_date': days_ago(1)},
    schedule_interval='0 23 * * *',
    catchup=False
)

# Define your tasks
transform_task = PythonOperator(
    task_id='transform_task',
    python_callable=custom_transformation,
    op_args=['sleek-data', 'oms/customer.csv', 'oms/customer_transformed.csv'],
    dag=dag,
)

# Define Dependencies
transform_task  
```  

**4.dependsOnPast.py**  

```python
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.utils.dates import days_ago


dag = DAG(
    'depends_on_past',
    default_args={'start_date': days_ago(1)},
    schedule_interval='0 21 * * *',
    catchup=False,
)

# Define tasks
task_a = PythonOperator(
    task_id="task_a",
    python_callable=lambda: print("Executing Task A"),
    dag=dag,
)

task_b = PythonOperator(
    task_id="task_b",
    python_callable=lambda: print("Executing Task B"),
    depends_on_past=True,
    dag=dag,
)


# Connect tasks
task_a >> task_b  
```  

**5.empdata_process.py**  

```python
from airflow import DAG
from airflow.utils.dates import days_ago
from airflow.providers.amazon.aws.sensors.s3 import S3KeySensor
from airflow.providers.snowflake.transfers.copy_into_snowflake import CopyFromExternalStageToSnowflakeOperator

dag = DAG(
    's3_to_snowflake_dag',
    default_args={'start_date': days_ago(1)},
    schedule_interval='0 23 * * *',
    catchup=False
)

# Wait for the file in S3
wait_for_file = S3KeySensor(
    task_id='wait_for_s3_file',
    bucket_name='sleekdata',
    bucket_key='oms/employee_details.csv',
    aws_conn_id='aws_conn',
    poke_interval=10,
    timeout= 60 * 60 * 5,
    soft_fail=True,
    deferrable = True,
    dag=dag
)

# Load the file from S3 to Snowflake
load_table = CopyFromExternalStageToSnowflakeOperator(
    task_id="load_s3_file_to_table",
    snowflake_conn_id="snowflake_conn",
    files=["employee_details.csv"],
    table="SLEEKMART_OMS.L1_LANDING.employee_details",
    stage='my_s3_stage',
    file_format="(type = 'CSV',field_delimiter = ',', skip_header = 1)",
    dag=dag
)

# Set the dependencies
wait_for_file >> load_table  
```  

**6.exchange_rate_pipeline.py**  

```python
# Imports
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.email_operator import EmailOperator
from airflow.operators.python_operator import PythonOperator
from datetime import datetime, timedelta
from clean_data import clean_data

# Define or Instantiate DAG
dag = DAG(
    'exchange_rate_etl',
    start_date=datetime(2023, 10, 1),
    end_date=datetime(2023, 12, 31),
    schedule_interval='0 22 * * *',
    default_args={"retries": 2, "retry_delay": timedelta(minutes=5)},
    catchup=False
)

# Define or Instantiate Tasks
download_task = BashOperator(
    task_id='download_file',
    bash_command='curl -o xrate.csv https://data-api.ecb.europa.eu/service/data/EXR/M.USD.EUR.SP00.A?format=csvdata',
    cwd='/tmp',
    dag=dag,
)

clean_data_task = PythonOperator(
    task_id='clean_data',
    python_callable=clean_data,
    dag=dag,
)

send_email_task = EmailOperator(
    task_id='send_email',
    to='sleekdatasolutions@gmail.com',
    subject='Exchange Rate Download - Successful',
    html_content='The Exchange Rate data has been successfully downloaded, cleaned, and loaded.',
    dag=dag,
)

# Define Task Dependencies
download_task >> clean_data_task >> send_email_task  
``` 

**7.fx_data producer.py**  

```python
from airflow import DAG, Dataset
from airflow.providers.amazon.aws.transfers.http_to_s3 import HttpToS3Operator
from airflow.utils.dates import days_ago
from airflow.models import Variable

dag = DAG(
    "data_producer_dag",
    default_args={"start_date": days_ago(1)},
    schedule_interval="0 23 * * *",
)

http_to_s3_task = HttpToS3Operator(
    task_id="data_producer_task",
    endpoint=Variable.get("web_api_key"),
    s3_bucket="sleek-data",
    s3_key="oms/xrate.json",
    aws_conn_id="aws_conn",
    http_conn_id=None,
    replace=True,
    dag=dag,
    outlets=[Dataset("s3://sleek-data/oms/xrate.json")]
)  

```  

**8.fx_data_consumer.py**

```python
# Imports
from airflow import DAG, Dataset
from airflow.utils.dates import days_ago
from airflow.providers.snowflake.operators.snowflake import SnowflakeOperator

# Define the DAG
dag = DAG(
    'data_consumer_dag',
    default_args={'start_date': days_ago(1)},
    schedule=[Dataset("s3://sleek-data/oms/xrate.json")],

#   We usually code cron-based (or time based) schedule_interval as below:
#   schedule_interval="0 23 * * *",
)

# Define the Task
load_table = SnowflakeOperator(
    task_id='data_consumer_task',
    sql='./sqls/xrate_sf.sql',
    snowflake_conn_id='snowflake_conn',
    dag=dag
)  

```  

**9.git_repo_dag.py**  

```python
from airflow import DAG
from airflow.utils.dates import days_ago
from airflow.providers.github.operators.github import GithubOperator
from airflow.operators.dummy import DummyOperator
import logging

# Define the DAG
dag = DAG(
    'git_repo_dag',
    default_args={'start_date': days_ago(1)},
    schedule_interval='0 21 * * *',
    catchup=False
)

# Start Dummy Operator
start = DummyOperator(task_id='start', dag=dag)

# List GitRepository Tags
list_repo_tags = GithubOperator(
    task_id="list_repo_tags",
    github_method="get_repo",
    github_method_args={"full_name_or_id": "sunapana2003/airflow-demo"},
    result_processor=lambda repo: logging.info(list(repo.get_tags())),
    dag=dag,
)

# End Dummy Operator
end = DummyOperator(task_id='end', dag=dag)

# Define task dependencies
start >> list_repo_tags >> end  

```  
**10.hybrid_dag.py**  

```python
from airflow import DAG
from airflow.decorators import task
from airflow.utils.dates import days_ago
from airflow.providers.snowflake.operators.snowflake import SnowflakeOperator

@task
def extract():
    # Extract logic here
    return "Raw order data"

@task
def transform(raw_data):
    # Transform logic here
    return f"Processed: {raw_data}"

@task
def validate(processed_data):
    # Validate logic here
    return f"Validated: {processed_data}"

@task
def load(validated_data):
    # Load logic here
    print(f"Data loaded successfully: {validated_data}")

dag = DAG(
    'hybrid_dag',
    default_args={'start_date': days_ago(1)},
    schedule_interval='0 21 * * *',
    catchup=False
)

with dag:
    load_task = load(validate(transform(extract())))

    snowflake_task = SnowflakeOperator(
        task_id='Snowflake_task',
        sql='select 1',
        snowflake_conn_id='snowflake_conn',
    )

    load_task >> snowflake_task   
```   

**11.live_exchange_rates.py**  

```python
# Import
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.email_operator import EmailOperator
from airflow.utils.dates import days_ago

# Define the DAG
dag = DAG(
    'live_exchange_rates',
    default_args={'start_date': days_ago(1)},
    schedule_interval='0 23 * * *',
    catchup=False
)

# Define the Tasks
fetch_exchange_rates = BashOperator(
    task_id='fetch_exchange_rates',
    bash_command="curl '{{ var.value.get('web_api_key') }}' -o xrate.json",
    cwd='/tmp',
    dag=dag,
)

send_email_task = EmailOperator(
    task_id='send_email',
    to="{{ var.value.get('support_email') }}",
    subject='Live Exchange Rate Download - Successful.',
    html_content='Live Exchange Rate data has been successfully downloaded.',
    dag=dag,
)



# Define the Dependencies
fetch_exchange_rates >> send_email_task  

``` 

**12.profit_uk.py** 

```python
# Imports
from airflow import DAG
from airflow.utils.dates import days_ago
from airflow.operators.email_operator import EmailOperator
from airflow.providers.snowflake.operators.snowflake import SnowflakeOperator

# Define the DAG
dag = DAG(
    'load_profit_uk',
    default_args={'start_date': days_ago(1)},
    schedule_interval='0 21 * * *',
    catchup=False
)

# Define the Task
load_table = SnowflakeOperator(
    task_id='load_table',
#    sql='./sqls/profit_uk.sql',
    sql='select 1',
    snowflake_conn_id='snowflake_conn',
    dag=dag
)

send_email = EmailOperator(
    task_id='send_email',
    to="{{ var.value.get('support_email') }}",
    subject='UK profit table load - Successful',
    html_content='UK Sales table to Profit table Load Completed',
    dag=dag,
)


# Define the Dependencies
load_table >> send_email  

```  

**13.setup_teardown.py**  

```python
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.utils.dates import days_ago


dag = DAG(
    'setup_teardown',
    default_args={'start_date': days_ago(1)},
    schedule_interval='0 21 * * *',
    catchup=False
)

# Define tasks
create_cluster = PythonOperator(
    task_id='create_cluster',
    python_callable=lambda: print("Creating Cluster"),
    dag=dag,
)

run_query1 = PythonOperator(
    task_id='run_query1',
    python_callable=lambda: print("Running Query 1"),
    dag=dag,
)

# run_query2 = PythonOperator(
#     task_id='run_query2',
#     python_callable=lambda: print("Running Query 2"),
#     dag=dag,
# )

run_query2 = PythonOperator(
    task_id='run_query2',
    python_callable=lambda: raise_exception("Failure in Query 2"),
    dag=dag,
)


run_query3 = PythonOperator(
    task_id='run_query3',
    python_callable=lambda: print("Running Query 3"),
    dag=dag,
)

delete_cluster = PythonOperator(
    task_id='delete_cluster',
    python_callable=lambda: print("Deleting Cluster"),
    dag=dag,
)

# Define task dependencies
create_cluster >> [run_query1, run_query2]
[run_query1, run_query2] >> run_query3
run_query3 >> delete_cluster.as_teardown(setups=create_cluster)  

```

**14.taskflow_api.py**  

```python
from airflow import DAG
from airflow.decorators import task
from airflow.utils.dates import days_ago

@task
def extract():
    # Extract logic here
    return "Raw order data"
@task
def transform(raw_data):
    # Transform logic here
    return f"Processed: {raw_data}"
@task
def validate(processed_data):
    # Validate logic here
    return f"Validated: {processed_data}"
@task
def load(validated_data):
    # Load logic here
    print(f"Data loaded successfully: {validated_data}")

dag = DAG(
    'taskflow_api',
    default_args={'start_date': days_ago(1)},
    schedule_interval='0 21 * * *',
    catchup=False
)

with dag:
    load_task = load(validate(transform(extract())))  
    
```  

**15.tradititional.py**

```python
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.utils.dates import days_ago

def extract(ti=None, **kwargs):
    # Extract logic here
    raw_data = "Raw order data"
    ti.xcom_push(key="raw_data", value=raw_data)

def transform(ti=None, **kwargs):
    # Transformation logic here
    raw_data = ti.xcom_pull(task_ids="extract", key="raw_data")
    processed_data = f"Processed: {raw_data}"
    ti.xcom_push(key="processed_data", value=processed_data)

def validate(ti=None, **kwargs):
    # Validation logic here
    processed_data = ti.xcom_pull(task_ids="transform", key="processed_data")
    validated_data = f"Validated: {processed_data}"
    ti.xcom_push(key="validated_data", value=validated_data)

def load(ti=None, **kwargs):
    # Load logic here
    validated_data = ti.xcom_pull(task_ids="validate", key="validated_data")
    print(f"Data loaded successfully: {validated_data}")

dag = DAG(
    'traditional_dag',
    default_args={'start_date': days_ago(1)},
    schedule_interval='0 21 * * *',
    catchup=False
)

extract_task = PythonOperator(
    task_id="extract",
    python_callable=extract,
    dag=dag,
)

transform_task = PythonOperator(
    task_id="transform",
    python_callable=transform,
    dag=dag,
)

validate_task = PythonOperator(
    task_id="validate",
    python_callable=validate,
    dag=dag,
)

load_task = PythonOperator(
    task_id="load",
    python_callable=load,
    dag=dag,
)

# Set Dependencies
extract_task >> transform_task >> validate_task >> load_task 

``` 

**16.trigger_rules.py**

```python
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.utils.dates import days_ago


dag = DAG(
    'trigger_rules',
    default_args={'start_date': days_ago(1)},
    schedule_interval='0 21 * * *',
    catchup=False
)

# Define tasks
task_a = PythonOperator(
    task_id='task_a',
    python_callable=lambda: raise_exception("Failure in Query a"),
    dag=dag,
)

task_b = PythonOperator(
    task_id='task_b',
    python_callable=lambda: raise_exception("Failure in Query b"),
    dag=dag,
)

task_c = PythonOperator(
    task_id='task_c',
    python_callable=lambda: raise_exception("Failure in Query c"),
    dag=dag,
)

task_d = PythonOperator(
    task_id='task_d',
    python_callable=lambda: print("Executing Task D"),
    dag=dag,
    trigger_rule='all_failed',
)

task_e = PythonOperator(
    task_id='task_e',
    python_callable=lambda: print("Executing Task E"),
    dag=dag,
)

# Define task dependencies
task_a >> task_d
task_b >> task_d
task_c >> task_d
task_d >> task_e
```

**17.welcome_dag.py**

```python
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.utils.dates import days_ago
from datetime import datetime
import requests

def print_welcome():
    print('Welcome to Airflow!')

def print_date():
    print('Today is {}'.format(datetime.today().date()))

def print_random_quote():
    response = requests.get('https://api.quotable.io/random')
    quote = response.json()['content']
    print('Quote of the day: "{}"'.format(quote))

dag = DAG(
    'welcome_dag',
    default_args={'start_date': days_ago(1)},
    schedule_interval='0 23 * * *',
    catchup=False
)

print_welcome_task = PythonOperator(
    task_id='print_welcome',
    python_callable=print_welcome,
    dag=dag
)

print_date_task = PythonOperator(
    task_id='print_date',
    python_callable=print_date,
    dag=dag
)

print_random_quote = PythonOperator(
    task_id='print_random_quote',
    python_callable=print_random_quote,
    dag=dag
)

# Set the dependencies between the tasks
print_welcome_task >> print_date_task >> print_random_quote  
```

*18.xrate_to_s3.py*8  

```python

from datetime import datetime
from airflow import DAG
from airflow.utils.dates import days_ago
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.transfers.local_to_s3 import LocalFilesystemToS3Operator
from airflow.models import Variable
import subprocess

dag = DAG(
    'xrate_to_s3',
    default_args={'start_date': days_ago(1)},
    schedule_interval='0 23 * * *',
    catchup=False
)

def fetch_xrate_fn(ti):
    xrate_filename = f'xrate_{datetime.now().strftime("%Y-%m-%d-%H-%M-%S")}.json'
    curl_command = ["curl", Variable.get('web_api_key'), "-o", f'/tmp/{xrate_filename}']
    subprocess.run(curl_command)
    ti.xcom_push(key='xrate_file', value=xrate_filename)

fetch_xrate = PythonOperator(
    task_id='fetch_xrate',
    python_callable=fetch_xrate_fn,
    provide_context=True,
    dag=dag
)

upload_to_s3 = LocalFilesystemToS3Operator(
    task_id='upload_to_s3',
    filename="/tmp/{{ ti.xcom_pull(task_ids='fetch_xrate', key='xrate_file') }}",
    dest_bucket='sleek-data',
    dest_key=f'oms/{{{{ ti.xcom_pull(task_ids="fetch_xrate", key="xrate_file") }}}}',
    aws_conn_id='aws_conn',
    dag=dag
)

# Define Dependencies
fetch_xrate >> upload_to_s3  

```


---

**SQLs**

**1.profit_uk.sql**

```sql

create or replace table SLEEKMART_OMS.TRAINING.profit_uk 
as ( 
  SELECT 
    sales_date, SUM(quantity_sold * unit_sell_price) as total_revenue,
    SUM(quantity_sold * unit_purchase_cost) as total_cost,
    SUM(quantity_sold * unit_sell_price) - SUM(quantity_sold * unit_purchase_cost) as total_profit
  FROM 
    SLEEKMART_OMS.TRAINING.sales_uk
  WHERE
    sales_date BETWEEN '{{ var.json.process_interval.start_date }}' AND '{{ var.json.process_interval.end_date }}'
  GROUP BY 
    sales_date
)
```

**2.xrate_sf.sql**

```sql
INSERT INTO exchange_rate_hist 
SELECT 
T1.$1:timestamp::TIMESTAMP_NTZ AS timestamp,
T1.$1:base::VARCHAR AS base_currency,
T2.$2 AS exchange_currency,
T2.$5 AS exchange_rate
FROM @MY_S3_STAGE/xrate.json (file_format => 'my_json_format') T1,
     lateral flatten(input => $1, path => 'rates') T2  
     
```


---

**clean_data.py**

```python
import os
import pandas as pd

def clean_data():

    # Load raw data into DataFrame  
    data = pd.read_csv('/tmp/xrate.csv', header=None)

    # Cleanse Data
    default_values = {
        int: 0, 
        float: 0.0, 
        str: '', 
    }

    cleaned_data = data.fillna(value=default_values)

    # Get the current date components
    now = pd.Timestamp.now()
    year = now.year
    month = now.month
    day = now.day

    # Create the directory path if it doesn't exist
    data_dir = f'/opt/airflow/data/xrate_cleansed/{year}/{month}/{day}'
    os.makedirs(data_dir, exist_ok=True)

    # Save the cleaned data to a new file
    cleaned_data.to_csv(f'{data_dir}/xrate.csv', index=False)  
    
```  
    
---
**Q1. What is Apache Airflow and why is it used?**

**A.** Airflow is a workflow orchestration platform used to **author, schedule, and monitor** data/ML/ETL pipelines. It’s ideal when you need **time-based, dependency-aware, retryable, observable** workflows defined as code (Python DAGs) instead of ad-hoc cron scripts.  

--- 
**Q2. Explain Airflow architecture in detail.**  

**A.** Core components:

- **Webserver** – Flask app serving UI.
- **Scheduler** – Parses DAGs, decides which tasks should run, sets their state to “scheduled/queued”.
- **Executor** – Actually runs tasks (locally, Celery, Kubernetes).
- **Metadata DB** – Stores DAGs, DAG runs, task instances, XComs, variables, connections, logs metadata.
Workers (for Celery/K8s) pull tasks from queues and update states back in the DB.  

---
**Q3. What is a DAG in Airflow? Why must it be acyclic?**

**A.** A DAG (Directed Acyclic Graph) is a **set of tasks with dependencies specifying execution order**. It must be acyclic to guarantee a well-defined ordering – if there were cycles, tasks could depend on themselves indirectly and never reach a valid terminal state.  

---

**Q4. What is the difference between DAG Run and Task Instance?**  

**A.** **A DAG Run** is a single execution of the whole DAG for a given logical date. A **Task Instance** is a specific task from that DAG Run (task + dag_id + run_id). One DAG run contains many task instances.  

---  
**Q5.What are `default_args` in Airflow and how does inheritance work?**  

**A.** `default_args` is a dictionary passed to the DAG; its values are used as default parameters for all tasks inside that DAG unless overridden.  
**Precedence:** task explicit argument → `default_args` → operator’s built-in default.  

---  
**Q6. What is Catchup? How is it different from Backfill?**  

**A.** catchup=True means the scheduler will create DAG runs for **all past scheduled intervals** since `start_date`. 
**Backfill** is a CLI command (`airflow dags backfill`) that explicitly creates and runs historical DAG runs over a date range, regardless of `catchup`. 

---
**Q7. What is a schedule_interval?**  

**A.** It defines **how often** a DAG should run. It can be a cron string `("0 2 * * *")`, a preset like @daily, or a `timedelta`. It defines the **data interval** the DAG run is responsible for.  

---  

**Q8. What is a logical date in Airflow?**  

**A.** Logical date (formerly execution_date) is the **timestamp that identifies the DAG run** – usually the end of the data interval it processes. It’s not the time it actually runs; the DAG for `2025-02-10` might execute at 2am on `2025-02-11`.  

---

**Q9. Explain the DAG lifecycle.** 

**A.** Scheduler creates DAG runs based on `start_date/schedule`. Task instances move through states: `none → scheduled → queued → running → success/failed/skipped/up_for_retry`. Logs, XComs, SLAs and alerting are hooked into those transitions.  

--- 

**Q10. Why should DAGs and tasks be idempotent?**  

**A.** Because retries, backfills, and manual re-runs are common. Idempotent tasks ensure **re-running the same run with the same inputs doesn’t corrupt data** (e.g., use upsert, partition loads, or “delete+insert” for specific date instead of appending blindly).  

---

**Q11. How do you define a DAG programmatically?**  

**A.** Use `DAG()` inside a `with` block or assign it to a variable, set `dag_id`, scheduling, and common args:

```python
with DAG("example", start_date=..., schedule="@daily", catchup=False) as dag:
    ...
```  

---  

**Q12. Explain task dependency methods: `>>`, `<<`, `set_upstream`, `set_downstream`.**  

**A.** `t1 >> t2` means t2 depends on t1 (t1 upstream, t2 downstream). `t2 << t1` is the same. `t1.set_downstream(t2)` and `t2.set_upstream(t1)` do the same in method form. Lists are allowed: `t1 >> [t2, t3]`.

--- 

**Q13. What is `depends_on_past?`**  

**A.** If `depends_on_past=True`, a task will only run if its **previous run (for the previous logical date) succeeded**. Useful for strictly sequential daily workflows; dangerous when combined with backfills if not handled carefully.

---  

**Q14. What happens if a task fails and `retries=3`?**  

**A.** The task moves to `up_for_retry`. Airflow waits for `retry_delay` between attempts. It will attempt up to 3 retries in addition to the first attempt (total 4 tries). After exhausting retries, state becomes `failed`, affecting downstream via trigger rules.  

---  

**Q15. What is a Trigger Rule? Give examples.**  

**A.** Trigger rule controls **when a task is considered ready** relative to upstream states. Examples:

- `all_success` (default) – all upstream must succeed.
- `one_success` – any one upstream success is enough.
- `all_failed` – all upstream must fail.
- `none_failed` – no upstream failures allowed (success or skipped ok).
Used for alerting, “cleanup” tasks, and branching merges.  

---

**Q16. What is SLA in Airflow?**  

**A.** SLA (Service Level Agreement) is a **time by which a task should have completed**. If it misses, Airflow can send SLA miss emails and log SLA events. It does not kill tasks; it’s a monitoring feature, not a timeout.  

---

**Q17. What are `queue` and `pool`?**  

**A.** `queue` routes tasks to specific worker queues (e.g. `"gpu_queue"`). `pool` limits **concurrent executions** of tasks sharing a common resource (e.g. “mysql_pool = 5” ensures only 5 tasks using that pool run at a time).  

---  

**Q18. How do you prioritize tasks?**  

**A.** With `priority_weight`. When multiple tasks are queued and competing for limited slots, tasks with higher `priority_weight` are picked first (depending on the executor and queue configuration).  

---

**Q19. How to rerun only failed tasks?**  

**A.** From UI: clear failed tasks with “failed only” selection and `Include downstream`? as needed, without clearing successful ones.  
From CLI: `airflow tasks clear -s <date> -e <date> -t <task_id> --only-failed <dag_id>.`  
  
---

**Q20. Can you trigger a DAG from another DAG? How?**  

**A.** Yes, using `TriggerDagRunOperator` or REST API/webhook. In Airflow 2 you can also use `TriggerDagRunOperator` with conf to pass parameters to the downstream DAG.  
  
---

**Q21. What is an operator?**

**A.** An operator is a **template for a single unit of work** (task). Each task in a DAG is an instance of an operator. Operators define what to do (run Python, bash, query DB, call API, etc.).  

---

**Q22. Difference between `BashOperator` and `PythonOperator`.**  

**A.** `BashOperator` runs a shell command; it’s good for scripts or CLIs.  
`PythonOperator` calls a Python function; it’s better when you want to stay in Python, use libraries, or manipulate data without shelling out.  

---

**Q23. What is `BranchPythonOperator`? Use case?**  

**A.** It allows **conditional branching**: based on some logic, you return task_id(s) that should be executed next; others are skipped. Use it for e.g., run path A on weekdays and path B on weekends.  

---  

**Q24. How to call external APIs using `HttpOperator`?**  

**A.** Configure an HTTP connection, then:

```python
HttpOperator(
    task_id="call_api",
    http_conn_id="my_api",
    endpoint="/v1/data",
    method="GET"
)

```  

You can template endpoint/params, and parse responses in downstream tasks or via hooks.  

---  


**Q25. What is `EmailOperator`? How to use it for failure notification?**  

**A.** `EmailOperator` sends emails from a task. For failure notifications, you usually configure `email` and `email_on_failure` in `default_args` or use a dedicated alerting task with `trigger_rule="one_failed"` upstream of critical branches.  

---  

**Q26. Explain `KubernetesPodOperator` with example.**  

**A.** It launches a pod on Kubernetes to run an image:

```python
KubernetesPodOperator(
    task_id="run_job",
    namespace="default",
    image="myimage:latest",
    cmds=["python", "job.py"],
)
```

Used for containerized workloads and ephemeral jobs needing isolated environments.  

---  


**Q27. When would you use `DockerOperator`?**  

**A.** When running Airflow on bare metal/VMs and you want to run tasks inside a local Docker container without Kubernetes. It runs containers using the Docker engine directly.  

---  

**Q28. What is `TriggerDagRunOperator`?**  

**A.** It programmatically triggers another DAG, optionally with a JSON `conf` payload. Used for DAG chaining, orchestration across DAGs, or event-driven DAG runs.  

---  

**Q29. What are Deferrable Operators / Smart Sensors?**

A. They move long-wait I/O-heavy tasks off workers into a **“triggerer”** process. Instead of blocking a worker while polling (e.g., a sensor), they “sleep” asynchronously and wake when condition is met. This saves resources at scale.  

---   
**Q30. What is TaskFlow API and how is it different from classic DAG?**  

**A.** TaskFlow API allows you to define tasks as **Python functions wrapped with** `@task` and DAGs with `@dag`. It automatically handles XCom for function returns and dependencies via function calls, making DAGs more Pythonic and less boilerplate than operator-based classic DAGs.  

---

**Q31. How does XCom passing work automatically in TaskFlow?**  

**A.** If a `@task`-decorated function returns a value, Airflow automatically **stores it in XCom**. When you pass the result into another `@task` function as an argument, Airflow handles the XCom pull for you.  

---

**Q32. Can TaskFlow tasks use retries, SLA, trigger rules?**  

**A.** Yes. You can pass all typical operator arguments via `@task` parameters or as `@task(task_id="...", retries=3, trigger_rule="...")`. Under the hood, TaskFlow still uses operators.  

---  


**Q33. How would you convert a classic DAG to TaskFlow?**  

**A.** Replace `PythonOperator` tasks with `@task` functions, move logic into those functions, and replace explicit `task1 >> task2` dependency lines with function chaining like `t2(t1())`. Keep non-Python tasks (e.g., BashOperator) as-is or wrap with `@task.external_python`/`@task.virtualenv` if needed.  

---  

**Q34. What are XComs?**  

**A.** XCom (“cross-communication”) is Airflow’s mechanism to store **small metadata** so tasks can share information (e.g., file paths, IDs). Stored in the metadata DB as key–value pairs per task instance.  

---  

**Q35. Why is XCom size limited?**  

**A.** Because XComs are stored in the DB; large payloads hurt performance/storage. They’re intended for metadata (paths, IDs) not raw data. Large dataset should live in S3/DB; XCom should contain a reference.  

---  

**Q36. Difference between `xcom_push()` and TaskFlow returns.**  

**A.** `xcom_push` is explicit and works in any operator. In TaskFlow, the **function’s return value is automatically pushed** to XCom with a standard key (`return_value`), simplifying code.  

---  

**Q37. How do you clear XComs?**  

**A.** From the UI under XCom tab, or via CLI/SQL. In Airflow 2, you can also use `airflow tasks clear` with `--include-xcom`. Some teams implement cleanup jobs to periodically delete old XComs 

---  

**Q38. Example: pass DB query results from Task A to Task B via XCom.**  

**A.** Task A queries DB, saves result to S3, and pushes the S3 path via XCom. Task B pulls that path and reads from S3. You do not directly pass large result sets in XCom.  

---

**Q39. What is a custom XCom backend?**  

**A.** It’s a pluggable backend where you override how XComs are serialized/stored (e.g., store large objects in S3 and just keep a pointer in DB). Useful when you need to pass larger objects in a controlled way.  

---

**Q40. Explain schedule_interval formats.**  

**A.** It can be:

- Cron: `"0 2 * * *"` – daily at 2am.
- Presets: `@hourly`, `@daily`, `@weekly`.
- `timedelta`: `timedelta(days=1)` – every 24 hours.  

---

**Q41. What is `catchup=False` behavior?**  

**A.** The scheduler **only runs DAGs from “now” onward**, not filling historical intervals. Past runs are not auto-created even if they’re missing.  

---

**Q42. What is backfill?**  

**A.** Manual command to run the DAG over a specified historical range regardless of `catchup`:
`airflow dags backfill -s 2024-01-01 -e 2024-01-10 my_dag`.  

---

**Q43. Why is logical_date not actual runtime?**  

**A.** Airflow is data-interval-based: a run labeled `2025-02-10` processes data for e.g., the day `2025-02-10`, but it might physically run later (like at 2am `2025-02-11`). This separation allows consistent backfills, replay, and reason-about-period pipelines.  

---  

**Q44. What is timezone handling in Airflow?**  

**A.** Airflow is internally UTC-based but supports timezone-aware DAGs using `pendulum` timezones. You should avoid Python’s naive datetimes and standard `tzinfo` due to edge cases around DST, etc.  

---   

**Q45. What are Connections?**  

**A.** Configured credentials/endpoints (host, port, user, password, extras) stored in metadata DB. They’re referenced by `conn_id` in hooks/operators to connect to DBs, message queues, cloud services, etc.  

--- 

**Q46. Difference between Operators, Hooks, Sensors.**

**A.**

- **Operator** – describes a unit of work as a task.
- **Hook** – low-level client wrapper to connect to/from external systems.
- **Sensor** – an operator that waits for an external condition.  

---

**Q47. How do hooks interact with external systems?**  

**A.** Hooks use connection IDs to fetch credentials, then encapsulate clients (like psycopg2, boto3, google client libraries). Operators call hooks’ methods to perform the actual external actions.  

---  
**Q48. How do you store credentials securely?**  

**A.** Use environment variables, secret backends (Vault, AWS Secrets Manager, GCP Secret Manager), and configure Airflow’s secrets backend so `Conn` and `Variable` values are retrieved securely instead of being stored in plain DB.  

---

**Q49. What happens if a connection id is wrong?**  

**A.** The hook fails to build a client, raising an exception (e.g., `AirflowNotFoundException` or underlying library error). The task state becomes `failed`.  

---

**Q50. Example: Writing a custom hook for a 3rd-party API.**

**A.** Inherit from `BaseHook`, implement an initializer that reads a connection ID, build a session/client, then expose methods like `get_data()`. Use that hook in a custom operator or `PythonOperator`.  

---  
**Q51. What is a Sensor?**  

**A.** It’s a special operator that **blocks** until a condition is true (file exists, external task succeeded, partition available). It periodically “pokes” to check the condition.  

---

**Q52. What is `poke_interval`?**  

**A.** Interval in seconds between checks in `poke` mode. Smaller intervals mean quicker detection but more overhead.  

---

**Q53. Difference between poke and reschedule mode?**  

**A.** In **poke** mode, the task occupies a worker slot while sleeping between checks. In **reschedule** mode, the sensor releases the worker and reschedules itself later, which is more resource-efficient for long waits.  

---

**Q54. What are Deferrable Operators?**  

**A.** They move waiting logic off workers into a “triggerer” process using async I/O. They’re ideal for high-scale deployments with many long-wait tasks.  

---  

**Q55. Example: Wait for S3 file.**  

**A.** Use `S3KeySensor` or `S3KeySensorAsync` with bucket/key pattern and specify `poke_interval` and `timeout`.  

---  

**Q56. Difference between LocalExecutor, CeleryExecutor and KubernetesExecutor.**  

**A.**

**LocalExecutor** – runs tasks in parallel on a single machine via processes.  
**CeleryExecutor** – distributes tasks across multiple worker machines using Celery + message broker.  
**KubernetesExecutor** – launches a pod per task, fully containerized and horizontally scalable.  

---  

**Q57. Which executor would you choose for large-scale enterprise?**  

**A.** Typically **CeleryExecutor** (on VMs) or **KubernetesExecutor** (on K8s). Choice depends on infra maturity: K8s → KubernetesExecutor; otherwise CeleryExecutor with autoscaling workers.  

---  


**Q58. Why must scheduler and workers see the same DAG files?**  

**A.** Scheduler needs DAG files to parse them and create task instances. Workers need the same code to actually run tasks. If they’re out of sync, workers can’t import the DAG or relevant code.  

---  

**Q59. How do you scale workers in KubernetesExecutor?**  

**A.** Each task becomes a pod, so scaling is handled by the K8s cluster (autoscaling nodes based on demand). You tune concurrency and parallelism and rely on Kubernetes’ scheduler.  

---

**Q60. What is the role of queues?**  

**A.** Queues route tasks to specific workers or worker pools (e.g. high-memory vs normal, GPU vs CPU). In Celery executor, tasks on `queue="gpu"` will only be consumed by workers listening to that queue.  

---

**Q61. Explain HA (High Availability) in Airflow scheduling.**  

**A.** Run multiple scheduler instances (since Airflow 2 supports multi-scheduler) and multiple webservers behind a load balancer. Use external DB with HA (e.g., Postgres cluster) and multiple Celery workers or Kubernetes.  

---  

**Q62. What is an Airflow provider package?**  

**A.** A pip-installable package that adds operators, hooks, sensors, and extra dependencies for specific services (e.g., `apache-airflow-providers-amazon` for AWS).  

---

**Q63. How do you install providers?**  

**A.** Via pip with the correct Airflow constraints, e.g.:
`pip install` `"apache-airflow-providers-amazon"` ensuring Airflow and providers’ versions are compatible.  

---

**Q64. What is an Airflow Plugin?**  

**A.** A way to extend Airflow with custom operators, hooks, macros, executors, and UI views by placing plugin modules in the `plugins/` directory (Airflow 1.x/early 2.x). In newer versions, many plugin use cases are replaced by providers.  

---

**Q65. How to add a custom UI view via plugin?**  

**A.** Implement a FlaskAppBuilder view and register it in `AirflowPlugin` class with `appbuilder_views`. Airflow webserver then exposes it as a new menu item.  

---  
**Q66. How do plugins impact DAG parsing?**  

**A.** Heavy plugins can slow down DAG parse time since they are imported with the Airflow environment. Badly designed plugins can add overhead or side effects during import.  

---  

**Q67. Where are logs stored?**  

**A.** By default on the local filesystem under `$AIRFLOW_HOME/logs`. In production often centralized to S3, GCS, Azure Blob, or Elasticsearch using `remote_logging` config.

---

**Q68. How do you debug a failed task?**  

**A.** Check the **task logs** via UI or CLI, inspect stack trace, verify connections and credentials, test the underlying code locally, repro via `airflow tasks test`, and fix DAG or environment accordingly.  

---

**Q69. Why might a task be stuck in `queued` state?**  

**A.** Common reasons:

- No free worker slots (concurrency limits).
- Executor not running or misconfigured.
- Task queue mismatch (queue name wrong).
- DB or broker issue preventing workers from pulling tasks.  

---  
**Q70. How to re-run only failed tasks in a DAG run?**  

**A.** In UI: graph view → “Clear” → choose “Failed” and “Past” scopes appropriately.   
CLI: `airflow tasks clear --only-failed <dag_id> -s <date> -e <date>`.  
  
---

**Q71. How do you view XCom contents?**  
  
**A.** In the UI under Admin → XComs or from a task logs by printing `ti.xcom_pull`. You can also query the XCom table in the meta DB.  
  
---

**Q72. How do you monitor Airflow with Prometheus/Grafana?**  
  
**A.** Use the Airflow statsd/Prometheus exporter or metrics from `airflow-exporter` to scrape metrics into Prometheus, then build Grafana dashboards for DAG/task counts, durations, failures, and scheduler health.  
  
---

**Q73. How to enable SLAs and SLA alerts?**  
  
**A.** Set `sla` on tasks (e.g., `sla=timedelta(hours=1))` and configure `smtp` + `email` settings and `sla_miss_callback` if needed. Airflow periodically checks SLA misses and sends reports.  
  
---
**Q74. Why should tasks be idempotent?**  

**A.** So retries, backfills, and manual re-runs don’t duplicate or corrupt data. Example: use partitioned loads (`WHERE date = ds`), so re-running simply overwrites the same day, not append duplicates.  

--- 


**Q75. Why avoid heavy code at top-level in DAG files?**

**A.** Because the scheduler frequently imports/parses DAGs. Heavy top-level code (DB calls, big loops) slows parsing and can overload external systems. This logic should be inside tasks, not global scope.  

---

**Q76.** How do you ensure retry-safe data pipelines?
A. Design tasks to be atomic, partitioned by time or ID, and use upserts or delete+reload per partition. External systems should support idempotent operations or guarding via checksums/versioning.  

---  

**Q77. What’s a good DAG folder structure in production?**  

**A.** E.g.:

```text 
dags/
  common/
    utils.py
    hooks/
    operators/
  pipelines/
    sales/
      sales_daily.py
    marketing/
      marketing_etl.py  
```  



Shared code in common, pipeline-specific in their own files, all under version control.  

----  

**Q78. Why is dynamic DAG generation useful?**  

**A.** It lets you generate DAGs or tasks from config (e.g., one DAG per client, one task per table). This reduces boilerplate and centralizes logic but must be done carefully to avoid parse-time heavy loops.  

---

**Q79. When to use Task Groups vs SubDAGs?**  

**A.** **TaskGroups** are the modern way to visually group tasks in the same DAG; they are lightweight and recommended. 

**SubDAGs** are discouraged because they come with their own scheduling/executor complexity and can cause deadlocks.  

---

**Q80. How do you optimize DAG parsing time?**  

**A.** Avoid heavy imports and queries at module level, reuse code via lightweight modules, keep DAG files small, reduce dynamic DAG generation overhead, avoid reading big configs on every parse. 

---

**Q81. How do you handle dependencies on upstream DAGs?**  

**A.** Use `ExternalTaskSensor` or datasets (in newer Airflow) to wait for upstream DAG completion, or `TriggerDagRunOperator` to trigger downstream DAG directly.  

---  
**Q82. How do you implement CI/CD for DAGs?**  

**A.** Treat DAGs as code: store in Git, use tests (unit + DAG integrity checks), run lint/parse checks in CI, then deploy via image builds/git-sync or artifact sync to the Airflow DAG folder.  

---  

**Q83. How would you scale Airflow for 10,000+ tasks per day?**

**A.** Use a robust database (Postgres), Celery/Kubernetes executor with autoscaling workers, enable multiple schedulers, tune `max_active_runs/parallelism`, move sensors to deferrable operators, centralize logging, and ensure DAGs are optimized for fast parse.  

---

**Q84. How to design resilient pipelines with schema evolution?**  

**A.** Use contract-first design, versioned schemas, schema registry (if streaming), backward-compatible changes, feature-flagged transformations, and tasks that handle optional fields gracefully. Validate at ingestion and fail fast if breaking changes occur.  

---

**Q85. How to deploy Airflow with multi-region failover?** 

**A.** Typically active–passive: replicate meta DB, object storage and DAG repository; run a standby Airflow cluster in another region; use infra orchestration to failover DNS/load balancer and possibly promote read replica DB.  

---

**Q86. How to manage Airflow across Dev/QA/Prod environments?**  

**A.** Use separate Airflow instances or namespaces, environment-specific configs via connections/variables, separate metadata DBs, and CI/CD pipelines that promote DAGs from dev→qa→prod with tests and approvals.  

---

**Q87. What are common performance bottlenecks in Airflow?**  

**A.** Slow DAG parsing (heavy code in DAGs), DB contention (too many task state updates), overloaded scheduler, too many poking sensors, large XCom usage, and underprovisioned workers.  

---

**Q88. Why might you move from CeleryExecutor to KubernetesExecutor?**

**A.** To get **per-task container isolation**, native pod autoscaling, simpler worker management, and infrastructure unified under Kubernetes, especially when your workloads are already container-based.  


---

**Q89. What happens if the scheduler crashes mid-run?**  

**A.** Existing running tasks continue (managed by executor/workers), but no new tasks will be scheduled until scheduler is back. Once restarted, it reads states from the metadata DB and resumes scheduling from where it left off.  



---
