# Chapter 10: Deep Dive into Hooks, Operators, Sensors & Provider Packages

Apache Airflow is powerful because of its **extensible provider ecosystem**, offering operators, hooks, and sensors for nearly every major cloud platform, database, and service. This chapter gives a deep technical understanding of Airflow’s provider architecture and how to use it effectively.

---
# 10.1 What Are Provider Packages?
Airflow providers are installable Python packages that add:
- Operators
- Hooks
- Sensors
- Transfers
- Connection types
- Extra integrations

### Examples of popular providers:
- `apache-airflow-providers-amazon`
- `apache-airflow-providers-google`
- `apache-airflow-providers-databricks`
- `apache-airflow-providers-snowflake`
- `apache-airflow-providers-mysql`

### Installing a provider:
```bash
pip install apache-airflow-providers-amazon
```

---
# 10.2 Deep Dive: Hooks
Hooks provide **interfaces to external systems**, handling:
- Authentication
- Session management
- API interactions

Hooks are low-level components used by operators.

### Example: S3Hook
```python
from airflow.providers.amazon.aws.hooks.s3 import S3Hook

hook = S3Hook(aws_conn_id="aws_default")
files = hook.list_keys(bucket_name="my-bucket")
```

### Common Hook Categories
- **Cloud Storage**: S3Hook, GCSHook, AzureBlobHook
- **Databases**: PostgresHook, MySqlHook, SnowflakeHook
- **Compute**: DatabricksHook, EmrHook
- **Messaging**: KafkaHook, PubSubHook

---
# 10.3 Deep Dive: Operators
Operators define **what tasks do**.

### Operator Categories
| Category | Examples |
|----------|----------|
| Action | PythonOperator, BashOperator |
| File/Cloud | S3CreateObjectOperator, GCSToBigQueryOperator |
| Data Warehouse | SnowflakeOperator, BigQueryInsertJobOperator |
| Compute Jobs | DatabricksRunNowOperator, EMRCreateJobFlowOperator |
| Docker/Kubernetes | KubernetesPodOperator, DockerOperator |

---
## 10.3.1 PythonOperator
Most widely used operator.

```python
PythonOperator(
    task_id="process_data",
    python_callable=my_fn
)
```

### Tips:
- Keep logic inside `python_callable`
- Avoid heavy processing—call external scripts/jobs instead

---
## 10.3.2 BashOperator
Execute shell scripts.

```python
BashOperator(
    task_id="print_date",
    bash_command="date"
)
```

---
## 10.3.3 SQL Operators
Airflow provides database-specific operators:
- PostgresOperator
- MySqlOperator
- SnowflakeOperator
- BigQueryInsertJobOperator

### Example:
```python
from airflow.providers.postgres.operators.postgres import PostgresOperator

run_sql = PostgresOperator(
    task_id="aggregate_customers",
    postgres_conn_id="pg_main",
    sql="sql/aggregate_customers.sql"
)
```

---
## 10.3.4 Cloud-Specific Operators
### AWS
- S3CopyObjectOperator
- RedshiftSQLOperator
- EMR Create/Terminate operators

### GCP
- BigQueryInsertJobOperator
- GCSToGCSOperator
- CloudComposer operations

### Azure
- AzureDataFactoryRunPipelineOperator
- AzureBlobStorageOperators

### Databricks
- DatabricksRunNowOperator
- DatabricksSubmitRunOperator

---
# 10.4 Deep Dive: Sensors
Sensors wait for conditions.

### Sensor Modes
- **poke** (default): blocks worker
- **reschedule**: frees worker

### Common sensors:
- FileSensor
- S3KeySensor
- ExternalTaskSensor
- HttpSensor

### Example: S3KeySensor
```python
S3KeySensor(
    task_id="wait_for_file",
    bucket_name="landing-zone",
    bucket_key="data/{{ ds }}/file.csv",
    aws_conn_id="aws_default",
    poke_interval=60,
    mode="reschedule"
)
```

Best Practice: use `reschedule` mode for long waits.

---
# 10.5 Deep Dive: Transfers
Transfer operators move data between systems.

### Examples:
- GCSToBigQueryOperator
- S3ToRedshiftOperator
- MySqlToGCSOperator

### Example:
```python
from airflow.providers.google.cloud.transfers.local_to_gcs import LocalFilesystemToGCSOperator

upload = LocalFilesystemToGCSOperator(
    task_id="upload_file",
    src="/data/report.csv",
    dst="reports/report.csv",
    bucket="my-bucket"
)
```

---
# 10.6 Creating Custom Hooks
A custom hook is needed when interacting with:
- Proprietary APIs
- Internal services
- Non-standard platforms

### Example: Custom API Hook
```python
from airflow.hooks.base import BaseHook
import requests

class MyAPIHook(BaseHook):
    def __init__(self, conn_id):
        super().__init__()
        conn = self.get_connection(conn_id)
        self.base_url = conn.host

    def get_data(self):
        return requests.get(f"{self.base_url}/data").json()
```

---
# 10.7 Creating Custom Operators
Custom operators wrap reusable logic.

```python
from airflow.models.baseoperator import BaseOperator

class MyCustomOperator(BaseOperator):
    def execute(self, context):
        print("Running logic...!")
```

---
# 10.8 Combining Operators + Hooks — Best Practice
A well-designed custom operator:
- Contains orchestration logic
- Calls hooks for external communication

Example architecture:
```
MyCustomOperator
   └── uses MyAPIHook
```

---
# 10.9 How to Choose Between Operators, Hooks & Sensors
| Use Case | Choose |
|----------|--------|
| Execute logic | Operator |
| Interact with external system | Hook |
| Wait for a condition | Sensor |
| Move data | Transfer |

---
# 10.10 Provider-Specific Best Practices
## AWS
- Use IAM roles instead of static credentials
- Prefer `reschedule` mode for S3 sensors
- Use batching for S3 object listings

## GCP
- Use Workload Identity Federation
- Prefer BigQueryInsertJobOperator over raw SQL

## Databricks
- Use JSON payload-based SubmitRun
- Keep cluster configs versioned

## Snowflake
- Store passwords in Secret Manager
- Use SnowflakeOperator with staged external scripts

---
# 10.11 Summary
In this chapter, you learned:
- How providers add hooks, operators, sensors
- Cloud-specific operator usage
- How hooks interface with APIs and services
- How to build custom hooks and operators
- Best practices for sensors and transfers

---

