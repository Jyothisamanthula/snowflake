# Chapter 32: Airflow Governance, Compliance & Enterprise Controls

Apache Airflow is widely adopted in regulated industries—finance, healthcare, government, telecom, ecommerce—where **governance, compliance, data security, and operational controls** are mandatory. This chapter explains how to build an enterprise-grade governance framework for Airflow that ensures:

✔ Security & Access Control  
✔ Data Governance & Lineage  
✔ Compliance (SOX, GDPR, HIPAA, PCI)  
✔ Change Management  
✔ Auditability  
✔ Operational Controls  
✔ Risk Mitigation  
✔ SLA Reporting & Business Continuity  

We cover frameworks, standards, organizational controls, DAG governance, and best practices for regulated environments.

---
# 32.1 What Is Governance in Airflow?
Governance ensures that Airflow pipelines:
- Operate in a secure, controlled environment
- Comply with policies & regulations
- Produce reliable, reproducible results
- Are auditable and transparent
- Follow standard development & deployment practices

Governance spans **people, processes, tools, security, and operations**.

---
# 32.2 Enterprise Governance Components
1. **Security & RBAC** — who can access what?  
2. **Data Governance** — lineage, metadata, cataloging.  
3. **Compliance** — SOX, SOC2, HIPAA, GDPR.  
4. **Operational Governance** — monitoring, auditing, SLAs.  
5. **Change Management** — PR reviews, CI/CD governance.  
6. **Risk Management** — resilience, backup, DR.  
7. **Cost Governance** — quotas, resource limits.  

---
# 32.3 RBAC (Role-Based Access Control)
Airflow's RBAC model includes permissions for:
- DAG read / write / delete
- Trigger DAGs
- Edit connections
- Edit variables
- Access Admin menu

### Best Practices
✔ Create roles for each persona: *Viewer*, *Developer*, *Operator*, *Admin*  
✔ Enforce SSO (OAuth, SAML, LDAP)  
✔ Restrict connection editing to admins  
✔ No shared admin accounts  
✔ Disable anonymous access  

---
# 32.4 Secrets Management & Secure Credentials
Airflow supports secret backends:
- AWS Secrets Manager
- GCP Secret Manager
- Azure Key Vault
- HashiCorp Vault

### Best Practices
✔ Do not store credentials in Connections UI  
✔ Rotate credentials automatically  
✔ Enforce encryption at rest (KMS)  
✔ Use IAM roles instead of long-term keys  
✔ Limit privilege per task

---
# 32.5 Compliance Controls (SOX, SOC2, HIPAA, GDPR)
Enterprises must validate:
- **Audit Trails:** who triggered DAGs? who edited?  
- **PII/PHI Protection:** prevent sensitive data leaks  
- **Data Retention Rules**  
- **Secure Access Policies**  
- **Change Management & Sign-offs**  

### Examples
- SOX requires strict change controls → DAG changes must go through PR process.  
- HIPAA demands encryption & access restrictions.  
- GDPR requires “right to erasure” & data minimization.

---
# 32.6 Audit Logging
Airflow logs must record:
- DAG triggers
- Manual task runs
- User actions (via Web UI)
- API calls
- Connection edits

Send logs to:
- ELK / OpenSearch
- Splunk
- Datadog
- S3/GCS with long-term retention

Audit logs must be immutable.

---
# 32.7 Change Management Governance
Define a change approval process:
1. Developer creates PR for DAG updates.  
2. Automated DAG validation.  
3. Code review by peer + data steward.  
4. Merge to main branch.  
5. CI/CD deploys DAGs across environments.  
6. Automated tests validate behavior.

### Required Tools
- GitHub / GitLab / Bitbucket
- CI workflow (GitHub Actions, Jenkins, GitLab CI)
- Pre-commit hooks
- DAG unit tests

---
# 32.8 CI/CD & Pipeline Governance
Enforce:
✔ DAG linting  
✔ Import checks  
✔ Static code analysis  
✔ Security scan (Bandit)  
✔ Provider compatibility checks  
✔ Version pinning

A common CI workflow:
```
1. Run unit tests
2. Run airflow dags test
3. Validate imports
4. Build Docker image
5. Deploy to staging
6. Prod rollout with approval
```

---
# 32.9 Policy-as-Code for Airflow
Use tools like:
- **OPA (Open Policy Agent)**
- **YAML-based DAG governance rules**
- **Custom linter checks**

Examples:
- No DAG executes without owner assigned.  
- No DAG should have `catchup=True` unless approved.  
- No task may use random credentials.  
- All DAGs must have retry policy.

---
# 32.10 Resource Governance
Define quotas:
- Max parallel tasks per DAG
- Max worker autoscaling limits
- CPU/memory per task
- Priority weights

Why?
✔ Prevent resource starvation  
✔ Protect cost budgets  
✔ Avoid runaway DAGs

---
# 32.11 Data Governance & Lineage
Integrate Airflow with lineage tools:
- OpenLineage
- Marquez
- Databricks Unity Catalog
- AWS Glue Data Catalog
- Amundsen / DataHub

### Benefits
✔ End-to-end lineage across Airflow → Spark → Warehouse  
✔ Data classification
✔ Impact analysis for downstream breaks

---
# 32.12 SLA Governance & Monitoring
Define SLA governance rules:
- SLA miss alerting
- Task delay thresholds
- Data freshness requirements
- Incident classification

### Example Policy
> All business-critical DAGs must complete before 7 AM; SLA misses generate PagerDuty alerts.

---
# 32.13 Operational Governance
Includes:
- Monitoring framework  
- Logging standards  
- On-call responsibilities  
- Runbooks & playbooks  
- Disaster recovery

### Mandatory Runbooks
- Scheduler down  
- Worker deadlocks  
- Metadata DB failure  
- Log storage outage  
- DAG stuck in queued state  

---
# 32.14 DR (Disaster Recovery) & Backup Governance
### Required Controls
✔ Backup metadata DB daily  
✔ Replicate DB cross-region  
✔ Version DAG code in Git  
✔ Backup logs (S3/GCS lifecycle rules)

### DR Scenarios
- Region failure  
- Cluster corruption  
- Misconfiguration rollback

Recovery time must meet RTO/RPO requirements.

---
# 32.15 Access Governance
Access approvals should follow:
- Ticket-based request workflow  
- Automated provisioning via IAM  
- Auto-expiry for temporary access  
- No admin privileges without justification

---
# 32.16 Environment Governance
Define separate environments:
- dev  
- qa  
- staging  
- production  

Each with:
- Independent metadata DB  
- Controlled DAG promotion  
- Permissions linked to user role

---
# 32.17 Governance Anti-Patterns
### ❌ No code reviews for DAGs
### ❌ Storing credentials in plaintext variables
### ❌ No log retention policy
### ❌ Running Airflow workers with admin permissions
### ❌ No DAG ownership structure
### ❌ No audit trail of DAG changes

---
# 32.18 Governance Best Practices
✔ Enforce RBAC with SSO  
✔ Store secrets in secret manager  
✔ Implement DAG review/approval workflow  
✔ Use policy-as-code for DAG checks  
✔ Integrate with lineage catalog  
✔ Enable full audit logging  
✔ Use GitOps for consistent deployments  
✔ Maintain DR playbooks and runbooks  
✔ Separate dev/stage/prod environments  

---
# 32.19 Summary
This chapter covered the complete governance framework for Apache Airflow, including:
- Enterprise security & compliance
- RBAC, secrets, audit trails
- CI/CD governance and change control
- Lineage and metadata governance
- Resource and operational governance
- DR and risk management

---

