# Chapter 22: Airflow for Machine Learning Pipelines (Feature Engineering, Training, Deployment & Monitoring)

Airflow is widely used to orchestrate Machine Learning (ML) workflows—coordinating feature extraction, data preparation, model training, model evaluation, deployment, and monitoring. While Airflow is **not** an ML framework itself, it provides the orchestration needed for reproducible, scalable, and automated ML operations.

This chapter covers how to build **end-to-end ML pipelines** using Airflow.

---
# 22.1 Why Use Airflow for ML Pipelines?
ML workloads require:
- Scheduled training pipelines
- Dependency management
- Feature engineering jobs
- Model retraining & monitoring
- Data-driven triggering
- Reprocessing workflows
- Experiment tracking

Airflow provides:  
✔ Clear orchestration & dependencies  
✔ Scheduling & event triggers  
✔ Integration with Spark, Databricks, EMR, Snowflake, BigQuery ML  
✔ XCom for metadata passing  
✔ KubernetesPodOperator for distributed ML jobs  
✔ Integration with MLflow, SageMaker, Vertex AI, etc.

---
# 22.2 ML Pipeline Blueprint in Airflow
A typical ML pipeline looks like this:
```
raw_data_ingestion
    ↓
feature_engineering
    ↓
train_model
    ↓
evaluate_model
    ↓
register_model
    ↓
deploy_model
    ↓
monitor_predictions
```

---
# 22.3 Feature Engineering in Airflow
Feature engineering may involve:
- SQL transformations
- Spark jobs
- Python scripts
- dbt models
- Data lake processing

### Example TaskFlow
```python
@task
def build_features():
    df = load_raw_data()
    df = clean(df)
    df = engineer_features(df)
    save_to_feature_store(df)
```

### Best Practices
✔ Use feature stores (Feast, Hopsworks)  
✔ Use distributed compute (Spark/Dask) for large datasets  
✔ Store engineered features in parquet/Delta files

---
# 22.4 Model Training with Airflow
Training jobs can run:
- Locally (PythonOperator)
- Distributed (SparkSubmitOperator)
- On cloud services:
  - AWS SageMaker  
  - GCP Vertex AI  
  - Azure ML  
  - Databricks ML  

### Example: SageMaker Training
```python
from airflow.providers.amazon.aws.operators.sagemaker import SageMakerTrainingOperator

train = SageMakerTrainingOperator(
    task_id="train_model",
    config=my_sagemaker_config,
)
```

### Using KubernetesPods for Training
```python
train = KubernetesPodOperator(
    task_id="train",
    image="ml-training-image:latest",
    cmds=["python", "train.py"]
)
```

---
# 22.5 Model Evaluation
After training:
- Compute accuracy metrics
- Validate performance on holdout data
- Compare to the previous model

### Example
```python
@task
def evaluate(model_path):
    metrics = calculate_metrics(model_path)
    return metrics
```

Trigger **conditional branching**:
```python
@task.branch
def decide(metrics):
    return "register_model" if metrics["accuracy"] > 0.85 else "no_op"
```

---
# 22.6 Model Registry Integration
Airflow integrates with:
- MLflow registry
- SageMaker Model Registry
- Vertex AI Model Registry
- Feast model registry

### Example: MLflow Registry
```python
import mlflow

@task
def register(model_path):
    mlflow.register_model(model_path, "churn_model")
```

---
# 22.7 Model Deployment
Deployment targets:
- SageMaker endpoints
- Vertex AI endpoints
- Kubernetes (FastAPI, Flask apps)
- On-prem ML servers

### Example
```python
deploy = SageMakerEndpointOperator(
    task_id="deploy",
    config=my_deployment_config
)
```

---
# 22.8 Monitoring ML Models in Production
Monitor:
- Prediction drift
- Feature drift
- Model accuracy decay
- Latency / throughput

Use:
- Evidently AI
- MLflow monitoring
- Monte Carlo
- Bigeye

### Example: Airflow-triggered drift check
```python
@task
def check_drift():
    drift = calculate_drift()
    if drift > 0.2:
        alert_slack()
```

---
# 22.9 Retraining Pipelines
Setup triggered retraining when:
- Drift detected
- Accuracy threshold fails
- Scheduled retraining (weekly/monthly)
- New data arrives

Use Airflow Datasets or ExternalTaskSensor to detect new data.

---
# 22.10 ML Experiment Tracking
Use tools like:
- MLflow
- Weights & Biases
- Neptune.ai

### Example
```python
@task
def log_experiment(metrics):
    mlflow.log_metrics(metrics)
```

---
# 22.11 Using Airflow with Feature Stores
Airflow orchestrates:
- Feature ingestion pipelines
- Feature validation
- Training set creation

Feature Stores supported:
- Feast
- Tecton
- Hopsworks
- AWS SageMaker Feature Store

---
# 22.12 Airflow, Databricks & ML
Use Databricks Operators:
- `DatabricksSubmitRunOperator`
- `DatabricksRunNowOperator`

Best for:
- Spark ML  
- Delta Lake pipelines  
- Large-scale distributed ML

---
# 22.13 AutoML Integration
Trigger AutoML jobs:
- Google Vertex AutoML
- AWS SageMaker Autopilot
- Azure AutoML

### Example
```python
automl = VertexAIAutoMLTrainOperator(...)
```

---
# 22.14 Best Practices for ML Pipelines in Airflow
✔ Isolate training jobs in K8s pods  
✔ Use dedicated queues for ML tasks  
✔ Store features in parquet/Delta  
✔ Track experiments in MLflow  
✔ Use branching for model acceptance  
✔ Monitor drift and accuracy  
✔ Enable retries with exponential backoff  
✔ Avoid heavy ML code in PythonOperator  

---
# 22.15 Summary
In this chapter, you learned how to use Airflow to orchestrate:
- Feature engineering pipelines
- Distributed model training jobs
- Model evaluation & branching logic
- Model registry + deployment workflows
- Production monitoring & drift detection
- Retraining pipelines & AutoML integrations

---

