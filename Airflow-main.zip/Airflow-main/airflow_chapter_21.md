# Chapter 21: Airflow + Data Quality Tools (Great Expectations, dbt Tests, Soda, Monte Carlo)

Data pipelines are only as good as the **quality of the data** they move. Apache Airflow alone does not guarantee data quality—but it integrates seamlessly with data quality frameworks such as:

- **Great Expectations (GE)**
- **dbt Tests**
- **Soda Core / Soda Cloud**
- **Monte Carlo (Data Observability)**
- Other DQ frameworks (Deequ, AWS Glue DQ, etc.)

This chapter shows how Airflow orchestrates modern data quality checks, integrates quality tools inside DAGs, and provides enterprise-grade quality workflows.

---
# 21.1 Why Data Quality Matters in Airflow
Airflow orchestrates critical business pipelines:
- Finance reports
- ML feature pipelines
- ETL/ELT workflows
- Customer analytics

Without quality checks:
- Downstream dashboards break
- ML models degrade
- Regulatory reports fail
- Business decisions become unreliable

Airflow must become the **quality gatekeeper** of your pipeline.

---
# 21.2 4 Levels of Data Quality Validation
Airflow supports multiple layers of validation:

## Level 1 — Schema Checks
- Column presence
- Data types
- Nullability

## Level 2 — Statistical Checks
- Row counts
- Distribution checks
- Anomaly detection

## Level 3 — Business Rule Checks
- Uniqueness
- Referential integrity
- Acceptance ranges

## Level 4 — Observability / ML Anomaly Detection
- Continuous monitoring
- Alerts when metrics deviate

---
# 21.3 Using Great Expectations with Airflow
Great Expectations (GE) is the most popular open-source data validation tool.

## GE + Airflow Workflow
1. Define GE Expectations Suite
2. Connect GE to your warehouse/data lake
3. Run `GreatExpectationsOperator` inside DAG
4. Store validation results

### Example DAG
```python
from great_expectations_provider.operators.great_expectations import GreatExpectationsOperator

validate_orders = GreatExpectationsOperator(
    task_id="validate_orders",
    data_context_root_dir="/usr/local/airflow/gx",
    expectation_suite_name="orders_suite",
    batch_request={
        "datasource_name": "warehouse",
        "data_asset_name": "orders"
    },
)
```

### Best Practices
✔ Store GE context in the plugins folder  
✔ Use checkpoints for modularity  
✔ Write results to S3/GCS for audit trails

---
# 21.4 Using dbt Tests with Airflow
dbt tests are a simple but powerful way to validate transformed data.

### dbt Test Workflow in Airflow
1. Airflow runs `dbt run`
2. Airflow runs `dbt test`
3. Fail DAG if tests fail

### Example
```python
run_dbt_tests = BashOperator(
    task_id="dbt_test",
    bash_command="cd /dbt && dbt test --profiles-dir ."
)
```

### Best Practices
✔ Always run tests before loading marts  
✔ Use slim CI for faster dbt tests  
✔ Use exposures to define quality-critical models

---
# 21.5 Using Soda with Airflow
Soda provides SQL-based data quality for modern warehouses.

## Example Soda Scan
```python
from soda.core.soda_scan import SodaScan

scan = SodaScan()
scan.add_configuration_files(...)
scan.execute()
```

### Soda Cloud Integration
- Automatically uploads scan results
- Alerts to Slack/PagerDuty

### Best Practices
✔ Use Soda for rule-based SQL DQ  
✔ Use Cloud for team collaboration  

---
# 21.6 Using Monte Carlo (Data Observability)
Monte Carlo is a **data observability** platform providing:
- End-to-end lineage
- Pipeline monitors
- Automatic anomaly detection
- Data downtime alerts

### Airflow Integration
```python
from monte_carlo_airflow import MarkJobsCompleteOperator
```

Use this to signal job completion + trigger downstream monitors.

### Best Practices
✔ Use Monte Carlo for ML-driven anomaly detection  
✔ Combine with dbt + Airflow for a full DQ stack  

---
# 21.7 Choosing the Right Tool
| Use Case | Tool Recommendation |
|----------|---------------------|
| Rule-based SQL checks | dbt Tests / Soda |
| Schema + statistical validation | Great Expectations |
| Enterprise observability | Monte Carlo |
| ML anomaly detection | Monte Carlo / Bigeye |

---
# 21.8 Building a Data Quality Layer in Airflow
### Common Pattern
```
extract → validate raw data → transform → validate transformed data → load → notify
```

## Example DAG
```python
extract >> ge_raw >> transform >> dbt_test >> soda_scan >> load >> notify
```

---
# 21.9 Storing Data Quality Results
Log validation results into:
- S3/GCS
- BigQuery/Snowflake (DQ audit tables)
- Soda Cloud
- Great Expectations Data Docs
- Monte Carlo event API

---
# 21.10 Alerts & Automation
Common alerting strategies:
- Slack alerts when a DQ check fails
- PagerDuty alerts for critical tables
- Email summaries for daily validation

### Example Slack Alert
```python
SlackWebhookOperator(..., trigger_rule="one_failed")
```

---
# 21.11 Best Practices for Data Quality with Airflow
✔ Integrate DQ early in pipeline (fail fast)  
✔ Use DQ suites per table / model  
✔ Store DQ results for audit compliance  
✔ Use observability tools for anomaly detection  
✔ Use dbt tests for model validation  
✔ Use GE/Soda for warehouse rule checks  
✔ Automate alerts via Slack/Email/PagerDuty  

---
# 21.12 Summary
In this chapter, you learned:
- How Airflow integrates with GE, dbt tests, Soda, Monte Carlo
- How to design enterprise-grade DQ pipelines
- DQ layers and workflow patterns
- Best practices for execution, monitoring, and alerting

---
