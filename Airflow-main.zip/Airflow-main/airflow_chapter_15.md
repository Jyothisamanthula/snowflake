# Chapter 15: Monitoring, Logging, Observability & Metrics in Apache Airflow

Monitoring is one of the most critical parts of running Apache Airflow in production. A well-monitored Airflow environment ensures reliable pipelines, early incident detection, transparency for data teams, and the ability to meet SLAs.

This chapter provides a complete guide to Airflow observability—logs, metrics, alerts, dashboards, distributed logging, OpenTelemetry, and enterprise monitoring patterns.

---
# 15.1 Why Monitoring Matters
Airflow runs thousands—sometimes millions—of automated tasks.

Without proper monitoring:
- Failures go undetected
- SLAs are missed
- Task retries overwhelm external systems
- DAGs silently fail
- Schedulers/Workers become bottlenecks
- Data quality and business trust deteriorate

---
# 15.2 Core Monitoring Components in Airflow
Airflow provides four main observability components:

1. **Logs** (local/remote)  
2. **Metrics** (StatsD / Prometheus)  
3. **Alerts** (email, Slack, webhooks)  
4. **UI Monitoring** (Graph View, Gantt view, Task Duration view)  

---
# 15.3 Logs in Airflow
Every task instance logs:
- Task output
- Errors / stack traces
- Retries
- Worker metadata

### Log Formats
Airflow supports log handlers:
- Local log files
- S3
- GCS
- Azure Blob Storage

### Example: Enable S3 Logging
```ini
remote_logging = True
remote_log_conn_id = aws_default
remote_base_log_folder = s3://airflow-logs/
```

---
# 15.4 Log Retention & Cleanup
Airflow can accumulate millions of task logs.

### Best Practices:
- Rotate logs using log retention policies
- Use lifecycle rules in S3/GCS
- Avoid storing logs locally in production

---
# 15.5 UI Monitoring Views
Airflow UI provides multiple monitoring perspectives:

## 1. Tree View
Shows success/failure history for tasks.

## 2. Graph View
Visual representation of DAG dependency graph.

## 3. Gantt View
Shows execution duration and parallel patterns.

## 4. Task Duration View
Identifies bottlenecks.

## 5. Code View
Shows code used for historical DAG runs.

---
# 15.6 Alerts & Notifications
Alerts help detect issues early.

### 3 Common Alert Methods:
- Email alerts (built-in)
- Slack alerts
- Webhook alerts (PagerDuty, Datadog, OpsGenie)

### Example: Slack alert callback
```python
from airflow.operators.slack_webhook_operator import SlackWebhookOperator

alert = SlackWebhookOperator(
    task_id='alert_slack',
    message='Task failed!',
    http_conn_id='slack_conn',
    trigger_rule='one_failed'
)
```

---
# 15.7 Metrics & Observability Tools
Airflow exposes metrics for:
- Scheduler performance
- DAG run durations
- Task failures
- Worker loads
- Queue wait time

## Airflow supports:
- StatsD
- Prometheus
- OpenTelemetry

---
# 15.8 Prometheus + Grafana (Recommended)
Prometheus scrapes Airflow metrics and Grafana visualizes them.

### Common Dashboards:
- DAG success rate
- Task retries per DAG
- Scheduler loop duration
- Worker queue size
- Task duration distribution

Enable Prometheus exporter:
```bash
pip install apache-airflow-providers-prometheus
```

---
# 15.9 OpenTelemetry Support
Airflow supports OpenTelemetry for distributed tracing.

Use cases:
- Trace tasks across microservices
- Understand latency bottlenecks
- Distributed logs & events

---
# 15.10 Monitoring the Scheduler
Critical metrics:
- Scheduler heartbeat
- DAG processing time
- Orphaned tasks count

If scheduler slows, pipelines stall.

### Signs of scheduler overload:
- Tasks stuck in "scheduled"
- Long delays in task execution
- High DAG parse times

---
# 15.11 Monitoring Workers
For Celery/Kubernetes Executor:
- Worker CPU/memory
- Celery queue depth
- Number of running tasks
- Pod creation time (K8s)

### Auto-scaling workers is essential.

---
# 15.12 Task-Level Observability
Track:
- Execution duration trends
- Retry count
- Frequent failure points
- Upstream failures
- SLA misses

Airflow UI + logs → best debugging tools.

---
# 15.13 DAG-Level Observability
Track:
- DAG runtime patterns
- Success/Fail ratios
- Bottlenecks in dependencies
- Time spent in each stage

---
# 15.14 Alerting Pattern Examples
## 1. Fail-Fast Alerts
Send alerts as soon as a critical preprocessing step fails.

## 2. SLA Miss Alerts
Notify when task exceeds expected duration.

## 3. Retry Storm Alerts
Detect repeated retries that overwhelm APIs.

---
# 15.15 Monitoring Data Quality Through Airflow
While Airflow is not a DQ tool, you can integrate:
- Great Expectations
- Soda.io
- dbt tests

### Example using Great Expectations:
```python
GreatExpectationsOperator(
    task_id="validate_data",
    conn_id="snowflake_conn",
    expectation_suite_name="customer_suite"
)
```

---
# 15.16 Enterprise Observability Architecture
Enterprise-grade setups typically have:

### Logging
- Centralized S3/GCS log storage
- Log retention policies

### Metrics
- Prometheus + Grafana dashboards

### Alerts
- Slack / PagerDuty / OpsGenie
- SLA dashboards

### Tracing
- OpenTelemetry traces to Jaeger/Tempo

---
# 15.17 Best Practices for Monitoring & Observability
✔ Use remote logging in production  
✔ Deploy Prometheus exporter  
✔ Create Grafana dashboards per DAG team  
✔ Add Slack alerts for failures  
✔ Monitor scheduler loop duration  
✔ Monitor worker queue sizes  
✔ Integrate with Great Expectations/dbt tests  

❌ Don’t rely only on Airflow UI for monitoring  
❌ Don’t store logs locally in distributed setups  
❌ Avoid alert fatigue (send only actionable alerts)

---
# 15.18 Summary
In this chapter, you learned:
- How Airflow logs work (local vs remote)
- UI views for task & DAG monitoring
- Alerts using Slack, email, and webhooks
- How to use Prometheus, Grafana, and OpenTelemetry
- How to monitor scheduler and worker performance
- Best practices for enterprise observability

---
