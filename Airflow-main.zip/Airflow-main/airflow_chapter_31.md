# Chapter 31: Airflow Architecture & Design Interview Questions (Ops + Engineering)

This chapter provides a complete and structured list of **real-world Airflow interview questions** frequently asked for Data Engineering, DevOps, and SRE roles. Each question includes a clear, concise, and industry-standard answer.

These questions range from beginner to advanced levels, covering:
- Scheduler internals
- Executors
- DAG design
- Event-driven workflows
- CI/CD
- Monitoring & observability
- Lakehouse orchestration
- High availability & scaling
- Security & governance

Use this chapter as a preparation guide for mid-level and senior-level interviews.

---
# 31.1 Airflow Basics — Beginner Level

### **Q1. What is Apache Airflow?**
**A:** An open-source workflow orchestration platform for scheduling and running data pipelines as DAGs (Directed Acyclic Graphs). Supports Python-based DAG definitions, retries, backfills, sensors, and UI-based monitoring.

### **Q2. What is a DAG in Airflow?**
**A:** A Directed Acyclic Graph consisting of tasks with dependencies. It represents the workflow structure.

### **Q3. What is a Task?**
**A:** The smallest unit of work in Airflow. Each task is executed using an Operator.

### **Q4. What is an Operator?**
**A:** A template for a specific type of task (e.g., PythonOperator, BashOperator, EmailOperator, SparkSubmitOperator).

### **Q5. What is the difference between Airflow 1.x and 2.x?**
**A:** 2.x introduces:
- Multi-scheduler support
- TaskFlow API
- Smart sensors
- Stable REST API
- HA improvements
- Simplified import paths
- Better execution engine

---
# 31.2 DAG Design & Patterns — Intermediate Level

### **Q6. What are best practices for designing DAGs?**
**A:**
- Keep DAGs lightweight
- Keep task logic inside operators/functions
- Use sensors in `reschedule` mode
- Avoid circular dependencies
- Use task groups for modularity
- Avoid excessive parallelism

### **Q7. What is idempotency in Airflow?**
**A:** A task should produce the same result if executed multiple times. Makes retries & backfills safe.

### **Q8. What’s the difference between `depends_on_past` and `wait_for_downstream`?**
**A:**
- `depends_on_past` waits for *previous dag run's task* to succeed
- `wait_for_downstream` waits for *downstream tasks* of the previous run

### **Q9. What is max_active_runs?**
**A:** Limits concurrent DAG runs. Helps prevent backfill storms.

### **Q10. How do you parameterize DAGs?**
**A:** Using DAG params:
```python
with DAG(..., params={"table": "orders"}) as dag:
```
Or using templates and variables.

---
# 31.3 Executors & Workers — Intermediate/Advanced

### **Q11. What is an Executor?**
**A:** Determines *how* tasks are executed.
Executors include:
- SequentialExecutor
- LocalExecutor
- CeleryExecutor
- KubernetesExecutor
- LocalKubernetesExecutor

### **Q12. When to use CeleryExecutor?**
**A:** Multi-node worker setups, large-scale batch pipelines, enterprise workloads.

### **Q13. When to use KubernetesExecutor?**
**A:** When you need:
- Kubernetes-native orchestration
- Auto-scaling
- Per-task isolation
- ML/CPU/GPU workloads

### **Q14. What is CeleryKubernetesExecutor?**
**A:** Hybrid executor: Celery handles small tasks, Kubernetes handles large/heavy tasks.

---
# 31.4 Scheduler Internals

### **Q15. How does the scheduler work?**
**A:**
- Parses DAG files
- Determines runnable tasks
- Pushes tasks to executor
- Monitors task state
- Updates metadata DB

### **Q16. What causes slow DAG parsing?**
**A:**
- Too many DAGs
- Heavy imports in DAG file
- External API calls during parse
- Dynamic DAG generation at import time

### **Q17. How to improve DAG parsing performance?**
**A:**
- Keep DAG files lightweight
- Move logic into tasks
- Cache metadata
- Split factories by domain
- Use `dag.test()` locally

---
# 31.5 Sensors & Event-Driven Workflows

### **Q18. Difference between `poke` and `reschedule` mode?**
**A:**
- `poke` → task holds worker slot (expensive)
- `reschedule` → worker freed, task requeues later (cost-efficient)

### **Q19. When should you use Datasets vs Sensors?**
**A:**
- Use Datasets for Airflow-to-Airflow orchestration
- Use Sensors for external systems

### **Q20. What is ExternalTaskSensor?**
**A:** Waits for a task or DAG in another DAG to finish.

---
# 31.6 XComs & Data Sharing

### **Q21. What is an XCom?**
**A:** Small metadata passing between tasks. Not meant for large data.

### **Q22. What are XCom anti-patterns?**
**A:**
- Passing large dataframes
- Passing files
- Passing entire datasets

### **Q23. Where should large data be stored?**
**A:** S3, GCS, database, or data lake—not XCom.

---
# 31.7 High Availability (HA) & Scaling

### **Q24. How do you achieve HA for Airflow Scheduler?**
**A:** Airflow 2.x supports multiple active schedulers.

### **Q25. How do you scale workers?**
**A:**
- Celery → Add more worker nodes / autoscale
- Kubernetes → Use HPA (Horizontal Pod Autoscaler)

### **Q26. What is the role of the metadata database?**
**A:** Stores all DAG runs, task instances, variables, connections, and XComs. It’s a critical component.

### **Q27. How do you secure the metadata DB?**
**A:**
- Use managed DB (RDS, CloudSQL)
- Enable SSL
- Use restricted IAM roles
- Backup daily

---
# 31.8 CI/CD & DevOps

### **Q28. How do you validate DAGs in CI?**
**A:**
```bash
airflow dags list
airflow dags test
flake8 / black
```

### **Q29. How do you deploy DAGs?**
**A:**
- MWAA → S3 sync
- Composer → GCS sync
- Astronomer → `astro deploy`
- Self-hosted → GitOps syncing DAG folder

### **Q30. What is a Blue-Green deployment?**
**A:** Running new Airflow version alongside the old one; switch traffic after validation.

---
# 31.9 Airflow + Cloud & Data Platforms

### **Q31. How does Airflow integrate with Databricks?**
**A:** Using `DatabricksSubmitRunOperator` and `DatabricksRunNowOperator`.

### **Q32. How does Airflow integrate with AWS EMR?**
**A:** Using `EMRCreateJobFlowOperator` and `EMRStepOperator`.

### **Q33. How does Airflow integrate with BigQuery?**
**A:** Using BigQuery operators and GCP service accounts.

---
# 31.10 Security & Governance

### **Q34. How do you store secrets in Airflow?**
**A:** Use secret backends:
- AWS Secrets Manager
- GCP Secret Manager
- Hashicorp Vault
- Azure Key Vault

### **Q35. How does RBAC work in Airflow?**
**A:** Assign roles to users controlling:
- DAG read/write access
- Trigger permission
- Admin access
- Connection editing

### **Q36. How do you enforce DAG-level access?**
**A:** Use Airflow permissions:  
`can_read`, `can_edit`, `can_delete` on specific DAG IDs.

---
# 31.11 Advanced Design Patterns — Senior Level

### **Q37. What are metadata-driven DAGs?**
**A:** DAGs generated dynamically based on config (YAML/DB). Enables scaling to 100s or 1000s of pipelines.

### **Q38. What are Dataset-based DAGs?**
**A:** DAGs triggered by updates to data assets instead of time-based schedules.

### **Q39. What is Dynamic Task Mapping?**
**A:** Allows tasks to be generated at runtime based on data returned by upstream task.

### **Q40. What are Airflow anti-patterns?**
**A:**
- Heavy logic in DAG file  
- Large XComs  
- Excessive sensors in poke mode  
- Too many parallel tasks  
- Use of SubDAGs (deprecated)

---
# 31.12 SRE/DevOps Operational Questions

### **Q41. What logs are critical in Airflow debugging?**
**A:**
- Scheduler logs
- Worker logs
- Webserver logs
- Task logs

### **Q42. How do you perform metadata cleanup?**
```bash
airflow db prune
airflow db cleanup
```

### **Q43. How do you monitor Airflow?**
**A:** Prometheus, Grafana, Datadog, CloudWatch, Stackdriver.

### **Q44. How do you build SLIs for Airflow?**
Examples:
- Scheduler uptime
- DAG success rate
- Task queue latency
- DAG parsing speed

### **Q45. What is a zombie task? How do you handle it?**
**A:** Tasks whose workers died without updating state. Airflow cleans them up via zombie detector.

---
# 31.13 Scenario-Based Questions — Expert Level

### **Q46. Your scheduler keeps crashing. What do you do?**
**A:**
- Check scheduler logs  
- Check DB health  
- Reduce DAG count  
- Validate imports  
- Scale scheduler replicas  
- Upgrade Airflow version

### **Q47. Your workers are stuck in "queued" state for hours. Root cause?**
**A:**
- Not enough workers  
- Heavy sensors blocking slots  
- External system outage  
- Queue misconfiguration  

### **Q48. You need to orchestrate 500+ ingestion pipelines. How?**
**A:**
- Metadata-driven DAG factory  
- Dynamic task mapping  
- Domain-based DAG grouping

### **Q49. A downstream DAG must wait for multiple upstream tables. How?**
**A:** Use **Datasets with multiple producers**.

### **Q50. Your logs bucket grew to 50 TB. What now?**
**A:**
- Apply lifecycle rules  
- Compress logs  
- Reduce verbosity  
- Prune old task runs

---
# 31.14 Summary
This chapter provided 50+ architecture and design interview questions across multiple levels. These Q&As help prepare for:
- Data Engineering Interviews
- SRE & DevOps Airflow Interviews
- Platform Engineering Roles
- Cloud Architecture Discussions

---

