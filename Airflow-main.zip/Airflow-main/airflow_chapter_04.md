# Chapter 4: Writing Your First Airflow DAG

This chapter teaches you how to write your first Airflow DAG—starting from the basics and building up to a fully functional pipeline. You will learn DAG structure, tasks, operators, scheduling, dependencies, and best practices.

---

## 4.1 What Is a DAG?
A **DAG (Directed Acyclic Graph)** represents a workflow where:
- **Directed** = tasks run in a specific order
- **Acyclic** = workflows cannot loop back
- **Graph** = tasks connected by dependencies

Airflow executes DAGs *not as code*, but as **task graphs**.

---

## 4.2 Anatomy of a DAG File
A DAG file is a Python script placed in the `dags/` folder.

Basic structure:
```python
from airflow import DAG
from airflow.operators.empty import EmptyOperator
from datetime import datetime

with DAG(
    dag_id="first_dag",
    start_date=datetime(2024, 1, 1),
    schedule_interval="@daily",
    catchup=False,
) as dag:

    start = EmptyOperator(task_id="start")
    end = EmptyOperator(task_id="end")

    start >> end
```

---

## 4.3 DAG Parameters Explained
### `dag_id`
Unique identifier for the DAG.

### `start_date`
When the DAG starts scheduling.

### `schedule_interval`
Defines how often the DAG runs:
- `@daily`
- `@hourly`
- `@once`
- Cron: `0 3 * * *`

### `catchup`
- `True` → runs all past scheduled periods
- `False` → only future runs

### `default_args`
Reusable parameters for tasks.

---

## 4.4 Tasks & Operators
A **task** is a unit of work. Tasks are created using **operators**.

### Categories of Operators:
- **Action Operators** (PythonOperator, BashOperator)
- **Transfer Operators** (S3ToGCSOperator)
- **Sensor Operators** (ExternalTaskSensor, S3KeySensor)
- **Email / Notification Operators**

### Example: PythonOperator
```python
from airflow.operators.python import PythonOperator

def greet():
    print("Hello from Airflow!")

hello_task = PythonOperator(
    task_id="hello",
    python_callable=greet,
)
```

---

## 4.5 Setting Task Dependencies
There are multiple ways:

### Method 1: Bitshift
```python
start >> task1 >> end
```

### Method 2: set_upstream / set_downstream
```python
task1.set_downstream(task2)
task2.set_upstream(task1)
```

### Method 3: Lists
```python
[start, task1] >> end
```

---

## 4.6 A Real DAG Example
```python
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from datetime import datetime

def process_data():
    print("Processing data...")

with DAG(
    dag_id="etl_daily_pipeline",
    start_date=datetime(2024, 1, 1),
    schedule_interval="0 2 * * *",
    catchup=False,
) as dag:

    extract = BashOperator(
        task_id="extract",
        bash_command="echo 'Extracting data'",
    )

    transform = PythonOperator(
        task_id="transform",
        python_callable=process_data,
    )

    load = BashOperator(
        task_id="load",
        bash_command="echo 'Loading data'",
    )

    extract >> transform >> load
```

---

## 4.7 DAG Scheduling Examples
### Cron examples:
- Run every day at midnight:
```
0 0 * * *
```
- Run every Monday:
```
0 0 * * 1
```

### Preset schedules:
- `@daily`
- `@weekly`
- `@once`
- `@hourly`

---

## 4.8 DAG Best Practices for Professionals
### Do:
- Keep DAG files simple
- Use functions for heavy logic
- Use XComs sparingly
- Use retries for flaky tasks
- Always set `catchup=False` unless needed

### Don’t:
- Put large Python code inside operators
- Use global variables
- Put heavy logic outside tasks
- Use long Python scripts inline

---

## 4.9 Testing Your First DAG
Validate DAG structure:
```bash
airflow dags list
```
View detailed parsing errors:
```bash
airflow dags report dag_id
```
Trigger a DAG manually:
```bash
airflow dags trigger first_dag
```

---

## 4.10 Summary
You learned:
- How DAGs are structured
- How tasks & operators work
- How to schedule and orchestrate pipelines
- How to write a production-ready DAG

---

