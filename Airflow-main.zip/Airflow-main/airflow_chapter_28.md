# Chapter 28: Airflow Upgrades, Migration Strategies & Version Management

Apache Airflow evolves rapidly. With new releases every few months, Airflow introduces:
- New operators & providers
- Security patches
- Performance improvements
- UI enhancements
- Executor and scheduler improvements

Enterprises must plan **safe and reliable upgrade strategies**. A poorly executed upgrade can break pipelines, corrupt metadata, or cause scheduler downtime.

This chapter provides a complete guide to Airflow upgrade planning, version management, testing strategies, and zero-downtime migration patterns.

---
# 28.1 Why Upgrading Airflow Is Critical
### Benefits of staying current:
✔ Security patches  
✔ Critical bug fixes  
✔ Compatibility with providers  
✔ Performance enhancements (scheduler, executor)  
✔ New features (Datasets, dynamic tasks, HA scheduler)  

### Risks of staying outdated:
❌ Unsupported provider packages  
❌ Incompatibility with cloud platforms (MWAA/Composer)  
❌ Vulnerable to security risks  
❌ Missing features used by the community

---
# 28.2 Airflow Version Policy
Airflow follows:
- **Semantic versioning** (major.minor.patch)
- Support cycle: ~18 months per release
- Providers updated independently of Airflow core

Major version upgrades (e.g., 1.x → 2.x) require breaking changes.

---
# 28.3 Types of Upgrades
### 1. **Patch Upgrade** (safe)
```
2.8.1 → 2.8.2
```
Bug fixes only.

### 2. **Minor Upgrade** (moderate risk)
```
2.7.x → 2.8.x
```
Adds features, may require DAG adjustments.

### 3. **Major Upgrade** (high risk)
```
1.10.x → 2.x
```
Requires migration steps.

---
# 28.4 Airflow Upgrade Compatibility Matrix
Check the compatibility between:
- Airflow core version  
- Python version  
- Provider packages  
- Metadata database version  
- Kubernetes version (if using K8s executor)

Always validate using:
```
pip install 'apache-airflow==X.Y.Z' --constraint <constraints-file>
```

---
# 28.5 Pre-Upgrade Checklist
✔ Validate database migrations  
✔ Backup metadata DB  
✔ Test DAGs in staging  
✔ Pin dependencies  
✔ Validate provider package versions  
✔ Check deprecation warnings  
✔ Review release notes of each version

---
# 28.6 Zero-Downtime Upgrade Strategy
### Pattern: **Blue-Green Deployment**
Run two Airflow clusters in parallel:
```
Blue = current production  
Green = upgraded version
```

Steps:
1. Clone DAGs + configs  
2. Set up upgraded Airflow cluster  
3. Validate jobs on Green  
4. Cut over traffic using LB  
5. Decommission Blue

---
# 28.7 Upgrade Strategy for MWAA
MWAA only supports specific Airflow versions.

### Steps:
1. Check AWS documentation for compatible versions  
2. Update MWAA environment version  
3. Update requirements.txt  
4. Validate DAG parsing  
5. Rollback using environment snapshot if needed

MWAA auto-manages DB migrations.

---
# 28.8 Upgrade Strategy for Cloud Composer
Composer uses images:
```
airflow-X.Y.Z-python3.N
```

### Steps:
1. Clone environment  
2. Point GCS DAG bucket to new environment  
3. Test tasks  
4. Promote environment to prod

---
# 28.9 Upgrade Strategy for Astronomer
Astronomer simplifies upgrades:
```bash
astro dev upgrade
astro deploy
```

Astronomer Cloud handles:
- DB migrations
- Image updates
- Compatibility checks

---
# 28.10 Manual Upgrade (Self-Hosted)
### Step 1 — Backup Metadata DB
```bash
pg_dump airflow > airflow_backup.sql
```

### Step 2 — Stop Scheduler & Webserver
```bash
systemctl stop airflow-scheduler
i systemctl stop airflow-webserver
```

### Step 3 — Upgrade
```bash
pip install --upgrade apache-airflow==2.9.0
```

### Step 4 — Run DB Migrations
```bash
airflow db upgrade
```

### Step 5 — Start Services
```bash
systemctl start airflow-scheduler
systemctl start airflow-webserver
```

---
# 28.11 Testing DAGs After Upgrade
### 1. Parse Tests
```bash
airflow dags list
```

### 2. Unit Tests
Reusable Python logic.

### 3. Integration Tests
Run DAG in test mode.

### 4. Backfill Tests
Validate old runs:
```bash
airflow dags backfill -s 2024-01-01 my_dag
```

---
# 28.12 Common Migration Issues
### ❌ Missing providers
Solution:  
```bash
pip install apache-airflow-providers-amazon
```

### ❌ Connection ID reference changes
### ❌ Import paths changed

Airflow 2.x introduced many import changes.

---
# 28.13 Migrating Airflow 1.10.x → 2.x (Major Migration)
Key changes:
- New scheduler engine  
- Official REST API  
- TaskFlow API  
- New UI & RBAC  
- DAG run state changes  

### Migration Steps
1. Fix legacy imports  
2. Add `dag_id` explicitly  
3. Migrate PythonOperator patterns  
4. Replace SubDAGs with Task Groups  
5. Update Dockerfile / K8s specs  

### Use the migration tool
Airflow provides a backward compatibility provider:
```
apache-airflow-backport-providers
```

---
# 28.14 Dependency Management During Upgrades
Always pin package versions:
```
apache-airflow==2.9.0
apache-airflow-providers-amazon==8.2.0
```

Use constraints file to avoid conflicts.

---
# 28.15 Observability for Upgrades
Monitor metrics after upgrade:
- Scheduler heartbeat  
- DAG parsing time  
- Task duration changes  
- Worker resource usage  
- Scheduler queue backlog  
- Database performance

Tools:
- Prometheus  
- Grafana  
- Datadog  
- CloudWatch  
- OpenTelemetry

---
# 28.16 Post-Upgrade Validation Checklist
✔ DAGs running successfully  
✔ Scheduler stable  
✔ No DAG parse errors  
✔ Provider package compatibility  
✔ Workers not failing  
✔ Logs written correctly  
✔ Triggers, sensors, and task mapping working  
✔ SLA alerts firing normally

---
# 28.17 Airflow Upgrade Anti-Patterns
### ❌ Upgrading directly in production  
### ❌ Not backing up metadata DB  
### ❌ Upgrading providers without testing DAGs  
### ❌ Mixing Python versions  
### ❌ Ignoring deprecation warnings

---
# 28.18 Best Practices
✔ Always upgrade in staging first  
✔ Use blue-green deployment  
✔ Pin Python & provider versions  
✔ Follow official upgrade guide  
✔ Monitor Airflow after upgrade  
✔ Keep DAGs lightweight—reduces breakage  
✔ Document your migration steps

---
# 28.19 Summary
In this chapter, you learned:
- How to plan and execute Airflow upgrades
- Strategies for MWAA, Composer, Astronomer, and self-hosted Airflow
- Zero-downtime blue-green deployments
- DAG testing, validation, and rollback methods
- Best practices for version management & dependency control

---
