# Chapter 25: Airflow + Streaming Workflows (Kafka, Spark Streaming, Flink, Kinesis)

Apache Airflow is fundamentally a **batch orchestrator**, but modern data platforms often require **real-time** and **near-real-time** pipelines. While Airflow is not a streaming engine, it plays a crucial role in orchestrating, supervising, checkpointing, and coordinating **streaming jobs** built with tools like:

- Apache Kafka
- Apache Spark Streaming / Structured Streaming
- Apache Flink
- AWS Kinesis
- GCP Pub/Sub
- Databricks Autoloader

This chapter explains how Airflow integrates with streaming processes, when to use Airflow (and when not to), and real-world streaming orchestration patterns.

---
# 25.1 Airflow’s Role in Streaming Architectures
Airflow is **not** suitable for:  
❌ continuous millisecond-level event processing  
❌ micro-batch pipelines with sub-second latency  
❌ event-by-event processing

Airflow **is** excellent for orchestrating:  
✔ Monitoring streaming systems  
✔ Managing checkpoints & recovery  
✔ Batch-on-stream hybrid pipelines  
✔ Stream ingestion health checks  
✔ Backfill / reprocess logic  
✔ Daily/Hourly window aggregations  
✔ Triggering downstream analytics jobs  

---
# 25.2 Common Streaming Architectures with Airflow
### Architecture 1 — Streaming Ingestion + Batch Transform
```
Kafka → Raw Storage (S3/GCS) → Airflow Batch ETL → Warehouse
```

### Architecture 2 — Streaming with Periodic Aggregation
```
Flink/Spark Streaming → Summary Tables → Airflow → BI Dashboards
```

### Architecture 3 — Monitoring Streaming Pipelines
```
Streaming job health → Airflow sensor → Alerts / Auto-restart
```

---
# 25.3 Airflow + Apache Kafka
Airflow integrates with Kafka via:
- KafkaProducerHook
- KafkaConsumerHook
- Observability sensors via custom operators
- Airflow → Kafka → Downstream pipelines

### Example: Produce Event to Kafka
```python
from airflow.providers.apache.kafka.hooks.kafka import KafkaProducerHook

@task
def push_to_kafka():
    hook = KafkaProducerHook(kafka_config_id="kafka_conn")
    hook.send("events", {"id": 1, "msg": "hello"})
```

### Kafka Use Cases with Airflow
✔ Trigger micro-batch files (Kafka → S3 → Airflow)  
✔ Monitor consumer lag  
✔ Validate Kafka → object storage delivery  
✔ Restart streaming applications

---
# 25.4 Airflow + Spark Streaming
Airflow orchestrates Spark Streaming jobs using:
- SparkSubmitOperator (on EMR/YARN/K8s)
- DatabricksSubmitRunOperator
- EMR operators

### Use Cases
✔ Start/Stop streaming jobs  
✔ Monitor streaming job checkpoint directory  
✔ Daily window aggregations from streaming tables  
✔ Schema enforcement after streaming ingestion

### Monitoring Spark Streaming Health
Airflow task to monitor checkpoint lags:
```python
@task
def check_checkpoint_lag():
    lag = get_streaming_lag()
    if lag > 120:
        raise AirflowException("Streaming is delayed!")
```

---
# 25.5 Airflow + Apache Flink
Airflow integrates with Flink using:
- FlinkKubernetesOperator
- Custom REST API operators

### Orchestration Patterns
✔ Submit Flink jobs  
✔ Cancel jobs  
✔ Monitor Flink job status  
✔ Trigger Airflow background pipelines from Flink sinks  

### Example: Trigger Flink Job
```python
run_flink = FlinkKubernetesOperator(
    task_id="run_flink",
    cluster_id="flink-cluster",
    job_jar="/opt/jobs/stream.jar"
)
```

---
# 25.6 Airflow + AWS Kinesis
Kinesis is AWS’s native streaming platform.

### Use Cases
✔ Monitor shard lag  
✔ Trigger downstream ETL when enough data accumulates  
✔ Write aggregated files into S3 for Airflow to process

### Example: Kinesis Lag Check
```python
@task
def check_kinesis_lag():
    lag = kinesis.get_iterator_age()
    if lag > 300:
        alert()
```

---
# 25.7 Airflow + GCP Pub/Sub
Pub/Sub is Google’s streaming backbone.

### Airflow Integrations
- PubSubPublishOperator
- PubSubPullOperator
- PubSubHook

### Example: Trigger Batch Job Once Pub/Sub Bucket Receives Data
Pub/Sub → Dataflow → GCS → Airflow

Use GCS sensors:
```python
GCSObjectExistenceSensor(...)
```

---
# 25.8 Micro-Batch Pipelines with Airflow
Streaming systems often write **micro-batches** to storage:
- Kafka → S3
- Kinesis → S3
- Pub/Sub → GCS

Airflow orchestrates micro-batch processing:
```
Wait for new file → Process batch → Commit status → Trigger downstream
```

---
# 25.9 Hybrid Streaming + Batch (Lambda/Kappa Architecture)
### Lambda Architecture
- Batch (Airflow ETL)
- Speed (Streaming job)
- Unified serving layer

### Kappa Architecture
- Single streaming pipeline  
- Airflow handles backfill + reprocess

---
# 25.10 Daily/Hourly Window Aggregations
Airflow is perfect for window aggregation after streaming ingestion.

Examples:
- Hourly metrics based on streaming tables
- Daily rollups and SCD updates
- ML feature aggregation windows

---
# 25.11 Monitoring Streaming Jobs with Airflow
Airflow can monitor:
- Consumer lag (Kafka/Kinesis)
- Checkpoint age (Flink/Spark)
- Streaming job errors
- Throughput anomalies

### Example: Airflow Alerts
```python
SlackWebhookOperator(..., trigger_rule="one_failed")
```

---
# 25.12 Restarting Streaming Jobs Automatically
Streaming systems fail often.

Airflow can restart jobs:
- Restart Spark Streaming app
- Restart Flink job via REST API
- Restart Kafka consumers

### Example
```python
restart = BashOperator(
    task_id="restart_stream",
    bash_command="systemctl restart spark_streaming_service"
)
```

---
# 25.13 Anti-Patterns in Airflow + Streaming
### ❌ Anti-Pattern: Using Airflow for real-time, sub-second processing  
Use Flink/Kafka Streams/Spark Streaming instead.

### ❌ Anti-Pattern: Using sensors for every micro-batch  
Use Datasets or event triggers instead.

### ❌ Anti-Pattern: Overusing XComs for high-volume metadata  
Store metadata in tables instead.

---
# 25.14 Best Practices
✔ Use Airflow for orchestration—not real-time compute  
✔ Use sensors in reschedule mode  
✔ Use Datasets for file-driven workflows  
✔ Use Spark/Flink for heavy stream compute  
✔ Offload large computations to Databricks/EMR  
✔ Monitor lag + checkpoints regularly  
✔ Use alerting for streaming failures  

---
# 25.15 Summary
In this chapter, you learned:
- How Airflow integrates with Kafka, Spark Streaming, Flink, Kinesis, Pub/Sub
- Hybrid streaming + batch workflows
- Monitoring and restarting streaming jobs
- Micro-batch and event-driven ingestion patterns
- Anti-patterns & best practices

---
