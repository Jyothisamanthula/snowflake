# Chapter 7: Error Handling, Retries, Alerting & SLAs in Apache Airflow

In this chapter, we explore how Apache Airflow manages task failures, retries, alerts, notifications, SLAs, and debugging best practices. These concepts are essential for running **reliable production pipelines**.

---

# 7.1 How Airflow Handles Task Failures
A task can fail due to:
- Code errors
- Resource limits
- External API failures
- Timeouts
- Dependency failures

Airflow marks failed tasks as:
- **failed** → task error
- **upstream_failed** → dependency failed
- **skipped** → triggered by rules

You can view logs in the UI under *Log* tab.

---

# 7.2 Retries — Automatic Recovery
Retries allow tasks to recover from transient issues like API timeouts.

### Common retry settings:
```python
retry_delay=timedelta(minutes=5)
retries=3
```

### Example:
```python
PythonOperator(
    task_id='call_api',
    python_callable=api_call,
    retries=5,
    retry_delay=timedelta(minutes=2)
)
```

### Best Practices:
✔ Retry intermittent failures (APIs, S3, warehouse loads)  
❌ Don’t retry deterministic failures (syntax errors, logic errors)

---

# 7.3 Timeouts — Kill Hung Tasks
### Types of timeouts:
- **execution_timeout** — per task
- **dagrun_timeout** — entire DAG

### Example:
```python
PythonOperator(
    task_id="slow_task",
    python_callable=run_job,
    execution_timeout=timedelta(hours=1)
)
```

---

# 7.4 Trigger Rules — Handling Conditional Flows
Trigger rules control when tasks run.

### Common examples:
- `all_success` (default)
- `one_success`
- `all_failed`
- `all_done`

### Example — Cleanup task that always runs:
```python
cleanup = PythonOperator(
    task_id="cleanup",
    python_callable=cleanup_fn,
    trigger_rule="all_done"
)
```

---

# 7.5 Alerts & Notifications
Airflow supports notifications via:
- Email
- Slack
- PagerDuty
- Custom webhooks

### Email Alert Example:
Add to `default_args`:
```python
default_args = {
    'email': ['alerts@company.com'],
    'email_on_failure': True,
    'email_on_retry': False,
}
```

### Slack Notification Example:
```python
from airflow.operators.slack_webhook_operator import SlackWebhookOperator

notify = SlackWebhookOperator(
    task_id="alert_slack",
    http_conn_id="slack_conn",
    message="Task failed!",
    trigger_rule="one_failed"
)
```

---

# 7.6 Failure Callbacks — Custom Failure Logic
Use callbacks for custom error responses.

### Example — Send Slack + Email + Log on failure:
```python
def task_fail_alert(context):
    print("Task failed!")

PythonOperator(
    task_id="process_data",
    python_callable=process_fn,
    on_failure_callback=task_fail_alert
)
```

---

# 7.7 SLAs (Service Level Agreements)
SLAs define how long a task *should* take.

### Example:
```python
sla=timedelta(hours=2)
```

### SLA Miss:
- Logged in UI
- Email notification sent
- Does *not* kill the task

SLAs help enforce reliability standards.

---

# 7.8 Retry Strategies for Production Pipelines
### 1. Exponential Backoff
```python
retries=5,
retry_exponential_backoff=True
```

### 2. Retry Jitter
Prevents thundering herd issues when many tasks retry simultaneously.

```python
retry_delay=timedelta(minutes=1),
max_retry_delay=timedelta(minutes=10)
```

---

# 7.9 Debugging Failed Tasks
### Check:
1. **Logs** → primary source of truth
2. **Rendered template** → Jinja errors
3. **Task tries**
4. **Upstream dependencies**

### CLI debugging:
```bash
airflow tasks test dag_id task_id 2024-01-01
```
Runs a task *locally* without the scheduler.

---

# 7.10 Task-Level Error Patterns
### Transient Error Examples:
- API unreachable
- S3 rate limit
- Warehouse timeout

**Fix:** Retries + fallback logic

### Permanent Errors:
- Wrong SQL syntax
- Missing file
- Code bugs

**Fix:** Fix the code, avoid retries

---

# 7.11 DAG-Level Error Patterns
### Common:
- Infinite retries
- Blocking downstream tasks
- Tasks never running

### Best Practices:
- Use `max_active_runs=1` for stateful DAGs
- Set reasonable timeouts
- Use sensors in `reschedule` mode

---

# 7.12 Designing Reliable Airflow Pipelines
✔ Add retries for flaky tasks  
✔ Add Slack alerts for failures  
✔ Use SLAs to detect slow pipelines  
✔ Use callbacks for custom incident handling  
✔ Use task groups for clarity  
❌ Avoid long-running Python tasks  
❌ Don’t overuse sensors in poke mode

---

# 7.13 Summary
In this chapter, you learned:
- How Airflow handles task failures
- Retries, timeouts, trigger rules, alerts
- Slack/email/webhook notifications
- SLA enforcement
- Error handling patterns for production

---

