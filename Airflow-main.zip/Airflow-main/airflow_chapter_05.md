# Chapter 5: Operators, Hooks, Sensors & XComs — The Core of Airflow DAGs

This chapter dives into the building blocks of Airflow workflows: **Operators**, **Hooks**, **Sensors**, and **XComs**. Together, they power nearly every Airflow pipeline, from simple ETLs to complex distributed data workflows.

---

# 5.1 Understanding Operators
Operators are the heart of Airflow—they define *what* a task does.

There are 4 major categories:

## 1. Action Operators
Execute actions directly.

Examples:
- **PythonOperator** — run Python functions
- **BashOperator** — run shell commands
- **EmailOperator** — send emails
- **SQL Operators** (BigQuery, Snowflake, Postgres)
- **DockerOperator** — run workloads in Docker containers

### Example: PythonOperator
```python
from airflow.operators.python import PythonOperator

def my_task():
    print("Running Python code!")

run_task = PythonOperator(
    task_id="run_python",
    python_callable=my_task,
)
```

---

## 2. Transfer Operators
Used for moving data between systems.

Examples:
- **S3ToGCSOperator**
- **GCSFileTransformOperator**
- **MySqlToGCSOperator**
- **S3ToRedshiftOperator**

---

## 3. Sensors
Wait for a condition to be true.

Examples:
- **FileSensor** — wait for a file
- **ExternalTaskSensor** — wait for another DAG
- **S3KeySensor** — wait for S3 object
- **TimeSensor** — wait for clock time

### Example:
```python
from airflow.sensors.filesystem import FileSensor

FileSensor(
    task_id="wait_for_file",
    filepath="/data/input.csv",
    poke_interval=30,
)
```

Sensors "poke" periodically until the condition is met.

---

## 4. Trigger Operators
Used for event-based DAG triggering.

Examples:
- **TriggerDagRunOperator** — trigger another DAG
- **TriggerRule** — control downstream execution

---

# 5.2 Hooks — Connecting to External Systems
Hooks provide interfaces to systems like:
- AWS S3
- GCP
- Databases (MySQL, Postgres, SQL Server)
- APIs

A hook handles:
- Authentication
- Error handling
- Connection pooling

### Example: S3Hook
```python
from airflow.providers.amazon.aws.hooks.s3 import S3Hook

hook = S3Hook(aws_conn_id="aws_default")
files = hook.list_keys(bucket_name="raw-data")
```

Hooks are used inside custom operators or Python tasks to interact with external systems.

---

# 5.3 Sensors — Waiting Intelligently
Sensors pause execution until a condition is met.

### Types of sensors:
- **Time-based** (TimeSensor)
- **External job-based** (ExternalTaskSensor)
- **File-based** (FileSensor, S3KeySensor)

### Modes:
- **poke mode** (default): sensor checks every X seconds
- **reschedule mode**: frees worker slots → efficient for long waits

### Example:
```python
FileSensor(
    task_id="wait_for_file",
    filepath="/opt/data/report.csv",
    mode="reschedule"
)
```

---

# 5.4 XComs — Passing Data Between Tasks
XCom = **Cross-Communication** between tasks.

XComs allow tasks to:
- Push values
- Pull values

### Example — Pushing XCom
```python
def push_data(**kwargs):
    kwargs['ti'].xcom_push(key='my_key', value='hello')
```

### Example — Pulling XCom
```python
def pull_data(**kwargs):
    value = kwargs['ti'].xcom_pull(key='my_key', task_ids='push_task')
    print(value)
```

### Best Practices:
✔ Use XComs for small metadata only  
❌ Do NOT pass large datasets through XComs

---

# 5.5 Custom Operators — When Built-ins Are Not Enough
You can create custom operators by extending `BaseOperator`.

### Example Custom Operator:
```python
from airflow.models import BaseOperator

class PrintMessageOperator(BaseOperator):
    def __init__(self, message, **kwargs):
        super().__init__(**kwargs)
        self.message = message

    def execute(self, context):
        print(self.message)
```

Use it like:
```python
PrintMessageOperator(
    task_id="print_msg",
    message="Hello Airflow!"
)
```

---

# 5.6 Understanding Trigger Rules
Trigger rules define when downstream tasks run.

Common rules:
- `all_success` (default)
- `all_failed`
- `one_success`
- `none_failed`
- `all_done`

### Example: Run task even if upstream fails
```python
from airflow.utils.trigger_rule import TriggerRule

cleanup = PythonOperator(
    task_id="cleanup",
    python_callable=cleanup_fn,
    trigger_rule=TriggerRule.ALL_DONE
)
```

---

# 5.7 Task Groups — Better DAG Organization
Task Groups help organize complex DAGs.

```python
from airflow.utils.task_group import TaskGroup

with TaskGroup("processing_group") as tg:
    t1 = EmptyOperator(task_id="step_1")
    t2 = EmptyOperator(task_id="step_2")
```

Task Groups appear visually grouped in the UI.

---

# 5.8 Summary
In this chapter, you learned:
- What operators are and how to use them
- How hooks interact with external systems
- How sensors intelligently wait for events
- How XComs transfer data between tasks
- How to implement custom operators
- Trigger rules and task groups

---

