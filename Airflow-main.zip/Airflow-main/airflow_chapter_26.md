# Chapter 26: Airflow Metadata-Driven Pipelines & Dynamic DAG Factories

Modern data engineering requires pipelines that adapt automatically to new datasets, new tables, new partitions, or new business rules—**without writing new DAGs manually**. Apache Airflow enables this through **metadata-driven pipelines** and **dynamic DAG factories**.

This chapter explains how to design, build, and scale metadata-driven workflows using Airflow, enabling hundreds or thousands of pipelines with minimal code.

---
# 26.1 What Are Metadata-Driven Pipelines?
A metadata-driven pipeline is a DAG whose behavior is controlled by **metadata**, not hard-coded logic.

Examples of metadata:
- List of tables to ingest
- Source-to-target mapping
- Schema definitions
- File paths, API endpoints
- Validation rules
- Load frequencies

### Benefits
✔ Auto-generation of pipelines  
✔ No code duplication  
✔ Easy to onboard new datasets  
✔ Business users can manage configs  
✔ Faster pipeline development

---
# 26.2 Airflow Dynamic DAGs
Airflow allows **DAGs to be created programmatically** using Python.

Example:
```python
for table in TABLE_LIST:
    dag_id = f"ingest_{table}"
    globals()[dag_id] = create_ingest_dag(table)
```

Every table becomes its own Airflow DAG.

---
# 26.3 Why Dynamic DAG Factories?
Enterprises may need:
- 100+ ingestion DAGs
- 500+ table-level validation pipelines
- Thousands of DAGs for lakehouse partitions

Dynamic Dag Factories allow:
- One Python file → hundreds of DAGs
- Config stored externally (YAML, DB, API)

---
# 26.4 Common Metadata Stores
Metadata commonly stored in:
- YAML/JSON files
- S3/GCS/Blob Storage
- PostgreSQL metadata database
- Feature store metadata
- Data catalog (e.g., Glue Data Catalog)

### Example YAML config
```yaml
sources:
  - name: customer
    path: s3://raw/customer/
    frequency: daily
    validations: [not_null, unique]
  - name: orders
    path: s3://raw/orders/
    frequency: hourly
```

---
# 26.5 Building a Dynamic DAG Factory
## Step 1: Define Metadata Source
```python
import yaml
config = yaml.safe_load(open("configs/tables.yml"))
```

## Step 2: Define a DAG Template Function
```python
def create_ingest_dag(table_config):
    with DAG(
        dag_id=f"ingest_{table_config['name']}",
        schedule=table_config['frequency'],
        catchup=False,
    ) as dag:

        task = PythonOperator(
            task_id="ingest",
            python_callable=ingest_data,
            op_kwargs={"path": table_config['path']}
        )

        return dag
```

## Step 3: Dynamically Register DAGs
```python
for table in config['sources']:
    dag = create_ingest_dag(table)
    globals()[dag.dag_id] = dag
```

---
# 26.6 Using Dynamic Task Mapping
Airflow 2.3+ allows tasks to scale dynamically.

Example: process every partition in S3:
```python
process_partition.expand(partition=list_of_partitions)
```

Use Cases:
- Partition-level ETL
- Multi-file ingestion
- Multitenant pipelines
- API pagination

---
# 26.7 Metadata-Driven Data Quality Pipelines
Define validation logic in metadata:
```yaml
validations:
  - column: customer_id
    check: not_null
  - column: age
    check: range
    min: 0
    max: 120
```

Airflow pipeline reads metadata → generates GE/Soda/dbt tests.

---
# 26.8 Scalable Multi-Tenant Pipelines
Enterprises may need pipelines per
- Business unit
- Country
- Customer/client
- Domain

Metadata like:
```yaml
tenants:
  - us
  - eu
  - apac
```

Dynamic task mapping:
```python
run_pipeline.expand(region=config['tenants'])
```

---
# 26.9 Integrating with Data Catalogs
Airflow can read metadata from:
- AWS Glue
- Unity Catalog
- BigQuery metadata
- Apache Atlas
- Amundsen

Example using Glue:
```python
import boto3
crawler = boto3.client('glue').get_tables(DatabaseName='raw')
```

---
# 26.10 Building a Metadata-Driven Lakehouse ETL
Example architecture:
```
YAML metadata → DAG factory → dynamic tasks → Delta processing → validations → marts
```

---
# 26.11 Scheduling via Metadata
Metadata includes schedule patterns:
```yaml
frequency: "0 3 * * *"
catchup: false
retry_count: 3
```

Airflow reads → assigns to DAG.

---
# 26.12 Enterprise Case Study (Example)
A financial institution ingests 500+ tables.

Metadata-driven architecture:
- YAML config in Git
- DAG Factory reads config daily
- DAGs created per table
- GE tests mapped from metadata
- Delta Lake compaction per table

Results:
✔ 70% reduction in pipeline creation time  
✔ Zero code duplication  
✔ Fully auditable metadata configs

---
# 26.13 Anti-Patterns
### ❌ Anti-pattern: Over-automating DAG generation
Too many DAGs can overwhelm the scheduler.

### ❌ Anti-pattern: Loading all metadata at parse time
Use lazy loading for large configs.

### ❌ Anti-pattern: Giant DAG factories with thousands of DAGs
Split factories by domain.

---
# 26.14 Best Practices
✔ Store metadata externally (YAML/DB)  
✔ Use DAG factories for ingestion, DQ, and transformations  
✔ Use dynamic task mapping instead of writing loops  
✔ Cache metadata for performance  
✔ Keep DAGs lightweight—run heavy logic in tasks  
✔ Use Git for metadata version control  
✔ Split metadata by domain/team

---
# 26.15 Summary
In this chapter, you learned:
- How to design metadata-driven Airflow pipelines
- How to build dynamic DAG factories
- How to scale pipelines to hundreds or thousands of DAGs
- How to integrate metadata from catalogs like Glue & Atlas
- Best practices & anti-patterns for dynamic DAG creation

---