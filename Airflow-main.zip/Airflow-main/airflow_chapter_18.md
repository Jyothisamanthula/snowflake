# Chapter 18: Advanced Airflow Security, Access Control & Secrets Management

Security is one of the most critical aspects of a modern Airflow deployment. As Airflow orchestrates sensitive and mission‑critical pipelines, it must be protected from unauthorized access, credential leaks, data exposure, and misconfigurations.

This chapter covers **authentication**, **authorization**, **RBAC**, **secrets management**, **network security**, and **cloud‑grade security patterns** for Airflow.

---
# 18.1 Why Security Matters in Airflow
Airflow pipelines often interact with:
- Data warehouses
- Cloud storage
- Payment systems
- CRM/ERP systems
- APIs containing sensitive data

A security breach can:
- Expose credentials
- Leak customer data
- Run unauthorized pipelines
- Modify business data
- Compromise infrastructure

---
# 18.2 Airflow Security Model Overview
Airflow security includes:
- **Authentication (AuthN)** → who can log in?
- **Authorization (AuthZ)** → what can they do?
- **RBAC UI** → role‑based permissions
- **Secrets Management** → where are credentials stored?
- **Network Security** → access, IP policies, VPC
- **API Security** → REST API access restrictions

---
# 18.3 Authentication (AuthN)
Airflow supports many authentication backends.

### Built‑in methods
- Password auth
- OAuth2 / OIDC
- LDAP
- Google Auth
- GitHub / GitLab login via OIDC

### Example: Enable Authentication
In `airflow.cfg`:
```
auth_backend = airflow.contrib.auth.backends.password_auth
```

### OAuth2 / OIDC Best Practice
Use enterprise identity providers:
- Okta
- Azure AD
- Google Identity Platform
- Auth0

This gives SSO, MFA, and centralized identity governance.

---
# 18.4 Authorization (AuthZ) with RBAC
Airflow provides a Role‑Based Access Control system (RBAC UI).

### Built‑in roles:
- `Admin`
- `User`
- `Op`
- `Viewer`
- `Public` (optional)

### Custom roles
You can define highly granular permissions:
- DAG read/write
- Trigger DAGs
- Edit connections
- View logs
- Access variables

### Best Practice
✔ Give developers *read‑only* access in production  
✔ Restrict "Connections" to admins only  
✔ Use separate roles for DataOps, DevOps, and Analytics Engineers  

---
# 18.5 API Security
Airflow's Stable REST API must be secured.

### Disable unauthenticated API access:
```ini
auth_backend = airflow.api.auth.backend.basic_auth
```

### Best Practices
✔ Use token‑based access with expirations  
✔ Restrict API access using IP whitelisting  
✔ Never expose the API publicly

---
# 18.6 Secrets Management (Most Important)
Never store secrets in:
- DAG code
- Variables
- Environment variables (production)
- Git repositories

Use **Secret Backends** instead.

### Supported Secret Backends:
- AWS Secrets Manager
- GCP Secret Manager
- HashiCorp Vault
- Azure Key Vault
- Kubernetes Secrets
- SOPS

### Example: Enable AWS Secrets Manager
```ini
[secrets]
backend = airflow.providers.amazon.aws.secrets.secrets_manager.SecretsManagerBackend
backend_kwargs = {"connections_prefix": "airflow/connections", "variables_prefix": "airflow/variables"}
```

---
# 18.7 Best Practices for Connections
✔ Use IAM roles instead of keys (AWS)  
✔ Use Workload Identity Federation (GCP)  
✔ Use Managed Identity (Azure)  
✔ Never store access keys in Airflow UI  
✔ Rotate secrets regularly  

---
# 18.8 Network Security
Airflow should always run inside a **private network** (VPC/VNet).

### Cloud Network Best Practices
✔ Private subnets for schedulers/workers  
✔ NAT gateway for outbound traffic  
✔ Security groups restricting inbound access  
✔ VPC peering for warehouse connectivity  
✔ No direct public internet exposure

### MWAA Example
- Webserver accessible only via IAM / Private Link  
- Workers in private subnets  

---
# 18.9 Encryption
Airflow should use encryption for:

### 1. Data at Rest
- RDS / CloudSQL encryption
- S3/GCS bucket encryption (KMS keys)
- Encrypted logs

### 2. Data in Transit
- HTTPS/SSL for UI
- Encrypted API calls

### 3. DAG Files
- KMS encryption of DAG buckets

---
# 18.10 Securing Airflow Metadata Database
Metadata DB stores:
- XComs
- Task states
- Variables
- DAG run metadata
- Connection references

### Best Practices
✔ Use managed DB (RDS, CloudSQL)  
✔ Enable automatic backups  
✔ Restrict network access  
✔ Use SSL/TLS connections  
✔ Restrict DB credentials

---
# 18.11 Securing Logs
Logs often contain sensitive info.

### Best Practices
✔ Use S3/GCS logs with encryption  
✔ Restrict bucket access with IAM policies  
✔ Don't print secrets in DAG logs  
✔ Use redaction filters

---
# 18.12 Multi‑Tenant Security
Common in large organizations.

### Best Practices
✔ Per‑team Airflow environments (namespace isolation)  
✔ Per‑team RBAC roles  
✔ Resource isolation via queues/pools  
✔ Separate Connections per team

---
# 18.13 Supply Chain Security for Airflow
Protect Airflow DAGs from malicious code.

### Techniques
- Hash‑pinned Python packages  
- Verified provider packages  
- Docker image signing (Cosign/Sigstore)  
- CI/CD signature validation  

---
# 18.14 Secrets in Kubernetes Executor
Use Kubernetes Secrets + environment variables or volume mounts.

### Example:
```yaml
apiVersion: v1
kind: Secret
metadata:
  name: db-secret
stringData:
  password: ABC123
```

Inside DAG:
```python
KubernetesPodOperator(..., env_vars={"DB_PWD": "{{ conn.db.password }}"})
```

---
# 18.15 Security Audit Checklist
✔ RBAC enabled  
✔ Authentication via OAuth2/OIDC  
✔ API authentication enabled  
✔ Secret backend enabled  
✔ No secrets in code  
✔ Workers in private subnets  
✔ Metadata DB secured with SSL  
✔ Remote logs encrypted  
✔ DAG buckets encrypted  
✔ Pools used for limiting access to external systems  
✔ Version‑pinned dependencies  
✔ SSO + MFA enabled

---
# 18.16 Summary
In this chapter, you learned:
- How Airflow handles authentication & authorization
- RBAC roles and permission models
- Best practices for secure connections
- Using secret backends for secure credential storage
- Network, VPC, and encryption strategies
- Secure API usage and metadata DB protection

---

