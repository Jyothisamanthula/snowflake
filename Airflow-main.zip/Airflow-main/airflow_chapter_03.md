# Chapter 3: Setting Up Your Airflow Development Environment

In this chapter, you will set up Apache Airflow from scratch on your local machine and learn about environments, installation methods, file structure, and initial configuration. This is the foundation for becoming productive with Airflow.

---

## 3.1 Installing Apache Airflow — Recommended Approach
Airflow must be installed with **constraints files** to ensure version compatibility.

### Install with pip (recommended):
```bash
pip install "apache-airflow==2.9.0" --constraint "https://raw.githubusercontent.com/apache/airflow/constraints-2.9.0/constraints-3.10.txt"
```
Replace Python version (3.10) as needed.

---

## 3.2 Installation Using Docker (Best for Beginners)
Airflow provides an official Docker Compose setup.

### Step 1 — Download official template:
```bash
curl -LfO 'https://airflow.apache.org/docs/apache-airflow/stable/docker-compose.yaml'
```

### Step 2 — Initialize Airflow:
```bash
airflow db init
```

### Step 3 — Start Airflow:
```bash
docker compose up
```

This launches:
- Webserver
- Scheduler
- Triggerer
- Workers (if Celery Executor)
- Postgres (metadata DB)
- Redis (for Celery)

---

## 3.3 Installing Airflow via Astronomer CLI
Astronomer provides a cloud-grade local environment:
```bash
curl -sSL https://install.astronomer.io | sudo bash
astro dev init
astro dev start
```

Useful for enterprise Airflow development.

---

## 3.4 Installing Airflow on Cloud Platforms
### **Google Cloud Composer**
Fully managed Airflow service for GCP.

### **Amazon MWAA (Managed Workflows for Apache Airflow)**
Managed Airflow on AWS.

### **Astronomer Cloud**
Fully managed Airflow SaaS.

These services handle:
- Schedulers
- Executors
- Logging
- Workers
- Upgrades

---

## 3.5 Understanding Airflow Home Directory
The Airflow home folder contains:
```
~/airflow/
  ├── airflow.cfg
  ├── dags/
  ├── logs/
  ├── plugins/
  └── webserver_config.py
```

### Purpose of each folder:
- **dags/** — your DAG files
- **plugins/** — custom operators, sensors, hooks
- **logs/** — task logs
- **airflow.cfg** — main configuration

---

## 3.6 Initializing Metadata Database
Airflow stores states in a SQL DB.
```bash
airflow db init
```

For Docker Compose, this happens automatically.

---

## 3.7 Creating an Admin User
To access Airflow UI:
```bash
airflow users create \
   --username admin \
   --firstname Air \
   --lastname Flow \
   --role Admin \
   --email admin@example.com
```

---

## 3.8 Starting Airflow Components
### Standalone Mode (for learners):
```bash
airflow standalone
```

Starts:
- Webserver
- Scheduler

### Full Multi-Container Mode (production-style):
```bash
docker compose up -d
```

---

## 3.9 Environment Variables
Common environment variables:
```
AIRFLOW_HOME
AIRFLOW_CONFIG
AIRFLOW__CORE__EXECUTOR
AIRFLOW__CORE__LOAD_EXAMPLES
```

Useful for customizing behavior.

---

## 3.10 Verifying Installation
Open Airflow UI:
```
http://localhost:8080
```

Verify:
- Scheduler is running
- Default example DAGs load
- Logs are accessible

---

## 3.11 Best Practices for Environment Setup
- Use **Docker** for isolated environment
- Use **Postgres** instead of SQLite
- Store credentials in **Airflow Connections**
- Use **.env** file for secrets
- Use **version-pinned dependencies** for stability

---

## 3.12 Summary
You now have a fully working Apache Airflow environment. You learned:
- How to install Airflow using pip, Docker, Astronomer
- How to set up Airflow folder structure
- How to initialize and configure metadata DB
- How to run Airflow services

---

