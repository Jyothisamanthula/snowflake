# Chapter 27: Airflow SLAs, Notifications & Alerting Frameworks

As Airflow orchestrates critical business workloads, it must provide strong mechanisms to detect failures, delays, anomalies, and SLA breaches. This chapter explores how to implement **SLA monitoring**, **alerting frameworks**, **real-time notifications**, and **incident management workflows** within Airflow.

We cover:
- SLAs & task-level monitoring
- Failure alerts & retries
- Custom on-failure callbacks
- Email/Slack/PagerDuty/Teams integrations
- Error handling design patterns

---
# 27.1 What Are SLAs in Airflow?
SLA = *Service Level Agreement*, defining the maximum allowed time for a task or DAG completion.

Airflow SLAs apply to:
- Task duration
- DAG duration
- Data freshness expectations

### Example
A pipeline must finish by **7:00 AM daily**; if not, Airflow triggers an SLA miss.

---
# 27.2 Defining SLAs in Tasks
Airflow allows setting SLAs on each task.

```python
PythonOperator(
    task_id="transform_data",
    python_callable=run_job,
    sla=timedelta(hours=2),
)
```

If the task exceeds 2 hours → Airflow sends an SLA alert.

---
# 27.3 SLA Miss Callbacks
Define a global callback for SLA misses.

```python
def sla_miss_callback(dag, task_list, blocking_task_list, slas, blocking_tis):
    send_slack_alert("SLA Missed!")
```

Enable in DAG:
```python
DAG(sla_miss_callback=sla_miss_callback)
```

---
# 27.4 Notifications for Task Failures
### Built-In Failure Notifications
Use `on_failure_callback`:

```python
def failure_alert(context):
    send_slack_alert(f"Task Failed: {context['task_instance']}")
```

Attach to a task:
```python
PythonOperator(
    task_id="load_data",
    python_callable=run,
    on_failure_callback=failure_alert
)
```

You can also use:
- `on_success_callback`
- `on_retry_callback`

---
# 27.5 Email Alerts
Airflow provides email alerts with minimal setup.

### Enable Email Backend
In `airflow.cfg`:
```
[email]
email_backend = airflow.utils.email.send_email_smtp
```

### Example
```python
default_args = {
    'email': ['data-team@example.com'],
    'email_on_failure': True,
}
```

---
# 27.6 Slack Alerts
Slack alerts are the most common Airflow notification method.

### Using SlackWebhookOperator
```python
from airflow.providers.slack.operators.slack_webhook import SlackWebhookOperator

SlackWebhookOperator(
    task_id="slack_alert",
    message="Pipeline failed!",
    http_conn_id="slack_connection"
)
```

### Reusable Slack Alert Function
```python
def slack_alert(context):
    SlackWebhookOperator(
        task_id=f"alert_{context['task_instance'].task_id}",
        message=f"Task Failed: {context['task_instance']}"
    ).execute(context=context)
```

---
# 27.7 Teams / PagerDuty / OpsGenie Alerts
Airflow can integrate with:
- PagerDuty (PagerDutyEventsHook)
- Microsoft Teams Webhook Operator
- OpsGenie Alerts
- ServiceNow incidents

Example: PagerDuty
```python
PagerDutyEventsHook(token="xxx").send_trigger("Airflow Failure")
```

---
# 27.8 Failure Retry Strategies
Retries are a core part of resilient workflows.

### Example Retry Settings
```python
PythonOperator(
    task_id="fetch_api",
    python_callable=call_api,
    retries=5,
    retry_delay=timedelta(minutes=2),
    retry_exponential_backoff=True
)
```

### Best Practices
✔ Exponential backoff for flaky APIs  
✔ Retry only idempotent tasks  
✔ Avoid infinite retry loops  

---
# 27.9 Custom Failure Handling Patterns
### Pattern 1: Fail Fast
Raise exception immediately → stop downstream.

### Pattern 2: Fail Quietly and Continue
Useful in optional tasks.

### Pattern 3: Mark Success Regardless
Use `TriggerRule.ALL_DONE`.

### Pattern 4: Retry-then-Fallback
```
main_task >> fallback_task
```

---
# 27.10 DAG-Level Alerting
Define alerts once at the DAG level:
```python
DAG(
    dag_id="daily_etl",
    on_failure_callback=slack_alert
)
```

---
# 27.11 SLA Miss vs Task Failure
| Behavior | SLA Miss | Task Failure |
|----------|----------|--------------|
| Task completed? | Yes | No |
| Trigger alert | Yes | Yes |
| Retries? | No | Yes |
| Affects downstream? | No | Yes |

---
# 27.12 Monitoring Airflow SLAs & Alerts with Observability Tools
Tools:
- Datadog Airflow integration
- Prometheus (Airflow exporter)
- Grafana dashboards
- Monte Carlo (data observability)
- OpenLineage tracking

### Common Metrics
- DAG duration  
- Task duration  
- SLA miss count  
- Number of failures  
- Late tasks  
- Scheduler delays  

---
# 27.13 Advanced Alert Routing
Send different alerts to different teams:
- Data Engineering  
- ML Team  
- BI Team  
- DevOps Team  

### Pattern
```python
if "billing" in dag_id:
    notify_billing()
```

Or define custom `owner` fields.

---
# 27.14 Error Categorization and Auto-Healing
### Categorize Failures
- Infrastructure failure  
- API rate limits  
- Data quality issues  
- Resource shortages  

### Auto-Healing Examples
- Restart streaming jobs  
- Retry with different cluster sizes  
- Clear stuck tasks  
- Rebuild EMR/Dataproc clusters

---
# 27.15 Building a Global Alert Handler Module
Create a shared module:
```
plugins/alerting/
    slack_alert.py
    email_alert.py
    pagerduty_alert.py
```

Use across all DAGs.

---
# 27.16 Alerting Anti-Patterns
### ❌ Too many alerts → alert fatigue
### ❌ Logging secrets in alerts  
### ❌ Triggering failures on optional tasks  
### ❌ No DAG-level alerts (repeating code per task)

---
# 27.17 Best Practices
✔ Use DAG-level callbacks  
✔ Use Slack alerts for rapid communication  
✔ Use retries with exponential backoff  
✔ Separate critical alerts from non-critical  
✔ Use observability tools to monitor SLAs  
✔ Use alert throttling to avoid noise  
✔ Build a shared alerting module  

---
# 27.18 Summary
In this chapter, you learned:
- How to configure SLAs, callbacks, failure alerts, retry logic
- How to integrate Slack, Email, PagerDuty & Teams
- Best practices for alert routing & incident handling
- Common anti-patterns & production-grade alert workflows

---

