# Chapter 2: Airflow Architecture & Core Components

Apache Airflow follows a modular, scalable, and distributed architecture designed to orchestrate workflows reliably at scale. This chapter provides a deep dive into every moving piece inside Airflow and how they interact.

---

## 2.1 High-Level Architecture Overview
Airflow’s architecture consists of the following core components:
- **Webserver** — UI for monitoring, browsing logs, managing DAGs
- **Scheduler** — Determines task order & submits tasks to queues
- **Executor** — Defines *how* tasks are executed
- **Worker(s)** — Execute tasks using the executor
- **Metadata Database** — Stores job state, DAG runs, task instances
- **DagBag** — In-memory collection of all parsed DAGs
- **Message Queue** (Celery/K8s) — Used when running distributed execution

A simplified flow:
```
Scheduler → Queue → Worker → Task Execution → Metadata DB → Webserver UI
```

---

## 2.2 Webserver
The Airflow webserver provides:
- DAG list and statuses
- DAG run history
- Task-level logs
- Graph view, tree view, calendar view
- Triggering manual DAG runs
- Pausing/unpausing DAGs

It is a **Flask** application running in the background.

---

## 2.3 Scheduler
The scheduler is the “brain” of Airflow.

Responsibilities:
- Parse DAGs
- Build DAG run schedules
- Detect task dependencies
- Submit tasks to the executor
- Maintain task state in the database

It runs continuously and wakes up periodically (default: every 5 sec).

---

## 2.4 Metadata Database
Airflow uses a relational database to store:
- DAG definitions
- Task instance states
- DAG runs
- XComs
- Variables & connections

Supported DBs:
- PostgreSQL (recommended)
- MySQL
- SQLite (development only)

---

## 2.5 The Executor
Executors define **how** Airflow runs tasks.

### Types of executors:
1. **SequentialExecutor** — runs tasks one-by-one (local dev)
2. **LocalExecutor** — parallel tasks on single machine
3. **CeleryExecutor** — distributed workers + queue
4. **KubernetesExecutor** — each task runs in its own pod
5. **CeleryKubernetesExecutor** — hybrid model

Executors are the key to scaling Airflow.

---

## 2.6 Workers
Workers process actual task execution.

With **CeleryExecutor**:
- Multiple workers scale horizontally
- Tasks are pushed to queues
- Workers pull tasks asynchronously

With **KubernetesExecutor**:
- No long-running workers
- Airflow spawns pods per task dynamically

---

## 2.7 Message Queues (Celery Only)
Airflow uses a message broker like:
- Redis
- RabbitMQ

to distribute tasks.

Workflow with Celery:
```
Scheduler → Queue → Worker → Task
```

---

## 2.8 DAG Folder & DagBag
Airflow scans a directory (DAG folder) and loads:
- DAG definitions
- Python files

DagBag is the in-memory representation of all DAGs.

---

## 2.9 Logs
Airflow stores logs:
- Locally (default)
- Remote storage (S3, GCS, Azure)

This is essential for distributed workers.

---

## 2.10 Airflow Components Interaction Flow
Detailed flow:
```
1. DAGs placed in DAG folder
2. Scheduler parses DAGs → DagBag
3. Scheduler determines what tasks to execute
4. Scheduler submits tasks to executor
5. Executor pushes tasks to workers (Local/Celery/K8s)
6. Workers run tasks and update metadata DB
7. Webserver UI pulls data from DB and displays status
```

---

## 2.11 Typical Airflow Deployment Patterns
### Local deployment (dev)
- SequentialExecutor
- SQLite
- Local webserver

### Production deployment
- CeleryExecutor / KubernetesExecutor
- PostgreSQL metadata DB
- Redis/RabbitMQ
- Remote logging
- Auto-scaling workers

### Cloud-managed
- Google Cloud Composer
- Amazon MWAA
- Astronomer.io

---

## 2.12 Summary
You now understand Airflow’s core architecture and components:
- Webserver
- Scheduler
- Metadata DB
- Executors
- Workers
- DAG parsing

---