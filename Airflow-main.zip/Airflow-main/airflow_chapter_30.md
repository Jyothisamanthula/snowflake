# Chapter 30: Airflow Operations Playbook for SRE/DevOps Teams

Apache Airflow is a mission-critical orchestration engine in modern data platforms. For SRE (Site Reliability Engineering) and DevOps teams, Airflow operations require well-defined processes, monitoring, troubleshooting workflows, and SLIs/SLOs to ensure reliability, performance, and stability.

This chapter provides a **complete operations playbook** tailored for SRE/DevOps teams managing Airflow in production.

---
# 30.1 Airflow Operations Overview
SRE/DevOps teams manage:
- High Availability (Schedulers, Webservers, Workers)
- Environment provisioning
- Deployment pipelines (CI/CD)
- Performance tuning
- Monitoring & telemetry
- Incident management
- Cost controls
- Security & secrets

Operations must ensure Airflow is:  
✔ Reliable  
✔ Secure  
✔ Performant  
✔ Scalable  
✔ Observable  

---
# 30.2 Daily Ops Checklist
### Every morning, check:
✔ Scheduler health (heartbeat, lag)  
✔ Worker queue size  
✔ Stuck/running tasks  
✔ DAG parsing time  
✔ DB CPU/IO utilization  
✔ Broken DAGs  
✔ Failed tasks > threshold  
✔ SLA misses  
✔ Disk space in Airflow logs bucket  

---
# 30.3 Weekly Ops Checklist
✔ Metadata DB maintenance  
✔ Clear old XComs  
✔ Check log retention policy  
✔ Analyze slow DAGs  
✔ Verify autoscaling behavior  
✔ Validate DAG parsing time trends  
✔ Check for new Airflow releases  
✔ Validate dependency vulnerabilities  

---
# 30.4 Monthly Ops Checklist
✔ Upgrade provider packages  
✔ Apply security patches  
✔ Review DAG performance  
✔ Review alerting policies  
✔ Cost optimization review  
✔ Chaos tests (fail scheduler/worker intentionally)  
✔ Validate DR strategy (DB restore test)  

---
# 30.5 Airflow SLIs & SLOs
### SLIs (Service Level Indicators)
- Scheduler uptime (%)
- Task success rate
- Task queue latency
- DAG run duration
- Worker availability
- Metadata DB latency

### SLOs (Service Level Objectives)
- 99.9% scheduler uptime
- 99% successful task runs
- Worker autoscaling time < 3 min
- DAG parsing < 30 seconds

---
# 30.6 Monitoring Airflow
### Monitor These Metrics:
#### Scheduler Metrics
- `scheduler_heartbeat`
- DAG parsing time
- Orphaned tasks

#### Worker Metrics
- Worker CPU / memory
- Queue sizes (Celery/Kafka)
- Pod eviction (K8s)

#### DAG Metrics
- Task duration
- Failure rate trends
- SLA misses

#### Database Metrics
- CPU, IO, connections
- Slow queries

### Tools
- Prometheus + Grafana
- Datadog
- AWS CloudWatch
- GCP Monitoring
- OpenTelemetry
- Sentry for Airflow exceptions

---
# 30.7 Log Management
Logs can overwhelm storage costs.

### Best Practices
✔ Use S3/GCS/Azure for remote logs  
✔ Enable log compression (GZIP)  
✔ Enable lifecycle policies (delete after 90–180 days)  
✔ Do not log full DataFrames or large payloads  
✔ Route critical logs to ELK/Splunk  

---
# 30.8 Incident Management Workflow
### Step 1: Detection
- Alerts via Slack/PagerDuty
- Monitoring dashboards

### Step 2: Classification
Severity 1 (Critical) → Airflow down  
Severity 2 → DAG failures impacting business  
Severity 3 → Delays, non-critical failures  

### Step 3: Diagnosis
- Check scheduler logs  
- Check DB connectivity  
- Inspect worker utilization  
- Validate DAG parsing logs  

### Step 4: Remediation
Examples:
- Restart a scheduler
- Rebuild stuck tasks
- Restart Celery workers / K8s pods
- Resolve dependency store outage

### Step 5: Postmortem
- Document root cause  
- Apply preventive fix  
- Update runbooks

---
# 30.9 Airflow Troubleshooting Guide
### Issue: Scheduler Lag / Slow Scheduling
Possible Causes:
- Too many DAGs  
- Heavy imports in DAG files  
- Slow metadata DB
Solution:
✔ Remove heavy imports  
✔ Move logic to tasks  
✔ Upgrade DB instance  
✔ Reduce number of DAGs

### Issue: Workers Starving / Tasks Pending
Possible Causes:
- Underprovisioned workers  
- Long-running sensor tasks  
- Upstream outage
Solution:
✔ Add workers / enable autoscaling  
✔ Use `reschedule` mode  
✔ Add retries + exponential backoff

### Issue: Tasks Fail Randomly
Possible Causes:
- API rate limits  
- Network issues  
- Dependency version conflicts
Solution:
✔ Retries  
✔ Circuit breaker logic  
✔ Pin dependencies

### Issue: DAG Parsing Slow
Possible Causes:
- Too many dynamic DAGs  
- Heavy Python code in DAG file  
- External API calls in DAG parse phase
Solution:
✔ Move code out of parse time  
✔ Cache metadata  
✔ Split DAGs into domains

---
# 30.10 Runbooks for Common Issues
Runbooks contain step-by-step remediation.

### Example Runbook: Scheduler Down
1. Check scheduler logs  
2. Restart scheduler  
3. Validate DB connectivity  
4. Clear zombie tasks  
5. Check Airflow version for known bugs

### Example Runbook: Worker Pod Crashes
1. Inspect pod logs  
2. Increase memory limits  
3. Validate Python dependencies  
4. Restart deployment

---
# 30.11 CI/CD for Airflow Operations
### Ensure:
✔ DAG validation in CI  
✔ Pre-commit hooks (flake8, black, isort)  
✔ Provider version pinning  
✔ Automated testing of DAG imports  
✔ GitOps deployment pipeline  

---
# 30.12 DR & Backup Requirements
### Backup:
- Metadata DB (daily snapshots + PITR)  
- DAG directory (Git is primary backup)  
- Logs (versioned buckets)

### DR Strategy
- Multi-region failover  
- Standby Airflow environment  
- Replicate metadata DB

---
# 30.13 Security Ops for Airflow
### Enforce:
✔ Secrets in Secret Manager/Vault only  
✔ RBAC setup for all users  
✔ SSL/TLS enabled  
✔ Log redaction for sensitive fields

### Audit
- Login audits  
- Connection edits  
- DAG trigger events

---
# 30.14 Capacity Planning
Plan for:
- Growth in number of DAGs  
- Growth in concurrency  
- Storage requirements  
- DB IOPS for metadata load  
- Log volume increase

### Techniques
✔ Forecast DAG count growth  
✔ Load test scheduler  
✔ Evaluate worker scaling metrics

---
# 30.15 Automation for Ops
### Automate:
- Log cleanup  
- XCom cleanup  
- Stuck task detection  
- Slack alert routing  
- DAG validation nightly  
- Auto-remediation scripts

---
# 30.16 Best Practices
✔ Store DAGs in Git  
✔ Keep DAG parsing < 1 second  
✔ Use Datasets instead of sensors  
✔ Use dynamic task mapping wisely  
✔ Use blue-green deploys for upgrades  
✔ Store configs in YAML/env variables  
✔ Keep workers stateless  
✔ Use Slack alerts for fast triage  
✔ Build runbooks for all common issues

---
# 30.17 Summary
In this chapter, you learned:
- Daily, weekly, and monthly Airflow operations checklists
- SLIs/SLOs for Airflow reliability
- Monitoring, logging, and troubleshooting workflows
- Incident management best practices
- DR, security operations, and automation patterns

---