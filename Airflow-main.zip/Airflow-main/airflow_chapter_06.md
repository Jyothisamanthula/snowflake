# Chapter 6: Scheduling, Backfilling & Catchup in Apache Airflow

This chapter covers one of the most important yet misunderstood topics in Apache Airflow—**scheduling, backfilling, catchup behavior, logical dates, and execution timing**. Mastering these concepts is essential for both beginners and experts building production-grade workflows.

---

# 6.1 Understanding Airflow Scheduling
Airflow schedules DAGs based on **cron expressions** or preset schedules like:
- `@daily`
- `@hourly`
- `@weekly`
- `@once`

You specify this in the DAG definition:
```python
schedule_interval="@daily"
```

---

# 6.2 Logical Date vs Execution Date — The Most Important Concept
Airflow runs DAGs using a concept called **logical date**.

Example:
- A DAG with `@daily` and `start_date=2024-01-01` will first run for **2024-01-01 logical date**.
- But it actually runs **after** the period ends → at **2024-01-02**.

In short:
```
Logical date = the data window being processed
Run date = when Airflow executes the task
```

This is essential for backfills, partitioned data, and incremental workloads.

---

# 6.3 schedule_interval Explained
### Cron example — Run at 3 AM daily
```
schedule_interval="0 3 * * *"
```

### Presets:
- `@daily` → Midnight
- `@hourly`
- `@weekly`
- `@once`

### No schedule (manual only):
```
schedule_interval=None
```

---

# 6.4 start_date — When the DAG First Runs
The `start_date` determines **when the scheduler begins creating DAG runs**.

Example:
```python
start_date=datetime(2024, 1, 1)
```

Airflow will create its *first* run for the interval starting `2024-01-01`.

### Best Practice:
- Set a **static** `start_date` in the past
- Avoid using `datetime.now()`

---

# 6.5 end_date — When DAG Stops Running
Optional parameter:
```python
end_date=datetime(2024, 12, 31)
```

Airflow will stop scheduling new runs after the end date.

---

# 6.6 catchup — Should Airflow Run Missed Schedules?
### catchup=True (default)
Airflow will backfill all missing periods.

### catchup=False
Only runs future intervals.

**Recommended for most business pipelines:**
```
catchup=False
```

---

# 6.7 Backfilling — Reprocessing Past Data
Airflow allows you to manually backfill historical runs.

### Using CLI:
```bash
airflow dags backfill -s 2024-01-01 -e 2024-01-07 my_dag
```

This runs the pipeline for **each day** in the range.

### Use cases:
- Data correction
- Data rebuild after migration
- Reprocessing upstream failures

---

# 6.8 Catchup vs Backfill — When to Use Which
| Feature | Catchup | Backfill |
|---------|---------|----------|
| Automatic? | Yes | No (manual) |
| Runs missed schedules? | Yes | Yes |
| Runs even if DAG paused? | No | Yes |
| Good for long histories? | No | Yes |

---

# 6.9 Understanding Timetables (Airflow 2.4+)
Airflow now supports **custom timetables**.

Examples:
- "Run every last working day of month"
- "Run every 45 minutes"
- "Run every Nth business hour"

### Example timetable usage:
```python
from airflow.timetables.interval import CronDataIntervalTimetable

dag = DAG(
    dag_id="custom_schedule_dag",
    timetable=CronDataIntervalTimetable("0 3 * * 1-5", timezone="UTC"),
    catchup=False,
)
```

---

# 6.10 Paused vs Unpaused DAGs
Newly created DAGs start **paused by default**.
You must enable them from the UI or CLI.

### CLI:
```bash
airflow dags unpause my_dag
```

---

# 6.11 max_active_runs — Control Concurrency
Limits simultaneous DAG runs.

Example:
```python
max_active_runs=1
```

Useful for:
- Stateful pipelines
- Downstream dependencies
- API rate limits

---

# 6.12 Task-Level Concurrency
### task_concurrency
Max number of active tasks of the same type.

### pool configuration
Pools control execution limits for shared resources.

Example:
```bash
airflow pools set api_pool 3 "Limit API calls"
```

---

# 6.13 SLA (Service Level Agreement)
Define execution time expectations.

```python
sla=timedelta(hours=2)
```

Airflow will notify if the task exceeds SLA.

---

# 6.14 Custom Execution Windows
Using **TimeSensor**:
```python
TimeSensor(task_id="wait_till_9am", target_time=time(9,0))
```

---

# 6.15 Summary
In this chapter, you learned:
- How Airflow scheduling works
- Logical date vs physical execution time
- Cron & preset schedules
- Backfilling and catchup
- Timetables and SLAs
- Concurrency and execution limits

---

