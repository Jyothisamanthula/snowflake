# Chapter 12: Advanced Scheduling, Timetables & Cron Patterns in Apache Airflow

Airflow’s scheduling engine is one of its most powerful—and most misunderstood—features. In this chapter, we explore advanced scheduling concepts including cron expressions, custom timetables, data intervals, logical dates, event-based triggers, and enterprise scheduling strategies.

---

# 12.1 Recap: How Airflow Scheduling Works
Airflow schedules tasks **after** the interval ends.

Example:
- A DAG scheduled `@daily` with `start_date = 2024-01-01`
- First run processes: **2024-01-01**
- It executes at: **2024-01-02 00:00**

This is the core difference between **logical date** and **execution date**.

---

# 12.2 Cron Expressions — Deep Dive
Cron format:
```
┌── minute (0–59)
│ ┌── hour (0–23)
│ │ ┌── day of month (1–31)
│ │ │ ┌── month (1–12)
│ │ │ │ ┌── day of week (0–6)
│ │ │ │ │
* * * * *
```

### Common Cron Patterns
| Schedule | Cron |
|----------|------|
| Every day at 2 AM | `0 2 * * *` |
| Every 15 minutes | `*/15 * * * *` |
| Every Monday | `0 0 * * 1` |
| Last day of month | `0 0 L * *` (requires custom timetable) |

---

# 12.3 Preset Schedules (Airflow Built-ins)
Airflow includes easy presets:
- `@hourly`
- `@daily`
- `@weekly`
- `@monthly`
- `@yearly`
- `@once`

### When to avoid presets
Avoid when:
- You need business-day-only schedules
- You need offset schedules (e.g., run at 23:55)

---

# 12.4 data_interval_start & data_interval_end (Airflow 2.4+)
Each DAG run has a **data interval** representing the time window it processes.

For daily DAG:
```
interval: 2024-01-01 → 2024-01-02
logical date = start of interval
```

Use inside tasks:
```python
print(context['data_interval_start'])
```

---

# 12.5 Custom Timetables (Airflow 2.4+)
Timetables replace `schedule_interval` for advanced scheduling.

### Example: Run every 45 minutes
```python
from airflow.timetables.interval import CronDataIntervalTimetable

dag = DAG(
    dag_id="custom_schedule",
    timetable=CronDataIntervalTimetable("*/45 * * * *", timezone="UTC"),
)
```

---

# 12.6 Creating Your Own Timetable
For complex business rules such as:
- Last business day of month
- Every 6 hours except weekends
- First Monday of quarter

### Example skeleton
```python
from airflow.timetables.base import Timetable

class MyCustomTimetable(Timetable):
    def infer_manual_data_interval(self, run_after):
        ...
```

Register using:
```
AIRFLOW__CORE__TIMETABLE_PLUGINS = mypackage.MyCustomTimetable
```

---

# 12.7 catchup & max_active_runs — Advanced Concepts
### catchup=True
Runs all historical intervals.

### catchup=False
Runs only upcoming intervals.

### max_active_runs
Control concurrency:
```python
max_active_runs=1
```

Useful for stateful pipelines (e.g., SCD loads).

---

# 12.8 Complex Enterprise Schedules
## 1. Business-Day Only
Use `pendulum` library:
```python
schedule_interval="0 3 * * 1-5"
```

## 2. Run every 2 hours between 6 AM and 6 PM
```python
schedule_interval="0 6-18/2 * * *"
```

## 3. Quarterly schedule
No built-in cron; use custom timetable.

---

# 12.9 Event-Based Scheduling (Triggers)
Not all workflows run on time-based schedules.

Airflow supports:
### • TriggerDagRunOperator
### • ExternalTaskSensor
### • Dataset-based scheduling (Airflow 2.6+)

---

# 12.10 Dataset Scheduling (Airflow 2.6+)
DAGs can trigger based on **data updates**, not time.

### Example:
```python
from airflow import Dataset

dataset = Dataset("s3://bucket/table")

@dag(schedule=[dataset])
def consumer():
    ...
```

---

# 12.11 Timezone Handling
Always set timezone explicitly:
```python
timezone="UTC"
```

Avoid using system local time.

---

# 12.12 Backfilling Complex Pipelines
Manual backfills:
```bash
airflow dags backfill -s 2024-01-01 -e 2024-01-10 dag_id
```

### Best Practices
- Ensure idempotency
- Disable downstream trigger rules temporarily
- Use pools to avoid overload

---

# 12.13 When NOT to Use Scheduling
Use manual triggering for:
- One-off jobs
- Migrations & bootstrap loads
- ML retraining not tied to time

---

# 12.14 Summary
In this chapter, you learned:
- Cron scheduling deeply
- Airflow logical dates & data intervals
- Custom timetables for complex scheduling
- Dataset-based triggers
- Backfill and catchup considerations
- Timezone and enterprise-grade scheduling patterns
---

