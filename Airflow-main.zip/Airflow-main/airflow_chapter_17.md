# Chapter 17: Airflow CI/CD, GitOps & Modern Deployment Workflows

Modern data engineering teams adopt CI/CD and GitOps practices to ensure that Airflow deployments are reliable, scalable, version-controlled, and fully automated. In this chapter, we cover how to design CI/CD pipelines for Airflow, how GitOps works for DAG deployments, and best practices for enterprise workflows.

---
# 17.1 Why CI/CD for Airflow?
Airflow pipelines should be treated like **software**, not ad-hoc scripts.

CI/CD enables:
- Repeatable & automated deployments
- Version-controlled DAGs
- Code reviews & quality checks
- Automated testing (linting, unit tests)
- Environment parity (dev → stage → prod)
- Faster onboarding for teams

---
# 17.2 What Should Be in Git?
Your Git repo should include:
- `dags/` folder (DAG code)
- `plugins/` folder
- `requirements.txt` or `setup.py`
- `Dockerfile` (optional for custom images)
- `tests/` folder
- CI/CD configuration (GitHub Actions, GitLab, Jenkins, etc.)

Not included:
- Secrets
- Logs
- Temp files

---
# 17.3 The Three-Layer Airflow Git Repository Structure
```
/airflow-project
  ├── dags/
  ├── plugins/
  ├── tests/
  ├── Dockerfile
  ├── requirements.txt
  ├── airflow_settings.yaml (optional)
  └── .github/workflows/ci.yml
```

---
# 17.4 CI Pipeline Stages
A typical CI pipeline includes:

## 1. Code Quality
- `flake8`
- `black` formatting
- `pylint`
- `isort`

## 2. DAG Validation
```bash
airflow dags list
```
Detects:
- Parse errors
- Import errors
- Syntax issues

## 3. Unit Tests (Optional)
Use pytest for:
- Task logic
- Python functions used inside tasks

## 4. Static DAG Checks
- DAG naming conventions
- No global variables
- No heavy imports outside tasks

---
# 17.5 CD Pipeline Stages
### Deployment depends on where Airflow is hosted:
- **MWAA** → sync DAGs to S3
- **Cloud Composer** → sync DAGs to GCS
- **Astronomer** → `astro deploy`
- **Self-hosted** → CI pushes files to NFS/S3 bucket or container registry

---
# 17.6 CI/CD with GitHub Actions (Example)
## `.github/workflows/airflow-ci.yml`
```yaml
name: Airflow CI

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v3

      - name: Install dependencies
        run: |
          pip install apache-airflow==2.9.0
          pip install -r requirements.txt

      - name: Lint
        run: |
          flake8 dags plugins

      - name: Validate DAGs
        run: |
          airflow dags list
```

---
# 17.7 Deploying to AWS MWAA via CI/CD
### 1. Sync DAGs to S3
```bash
aws s3 sync dags/ s3://mwaa-env/dags/
```

### 2. Sync Plugins
```bash
aws s3 sync plugins/ s3://mwaa-env/plugins/
```

### Best Practices:
✔ Use CI/CD to bundle dependencies  
✔ Use versioned S3 paths for rollback

---
# 17.8 Deploying to Google Cloud Composer via CI/CD
### Sync DAGs to GCS
```bash
gsutil rsync -r dags/ gs://composer-bucket/dags
```

### Deploy Requirements
```bash
gsutil cp requirements.txt gs://composer-bucket/plugins/
```

### Best Practices:
✔ Test DAGs in dev Composer first  
✔ Use Workspaces for environment separation

---
# 17.9 Deploying with Astronomer
Astronomer provides the simplest CI/CD.

### Deploy:
```bash
astro deploy
```

Runs:
- Build image  
- Push to registry  
- Deploy Airflow instance  

---
# 17.10 GitOps for Airflow
GitOps = **Airflow is deployed from Git, not manually.**

### GitOps Workflow
1. Developer creates a branch  
2. Writes DAG code  
3. Opens Pull Request  
4. CI tests DAGs  
5. Reviewer approves  
6. Merge triggers deployment automatically  

---
# 17.11 Multi-Environment Deployment (dev → stage → prod)
### CI/CD Pipeline Example:
1. `dev` branch → deploy to dev Airflow  
2. Pull Request from dev → stage  
3. Stage deployment for testing  
4. Approved PR → merge to main  
5. Automatic deployment to prod  

---
# 17.12 Dependency Management
Use one of:
- `requirements.txt`
- `setup.py`
- `poetry.lock`

Install dependencies automatically:
```bash
pip install -r requirements.txt
```

### Best Practices
- Pin versions  
- Avoid heavy libraries in DAG code  
- Use virtual environments or Docker  

---
# 17.13 Automated Testing for Airflow
### 3 Types of Tests
## 1. Unit Tests
Test code **inside** operators.

## 2. DAG Parse Tests
Detect DAG errors.
```bash
airflow dags list
```

## 3. End-to-End Tests (Optional)
Run DAGs in ephemeral environments.

---
# 17.14 Detecting Breaking Changes Early
Use:
- `airflow dags list` for parse checks  
- `pytest` for logic  
- `pre-commit` hooks for formatting

---
# 17.15 Rollback Strategies
### MWAA / Composer
- Use versioned S3/GCS folders
- Promote previous version if needed

### Astronomer
- Rollback to previous image

### Self-hosted
- Re-deploy previous Git commit

---
# 17.16 Best Practices for Airflow CI/CD
✔ Treat Airflow DAGs as production-grade software  
✔ Use GitOps for consistent deployments  
✔ Validate DAGs in CI  
✔ Deploy automatically after merge  
✔ Maintain dev → stage → prod separation  
✔ Store dependencies in versioned files  
✔ Use Docker for deterministic environments  

---
# 17.17 Summary
In this chapter, you learned:
- CI/CD pipelines for Airflow
- GitOps best practices
- How to deploy to MWAA, Composer, and Astronomer
- DAG validation, linting, automated testing
- Rollbacks, multi-environment deployment
- Dependency & repo organization

---
