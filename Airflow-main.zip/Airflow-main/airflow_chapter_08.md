# Chapter 8: Variables, Connections, Secrets & Configuration Management in Apache Airflow

Managing configurations, credentials, and environment-specific settings is a critical part of building secure and scalable pipelines in Apache Airflow. This chapter explains **Variables**, **Connections**, **Secret Backends**, and **config settings**, giving you full mastery of Airflow configuration management.

---

# 8.1 Introduction to Airflow Configuration Management
Apache Airflow separates **pipeline logic** (DAGs) from **external configuration** (credentials & settings). This ensures:
- Security
- Environment portability
- Cleaner code
- Easier CI/CD deployment

Airflow provides four main mechanisms:
1. **Variables**
2. **Connections**
3. **Secrets Backends**
4. **airflow.cfg & environment variables**

---

# 8.2 Airflow Variables
Variables store **key-value pairs** used in DAGs.

Use cases:
- Toggle features on/off
- Store static configuration values
- Store environment flags
- store file paths, dataset names, environment modes

### Setting Variables
### Using UI:
**Admin → Variables → Create**

### Using CLI:
```bash
airflow variables set my_key "my_value"
```

### Using code:
```python
from airflow.models import Variable
value = Variable.get("my_key")
```

### Using default values:
```python
value = Variable.get("my_key", default_var="fallback")
```

### DO NOT use Variables for:
❌ Secrets or passwords  
❌ Access tokens  
❌ API keys

Use **Connections or Secret Backends** instead.

---

# 8.3 Airflow Connections (Most Important for Credentials)
Connections store credentials for:
- Databases (Postgres, MySQL, Snowflake)
- Cloud services (AWS, GCP, Azure)
- APIs
- SSH
- SFTP
- FTP
- Data warehouses

### Creating a Connection
### Using UI:
**Admin → Connections → +**

### Using CLI:
```bash
airflow connections add 'my_postgres' \
    --conn-uri 'postgresql://user:pass@host:5432/database'
```

### Using code:
```python
from airflow.hooks.base import BaseHook
conn = BaseHook.get_connection("my_postgres")
username = conn.login
password = conn.password
```

---

# 8.4 Types of Connections
Airflow supports dozens of providers:
- **AWS** → `aws_conn_id`
- **GCP** → `google_cloud_default`
- **Azure** → `azure_default`
- **Snowflake** → `snowflake_default`
- **BigQuery** → `bigquery_default`
- **MySQL / Postgres / MSSQL** → standard DB connections
- **HTTP** → APIs
- **SFTP / SSH** → file systems

This makes Airflow extremely flexible.

---

# 8.5 Secret Backends — Secure Credential Storage
Sensitive information should **never** be stored in Variables or connection fields.

Airflow integrates with secret backends:
- **HashiCorp Vault**
- **AWS Secrets Manager**
- **GCP Secret Manager**
- **Azure Key Vault**
- **SOPS**
- **Kubernetes Secrets**

### Example: enabling AWS Secrets Manager
In `airflow.cfg` or env vars:
```
AIRFLOW__SECRETS__BACKENDS=airflow.providers.amazon.aws.secrets.secrets_manager.SecretsManagerBackend
AIRFLOW__SECRETS__SECRET_MANAGER__CONNECTION_PREFIX=airflow-connections
AIRFLOW__SECRETS__SECRET_MANAGER__VARIABLE_PREFIX=airflow-variables
```

### Benefits of Secret Backends
✔ Rotation without redeploying Airflow  
✔ More secure than Airflow UI storage  
✔ Centralized credentials management  
✔ Auditing and access control

---

# 8.6 Environment Variables in Airflow
Airflow reads configuration values from environment variables following this format:
```
AIRFLOW__{SECTION}__{KEY}
```

### Example: set executor to LocalExecutor
```bash
export AIRFLOW__CORE__EXECUTOR=LocalExecutor
```

### Example: enable debug logging
```bash
export AIRFLOW__LOGGING__LOGGING_LEVEL=DEBUG
```

This is heavily used in Docker/Kubernetes deployments.

---

# 8.7 airflow.cfg — Main Airflow Configuration File
Located at:
```
~/airflow/airflow.cfg
```

Important sections:
- `[core]` → executor, DAG folder, parallelism
- `[logging]` → log format, remote log storage
- `[webserver]` → UI settings
- `[secrets]` → secret backend configuration
- `[email]` → alert settings

Example settings:
```
load_examples = False
parallelism = 32
max_active_runs_per_dag = 1
```

Most enterprise environments **override airflow.cfg with environment variables**.

---

# 8.8 How Airflow Finds Configuration Values
Order of priority:
```
Environment Variables > airflow.cfg > Defaults
```

This ensures easy environment overrides.

---

# 8.9 Best Practices for Variables, Connections & Secrets
### Variables:
✔ Use for non-sensitive configs  
✔ Use default values for resilience  
❌ Never store passwords or API keys

### Connections:
✔ Use for all external system credentials  
✔ Give meaningful connection IDs: `aws_raw_zone`  
✔ Use hooks to simplify code

### Secrets Backend:
✔ Mandatory for production  
✔ Use AWS/GCP Vault for sensitive secrets  
✔ Rotate secrets without DAG updates

### airflow.cfg:
✔ Keep minimal and environment-agnostic  
✔ Override with environment variables in CI/CD

---

# 8.10 Example: Secure AWS S3 Access in a DAG
```python
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook


def list_s3_files():
    hook = S3Hook(aws_conn_id="aws_default")
    keys = hook.list_keys(bucket_name="raw-data")
    print(keys)

list_files = PythonOperator(
    task_id="list_files",
    python_callable=list_s3_files,
)
```

---

# 8.11 Summary
In this chapter, you learned:
- How Airflow Variables, Connections & Secret Backends work
- How to configure Airflow securely using env vars
- How to integrate AWS/GCP/Azure secrets
- How airflow.cfg interacts with other config systems
- Best practices for enterprise-grade Airflow configuration

---

