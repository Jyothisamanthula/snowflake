# Chapter 33: Airflow at Scale — Running 10,000+ Tasks per Day

Scaling Apache Airflow to support thousands of tasks per day—and hundreds of concurrent workflows—requires thoughtful architecture, clean DAG design, optimized scheduling, and strong operational practices.

This chapter provides a **complete blueprint** for scaling Airflow to enterprise-scale workloads, including patterns, anti-patterns, performance tuning, cluster sizing, and high-availability strategies.

---
# 33.1 What Does “Scale” Mean in Airflow?
Airflow at scale involves:
- 10,000–500,000+ tasks per day
- 300–2,000+ DAGs
- 50–500+ concurrent DAG runs
- Multi-region HA
- Large worker clusters (Celery/K8s)
- High DAG parse frequency

Scale stresses:
- Scheduler CPU
- Metadata DB throughput
- Worker autoscaling
- DAG parse time
- Log storage volume

---
# 33.2 Pillars of Scaling Airflow
Airflow scales along five dimensions:
1. **Scheduler Performance**  
2. **Metadata Database Throughput**  
3. **Worker Scaling**  
4. **DAG Design & Lightweight Parsing**  
5. **Logging & Storage Management**  

---
# 33.3 Scaling the Scheduler
### The scheduler is the brain of Airflow.
To scale:  
✔ Run **multiple schedulers** (Airflow 2.x native HA)  
✔ Increase scheduler concurrency:  
```ini
[scheduler]
max_tis_per_query = 256
min_file_process_interval = 0
```
✔ Use powerful nodes (4–8 CPU minimum)  
✔ Use lazy-loading for large DAG factories  
✔ Keep DAG parsing time < 0.5s

---
# 33.4 Metadata Database Scaling
Airflow DB must support:
- Thousands of reads/writes per second
- Fast DAG parsing
- Burst traffic during scheduler cycles

### Best Practices
✔ Use **PostgreSQL** or CloudSQL/RDS (avoid MySQL for large-scale)  
✔ Use high IOPS storage (SSD)  
✔ Enable connection pooling (PgBouncer)  
✔ Prune metadata regularly:  
```bash
airflow db prune
airflow db cleanup
```
✔ Partition task_instance table if needed (advanced)

---
# 33.5 Scaling Workers (Celery / Kubernetes / Astronomer)
### CeleryExecutor
✔ Use autoscaling workers  
✔ Separate queues for heavy/light tasks  
✔ Run Redis/RabbitMQ in HA mode  

### KubernetesExecutor
✔ Enable Horizontal Pod Autoscaling (HPA)  
✔ Use multiple node pools (CPU/GPU/Highmem)  
✔ Use spot/preemptible nodes for batch workloads  

### Astronomer Hybrid Executor
✔ Use Celery for small tasks, K8s for heavy tasks  

---
# 33.6 DAG Design Principles for Scale
To scale DAGs:
### 1. Keep DAGs **lightweight**
No heavy logic at parse time.

### 2. Break large DAGs into domains
Avoid DAGs with 500+ tasks.

### 3. Use TaskGroups, not giant monolithic flows
Better organization → faster parsing.

### 4. Avoid XCom-heavy logic
Store large data externally.

### 5. Use dynamic task mapping carefully
Avoid generating 1000s of tasks in a single DAG unless needed.

### 6. Set proper limits
```python
max_active_runs = 1
max_active_tasks = 50
```

---
# 33.7 Scaling Using Metadata-Driven DAG Factories
Factories generate hundreds of DAGs automatically.

Best Practices:  
✔ Cache metadata  
✔ Use lazy evaluation  
✔ Validate metadata before DAG generation  
✔ Split factories by domain  
✔ Avoid generating > 300 DAGs per file  

---
# 33.8 Log Storage Strategy for Large Workloads
Large Airflow setups consume huge log storage.

### Best Practices
✔ Compress logs (GZIP)  
✔ Lifecycle policy: delete or archive after 90–180 days  
✔ Send metadata logs to Datadog/ELK  
✔ Avoid excessive print statements in tasks  

---
# 33.9 Optimizing Sensors for Scale
Sensors can overwhelm worker slots.

### Instead of sensors, use:
✔ Datasets (Airflow 2.5+)  
✔ External APIs with callbacks  
✔ Event-driven triggers  
✔ Short-circuit operators  

If sensors must be used:
- Use `mode="reschedule"`
- Increase poke interval

---
# 33.10 Improving Task Execution Throughput
### How to increase total tasks processed per minute:
✔ Increase parallelism  
✔ Increase worker pods/nodes  
✔ Use faster executors (K8s > Celery > Local)  
✔ Reduce task duration  
✔ Use short-lived tasks  
✔ Use efficient retries (avoid retry storms)

---
# 33.11 Dealing with Backfill Storms
Backfill storms overwhelm scheduler & workers.

### Solutions
✔ Disable catchup for most DAGs:  
```python
catchup=False
```
✔ Limit backfill concurrency:  
```bash
airflow dags backfill --max_active_runs 1
```
✔ Use partition-based reprocessing instead of full backfills

---
# 33.12 Distributed Caching for Scale
Avoid repeated metadata pulls.

Use caching layers:
- Redis  
- Memcached  
- Local cache per scheduler

---
# 33.13 Observability at Scale
Track:
- Scheduler queue backlog  
- Worker pod usage  
- DB CPU/IO  
- Task duration over time  
- SLA violations  
- Failed task trends

Use:
- Prometheus exporters  
- Datadog integration  
- Grafana dashboards  

---
# 33.14 Scaling Airflow on Cloud Platforms
### MWAA
✔ Choose larger environment tier  
✔ Limit DAG size & complexity  
✔ Use batch writes instead of large XComs  

### Cloud Composer
✔ Use multiple node pools  
✔ Tune scheduler CPU  
✔ Upgrade Airflow regularly

### Astronomer
✔ Use Deployment-level resources  
✔ Autoscale workers  
✔ Tune scheduler replicas

---
# 33.15 High Availability (HA) Patterns
Large Airflow setups require HA.

### Scheduler HA
Run multiple schedulers.

### Worker HA
Use multiple node pools and autoscaling.

### Database HA
Use:
- CloudSQL HA  
- RDS Multi-AZ  
- PostgreSQL replication

---
# 33.16 Advanced Architecture for 10,000–100,000+ Tasks
```
                 +------------------+
                 |  LB / Ingress     |
                 +---------+--------+
                           |
               +-----------+-----------+
               |   Airflow Webserver   |
               +-----------+-----------+
                           |
               +-----------+-----------+
               |  Multi-Scheduler HA   |
               +-----------+-----------+
                           |
               +-----------+-----------+
               | Metadata DB (HA / RDS)|
               +-----------+-----------+
                           |
           +---------------+---------------+
           |               |               |
    Worker Pool A    Worker Pool B   Worker Pool C
      (small)          (medium)          (GPU/ML)
```

---
# 33.17 Airflow Scale Anti-Patterns
### ❌ Giant DAG files (1000+ tasks)
### ❌ Too many sensors in poke mode
### ❌ Storing large payloads in XComs
### ❌ API calls at DAG parse time
### ❌ Workers without autoscaling
### ❌ Single scheduler setup
### ❌ Running ETL inside Airflow tasks

---
# 33.18 Best Practices Summary
✔ Use multiple schedulers  
✔ Use Celery/K8s executor with autoscaling  
✔ Keep DAGs small, modular & fast to parse  
✔ Use data-driven dynamic tasks  
✔ Use Datasets over sensors  
✔ Optimize metadata DB & logs  
✔ Split workloads across worker queues  
✔ Limit backfills & use partition-based processing  

---
# 33.19 Summary
In this chapter, you learned:
- How to design and operate Airflow at large scale
- Scaling patterns for scheduler, workers, metadata DB, and logs
- How to optimize DAG design for massive workloads
- Anti-patterns to avoid and best practices for stable operations

---