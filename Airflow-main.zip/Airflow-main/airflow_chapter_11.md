# Chapter 11: XComs, Data Passing & Task Communication in Apache Airflow

In Airflow, tasks are meant to be **loosely coupled**, but sometimes they need to exchange metadata or small pieces of information. XComs (Cross-Communication objects) make this possible. This chapter explains how XComs work, how to use them efficiently, and their best practices and caveats.

---

# 11.1 What Are XComs?
XCom = **Cross Communication**.

Tasks can:
- **push** small data
- **pull** data from other tasks

XComs live in the **Airflow Metadata DB**, not in memory.

### Typical uses:
- Passing small metadata (file paths, counts)
- Sharing API response IDs
- Passing table names, partition info
- Inter-task signaling

---

# 11.2 What XComs Should NOT Be Used For
❌ Do NOT pass large datasets (DataFrames, millions of rows).  
❌ Do NOT pass binary files.  
❌ Do NOT use XComs for data processing or data movement.

Use S3/GCS/DB for transferring large objects.

---

# 11.3 Pushing XComs
### Method 1 — Implicit return value
```python
def get_value():
    return "hello world"

PythonOperator(
    task_id="task1",
    python_callable=get_value
)
```
This automatically stores a XCom.

### Method 2 — Explicit push
```python
def push_value(**kwargs):
    kwargs['ti'].xcom_push(key='message', value='hello')
```

---

# 11.4 Pulling XComs
```python
def read_value(**kwargs):
    value = kwargs['ti'].xcom_pull(task_ids='task1', key='message')
    print(value)
```

If key is not specified, Airflow uses `'return_value'`.

---

# 11.5 XCom Backend (Airflow 2.3+)
Airflow allows you to customize where XComs are stored.

Examples:
- S3
- GCS
- Redis
- Custom DB

### Example config:
```
AIRFLOW__CORE__XCOM_BACKEND=custom.S3XComBackend
```

Useful for ML workloads and cloud pipelines.

---

# 11.6 XCom Types (Airflow 2.5+)
XComs now support custom serialization/deserialization.

Examples:
- Pandas DataFrames
- Python dicts
- JSON objects

### Registering Custom Types
```python
from airflow.models.xcom import BaseXCom

class MyCustomXCom(BaseXCom):
    @staticmethod
    def serialize_value(value):
        return json.dumps(value)
```

---

# 11.7 Using XComs with TaskFlow API
TaskFlow API makes XCom usage automatic.

### Example:
```python
from airflow.decorators import dag, task
from datetime import datetime

@dag(start_date=datetime(2024, 1, 1), schedule_interval="@daily")
def sample_flow():

    @task
    def extract():
        return {"count": 100}

    @task
    def transform(data):
        return data["count"] * 2

    @task
    def load(result):
        print(f"Final result: {result}")

    load(transform(extract()))

sample_flow()
```

TaskFlow API → XCom passing without specifying `xcom_push()` or `xcom_pull()`.

---

# 11.8 XCom Clear & Cleanup
Clean XComs from DB:
```bash
airflow tasks xcom_clear -t task1 -d 2024-01-01 my_dag
```

Automate cleanup using maintenance DAGs.

---

# 11.9 Best Practices for XCom Usage
### ✔ Do
- Use XComs for small metadata only
- Use TaskFlow API for clean inter-task communication
- Use JSON-serializable objects

### ❌ Don’t
- Pass large datasets
- Store secrets in XComs
- Use XComs for long-term storage

---

# 11.10 Real-World Examples
### Example 1 — Pass S3 file path
```python
@task
def pick_file():
    return "s3://bucket/data.csv"

@task
def consume(path):
    print(path)
```

### Example 2 — Pass row counts
```python
@task
def get_rowcount():
    return 12345
```

### Example 3 — Pass API Job ID
```python
@task
def start_job():
    return {"job_id": "abc123"}
```

---

# 11.11 Summary
In this chapter, you learned:
- How XComs work internally
- How to use push/pull methods
- Limitations and anti-patterns
- TaskFlow API for clean DAGs
- Real-world XCom examples
- XCom backend and custom types

---

