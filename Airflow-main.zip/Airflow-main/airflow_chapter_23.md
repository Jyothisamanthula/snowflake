# Chapter 23: Event‑Driven Workflows & Airflow Datasets

Traditional Airflow pipelines are mostly **time‑driven**, running on cron schedules like hourly or daily. But modern data platforms increasingly require **event‑driven orchestration**, where pipelines trigger based on *data arrival*, *file creation*, *API events*, *table updates*, or *completion of upstream systems*.

Airflow 2.4+ introduced the **Datasets** feature, transforming Airflow into a powerful event‑driven orchestrator.

This chapter dives into Datasets, event-based triggering, sensors, and hybrid orchestration patterns.

---
# 23.1 Why Event‑Driven Pipelines?
Time-based scheduling has limitations:
- Pipelines may run before data is ready
- Wasteful compute
- Harder to coordinate cross‑team workflows
- Delays propagate downstream  

Event-driven pipelines improve:  
✔ Freshness  
✔ Latency  
✔ Efficiency  
✔ Pipeline reliability  
✔ Cross-DAG coordination  

---
# 23.2 What Are Airflow Datasets?
A **Dataset** represents a *data asset* that one DAG produces and another DAG consumes.

Examples of datasets:
- A table in Snowflake or BigQuery
- A file in S3 or GCS
- A Delta/Parquet file in a data lake
- A dbt model

### Syntax
```python
from airflow import Dataset

sales_table = Dataset("bq://analytics.sales_table")
```

Datasets enable DAG‑to‑DAG orchestration without sensors.

---
# 23.3 Dataset‑Aware DAGs
### 1. Producing a Dataset
```python
@task

def update_sales():
    ...

update_sales() >> sales_table  # marks dataset updated
```

### 2. Consuming a Dataset
```python
@dag(schedule=[sales_table])
def downstream_pipeline():
    process()
```

When `update_sales` completes → downstream DAG is triggered.

---
# 23.4 Multiple Dataset Dependencies
A DAG can depend on multiple upstream datasets.

```python
@dag(schedule=[dataset_A, dataset_B, dataset_C])
def consumer_dag():
    run()
```

Runs only when **all datasets update**.

---
# 23.5 Mixed Event + Cron DAGs
A DAG can have both:
- A cron schedule
- Dataset triggers

```python
@dag(schedule=[Dataset("s3://files/daily.csv"), "0 6 * * *"])
def pipeline():
    run()
```

Useful when you want:
✔ A minimum freshness window  
✔ A fallback cron run if the event doesn’t fire

---
# 23.6 Using Sensors for Event‑Driven Flows
Before Datasets existed, event-driven flows used sensors.

Common sensors:
- S3KeySensor
- GCSObjectSensor
- FileSensor
- HttpSensor
- ExternalTaskSensor

### Example: S3 Key Sensor
```python
S3KeySensor(
    task_id="wait_for_file",
    bucket_name="raw-zone",
    bucket_key="{{ ds }}/file.csv",
    mode="reschedule",
)
```

Sensors are still useful when:
- External systems cannot publish Datasets
- You need fine‑grained conditions
- You need file pattern detection

---
# 23.7 Event‑Driven dbt Pipelines
In dbt 1.5+, you can emit a Dataset representing a dbt model.

Example:
```python
dbt_sales = Dataset("dbt://models/sales")
```

Let Airflow run downstream pipelines when dbt finishes.

---
# 23.8 Real‑World Event‑Driven Patterns
## Pattern 1 — Raw File → ETL → Marts
```
S3 File Upload → Raw DAG → Staging DAG → Mart DAG
```
Use Datasets or S3 sensors.

## Pattern 2 — API Refresh → ML Retraining
```
API ingestion DAG updates dataset → ML DAG triggered
```

## Pattern 3 — Data Warehouse Publish‑Subscribe
```
Snowflake table updated → downstream DAGs start
```

## Pattern 4 — Streaming + Batch Hybrid
Kafka event fires a DAG that processes micro‑batches.

---
# 23.9 Event‑Driven Best Practices
✔ Prefer Datasets over sensors for DAG‑to‑DAG orchestration  
✔ Use sensors for external systems only  
✔ Use `reschedule` mode for long‑waiting sensors  
✔ Track dataset lineage in the Airflow UI  
✔ Avoid giant event chains → break into micro‑DAG patterns  
✔ Capture metadata (partition, timestamp) using XComs  

---
# 23.10 Datasets UI & Lineage Graph
Airflow UI includes a **Dataset view**:
- Shows upstream DAGs
- Downstream consumers
- Update history
- Trigger patterns

This becomes a simple built‑in data lineage tool.

---
# 23.11 Combining Event‑Driven and Time‑Driven Logic
Many enterprises use *hybrid schedules*.

Example:
```
Execute when a file arrives  
OR  
Run anyway at midnight
```

This ensures consistency even if events fail.

---
# 23.12 Common Anti‑Patterns
### ❌ Anti‑Pattern: Overusing Sensors in Poke Mode
Consumes workers and slows pipelines.

### ❌ Anti‑Pattern: Storing dataset metadata manually
Let Airflow track datasets natively.

### ❌ Anti‑Pattern: Triggering dozens of DAGs directly
Use Datasets → automatic propagation.

### ❌ Anti‑Pattern: Hardcoding file paths & data intervals
Use `data_interval_start` / `end` instead.

---
# 23.13 Summary
In this chapter, you learned:
- How event‑driven pipelines work in Airflow
- How to define Datasets and dataset‑aware DAGs
- How to use both Datasets and sensors
- Real‑world event‑driven patterns
- Anti‑patterns and best practices

---

