# Chapter 19: Airflow Resilience, High Availability (HA) & Disaster Recovery (DR)

Running Apache Airflow at scale requires more than just building DAGs—it requires ensuring the platform is **highly available**, **fault-tolerant**, and **disaster-proof**. Enterprise teams rely on Airflow for mission‑critical jobs, so downtime can translate into failed SLAs, missed reports, and broken data pipelines.

This chapter focuses on how to architect, deploy, and maintain Airflow for HA and DR.

---
# 19.1 What Does High Availability Mean for Airflow?
High Availability (HA) ensures Airflow continues to run even when components fail.

Airflow’s key components:
- **Scheduler**
- **Webserver**
- **Workers (Celery/K8s/Local)**
- **Metadata Database**
- **Message Queue (Redis/RabbitMQ)**
- **Logs backend (S3/GCS/Azure)**

To achieve HA:
- No single point of failure
- Redundant instances of core components
- Ability to failover quickly

---
# 19.2 Airflow HA Architecture Overview
### HA Airflow includes:
- Multiple schedulers (Airflow 2.x)
- Multiple webserver replicas
- Horizontally scalable workers
- HA metadata database
- HA message broker
- Remote log storage

### Typical HA Deployment
```
Load Balancer
     ↓
 Multiple Webservers
     ↓
   Schedulers (HA)
     ↓
 Message Queue (Redis/RabbitMQ Cluster)
     ↓
  Worker Fleet (Celery/K8s)
     ↓
Metadata DB (RDS/CloudSQL w/ failover)
```

---
# 19.3 Airflow Scheduler HA
Airflow 2.x supports **multiple active schedulers**, providing:
- Built-in redundancy
- Better performance
- No downtime if one scheduler crashes

Enable HA schedulers in `airflow.cfg`:
```ini
scheduler_ha = True
num_runs = -1
```

Deploy 2–3 scheduler replicas for production.

---
# 19.4 Webserver HA
Webserver is stateless → horizontal scaling is easy.

HA Patterns:
- Multiple webservers behind a load balancer
- Health checks via `/health`

Kubernetes example:
```yaml
replicas: 3
```

---
# 19.5 Worker HA
Workers run tasks and must scale elastically.

### Celery Executor
- Deploy multiple Celery worker nodes
- Autoscale via Celery’s `--autoscale` flag

### Kubernetes Executor
- Each task runs in its own pod
- Kubernetes autoscaler handles HA

### Best Practice
✔ At least 2 worker groups for redundancy  
✔ Separate heavy workloads into dedicated queues

---
# 19.6 Message Queue HA (Redis/RabbitMQ)
The message broker is a **critical dependency**.

### Redis HA Options
- Redis Sentinel
- Redis Cluster
- AWS Elasticache Redis (multi-AZ)

### RabbitMQ HA Options
- Mirrored queues
- RabbitMQ Cluster
- CloudAMQP enterprise plans

Avoid single-node brokers in production.

---
# 19.7 Metadata Database HA
The metadata DB is the **most important component**.

### Use managed HA databases:
- Amazon RDS (Multi-AZ)
- Google CloudSQL (HA)
- Azure Database for Postgres (Zone redundant)

### Key DB Best Practices
✔ Automatic backups enabled  
✔ Read replicas for offloading queries  
✔ Encrypted at rest + SSL connections  
✔ Connection pooling (PgBouncer)  
✔ High IOPS storage (fast IO)  

---
# 19.8 Remote Logging for HA
Local logs are risky.

Use:
- AWS S3
- Google GCS
- Azure Blob Storage

Benefits:
✔ Logs preserved even if worker dies  
✔ Logs available for debugging  
✔ Storage is scalable and redundant

---
# 19.9 Airflow Self-Healing & Auto-Recovery
Airflow supports auto-recovery via:
- Task retries  
- Task-level timeouts  
- Zombie task detection  
- Orphan task cleanup  

Enable zombie detector:
```ini
scheduler_zombie_task_threshold = 300
```

---
# 19.10 Disaster Recovery Strategy (DR)
DR focuses on **restoring Airflow when the entire region or cluster fails**.

### Key Components of DR:
1. Metadata DB backups  
2. DAG folder backups  
3. Logs backups  
4. Environment configuration backups  
5. Reproducible infrastructure (IaC)

---
# 19.11 Multi-Region Airflow Architecture (Advanced)
For mission-critical use cases, deploy Airflow across multiple regions:

```
Primary Region Airflow ←→ Failover Region Airflow
Shared DAG storage + replicated DB
```

### DR Approaches
1. **Warm Standby** (recommended)  
2. Cold standby (slow)  
3. Active/active (complex)  

---
# 19.12 Backup & Restore
### Backup DAGs
- Store DAGs in Git + cloud buckets

### Backup Metadata DB
- Automatic snapshots  
- Point-in-time restore (PITR)

### Backup Logs
- Versioned S3/GCS bucket

### Restore Steps
1. Restore metadata DB snapshot  
2. Restore DAG folder  
3. Recreate Airflow environment  
4. Reconnect secrets backend  
5. Validate DAG state & resume tasks

---
# 19.13 Airflow Fault Tolerance Patterns
✔ Use retries with exponential backoff  
✔ Mark tasks with `retries=3` and `retry_delay=5m`  
✔ Use SLAs to detect late runs  
✔ Use Sensors in `reschedule` mode  
✔ Use pools to rate-limit failing APIs

---
# 19.14 Chaos Testing (Advanced)
Simulate failures to validate resiliency:
- Kill workers randomly  
- Terminate scheduler pod  
- Failover metadata DB  
- Drop network connectivity

### Tools:
- Chaos Mesh  
- AWS Fault Injection Simulator  
- Gremlin

---
# 19.15 Observability for HA & DR
To ensure availability, monitor:
- Scheduler heartbeat  
- Worker queue backlog  
- Task duration spikes  
- Metadata DB CPU/IO  
- Message queue health  
- DAG file parsing times

Tools:
- Prometheus  
- Grafana  
- Datadog  
- CloudWatch / Stackdriver

---
# 19.16 HA & DR Best Practices Checklist
✔ Multiple schedulers (Airflow 2.x HA)  
✔ Multiple webservers  
✔ HA workers (Celery/K8s)  
✔ Managed HA metadata DB  
✔ HA message broker  
✔ Remote logging enabled  
✔ DAGs stored in Git + cloud bucket  
✔ Secrets stored in Vault/Secret Manager  
✔ Automated DB backups  
✔ Multi-region DR plan  
✔ Autoscaling enabled  
✔ Regular chaos tests  

---
# 19.17 Summary
In this chapter, you learned:
- How to architect Airflow for resilience
- HA patterns for scheduler, webserver, workers & database
- How to build DR strategy with backups and multi-region failover
- Fault tolerance patterns and chaos testing
---

