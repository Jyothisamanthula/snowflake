# Chapter 16: Airflow in the Cloud — MWAA, Cloud Composer & Astronomer

Modern data engineering teams increasingly deploy Airflow in the cloud for scalability, reliability, and easier maintenance. Cloud platforms offer managed Airflow services that eliminate the need to manage underlying infrastructure.

This chapter covers:
- **AWS MWAA (Managed Workflows for Apache Airflow)**
- **Google Cloud Composer**
- **Astronomer (SaaS Airflow)**
- Comparing cloud Airflow vs self-hosted clusters
- Deployment, scaling, networking, and best practices

---
# 16.1 Why Use Managed Airflow?
Managed Airflow eliminates the heavy lifting of:
- Installing Airflow components
- Managing schedulers/workers
- Upgrading Airflow
- Scaling Celery/K8s clusters
- Handling database and logging infrastructure

### Benefits
✔ Highly available  
✔ Auto-scaling workers  
✔ Managed metadata database  
✔ Integrated logging & monitoring  
✔ Reduced DevOps overhead  

---
# 16.2 AWS MWAA (Managed Workflows for Apache Airflow)
MWAA is Amazon’s managed Airflow service.

### Key Features
- IAM-based authentication
- S3 storage for DAGs & plugins
- CloudWatch logging
- VPC networking
- Auto-scaling workers

### Architecture
```
S3 bucket → MWAA environment → Workers → CloudWatch logs → RDS metadata DB
```

### Deploying DAGs
Upload DAGs to:
```
s3://<env-name>/dags/
```

### Pros
✔ Deep integration with AWS services  
✔ Fully managed scaling  
✔ Secure IAM-based access  

### Cons
❌ No custom Airflow Docker image  
❌ Delayed Airflow version releases by AWS  

---
# 16.3 Google Cloud Composer (GCP)
Composer is GCP’s managed Airflow, tightly integrated with:
- BigQuery
- GCS
- Dataflow
- Cloud Logging
- VPC service controls

### Architecture
```
GKE cluster → Airflow scheduler/workers → GCS bucket → CloudSQL metadata DB
```

### Key Features
- Airflow runs inside Kubernetes
- Seamless BigQuery operator support
- Stackdriver logging
- Private IP support

### Pros
✔ Strong BigQuery ecosystem integration  
✔ Kubernetes-native implementation  

### Cons
❌ Can be costly for large clusters  
❌ Composer 1.x had stability issues (Composer 2.x improved)  

---
# 16.4 Astronomer (Astronomer Cloud)
Astronomer provides **enterprise-grade Airflow as SaaS**.

### Features
- Push-button Airflow deployments
- Custom Docker image support
- Automated Airflow upgrades
- Built-in observability dashboards
- Multi-tenant & team management

### Deployment
Astronomer CLI:
```bash
astro deploy
```

### Pros
✔ Fastest-to-market Airflow solution  
✔ Fully customizable image  
✔ Excellent monitoring & support  

### Cons
❌ Higher cost than self-hosted  

---
# 16.5 Comparing Cloud Providers
| Feature | MWAA | Cloud Composer | Astronomer |
|---------|------|----------------|------------|
| Infra Management | AWS | GKE | Astronomer Cloud |
| Custom Images | ❌ | ✔ | ✔ |
| Ecosystem | AWS | GCP | Multi-cloud |
| Autoscaling | ✔ | ✔ | ✔ |
| Monitoring | CloudWatch | Stackdriver | Built-in + Grafana |
| Cost | Medium | High | Medium–High |

---
# 16.6 Selecting the Right Cloud Airflow
### Choose MWAA if:
- You are AWS-heavy
- You use S3, Redshift, Glue, EMR
- You want lowest overhead

### Choose Cloud Composer if:
- You are BigQuery-first
- You use GKE and Dataflow

### Choose Astronomer if:
- You want the most flexible enterprise Airflow setup
- You want plug-and-play deployment
- You use multi-cloud environments

---
# 16.7 Hybrid & Multi-Cloud Airflow
Some enterprises run Airflow:
- Part in AWS (data lake)  
- Part in GCP (analytics pipelines)  
- Part in on-prem clusters  

### Best Practices
✔ Use event-driven design  
✔ Use Airflow Datasets  
✔ Sync DAGs via GitOps  
✔ Use OIDC for identity federation  

---
# 16.8 Deploying DAGs in Clouds
### MWAA
- S3 bucket sync
### Composer
- GCS bucket sync
### Astronomer
- CLI deployment via registry

---
# 16.9 Logging in Cloud Environments
### MWAA → CloudWatch
### Composer → Stackdriver
### Astronomer → Elastic/Grafana

Centralized logs make debugging easier.

---
# 16.10 Airflow Versions in Managed Services
Providers may lag behind the latest Airflow release.

### Example:
- Airflow 2.7 released → MWAA updates months later

### Recommendation
Ensure DAGs use **version-stable features**.

---
# 16.11 Networking Considerations
Cloud Airflow often runs inside VPCs.

Important considerations:
- Private subnets
- NAT gateways
- VPC peering
- Firewall rules
- Service accounts / IAM roles

Ensure workers can reach:
- S3/GCS
- Metadata DB
- APIs accessed by operators

---
# 16.12 Scaling in Cloud Airflow
- MWAA auto-scales worker fleets
- Composer auto-scales GKE nodes
- Astronomer auto-scales deployments

Set limits:
- `parallelism`
- `dag_concurrency`
- `worker_concurrency`

---
# 16.13 Cost Optimization
### MWAA
- Use minimal worker nodes
- Compress DAGs/plugins

### Composer
- Use Composer 2.x (optimized cost)
- Limit scheduling frequency

### Astronomer
- Deploy lightweight & heavy Airflow instances as needed

---
# 16.14 Cloud Security
### Use IAM/GCP/Azure Roles
- Avoid embedding credentials in DAGs

### Secrets
Use:
- AWS Secrets Manager
- GCP Secret Manager
- Astronomer’s Secret Backend

### Encryption
- Use KMS for DAG buckets

---
# 16.15 Summary
In this chapter, you learned:
- Differences between MWAA, Composer, and Astronomer
- Deployment patterns
- Scaling and networking considerations
- Logging, security, and cost best practices
- How to choose the right Airflow cloud platform

---

