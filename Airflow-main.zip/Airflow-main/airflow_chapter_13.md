# Chapter 13: TaskFlow API & Modern Airflow DAG Development

The **TaskFlow API** is one of the most important innovations introduced in Apache Airflow 2.x. It enables writing cleaner, function-based DAGs while reducing boilerplate, improving readability, and managing XComs automatically.

This chapter covers the TaskFlow API in-depth—from beginner concepts to advanced real-world patterns.

---
# 13.1 What Is the TaskFlow API?
TaskFlow API allows you to define Airflow tasks as **Python functions** using decorators.

### Classic approach vs TaskFlow API
| Classic Operators | TaskFlow API |
|------------------|--------------|
| More boilerplate | Clean & minimal code |
| Manual XCom usage | Automatic XCom passing |
| Operators for everything | Functions become tasks |

---
# 13.2 Writing Your First TaskFlow DAG
### Example:
```python
from airflow.decorators import dag, task
from datetime import datetime

@dag(schedule_interval="@daily", start_date=datetime(2024, 1, 1))
def example_taskflow():

    @task\    def extract():
        return {"id": 1, "value": 100}

    @task
    def transform(data):
        return data["value"] * 10

    @task
    def load(result):
        print(f"Loaded: {result}")

    load(transform(extract()))

example_taskflow()
```

### What TaskFlow provides:
- Automatic XCom serialization
- Type hints support
- Clear dependency structure

---
# 13.3 Passing Data Between Tasks (No XCom Code Needed)
All function returns automatically become XComs.

```python
@task
def add_numbers():
    return 5

@task
def multiply(x):
    return x * 10

multiply(add_numbers())
```

---
# 13.4 TaskFlow API and Type Hints
Airflow automatically serializes common Python types.

```python
@task
def process(data: dict) -> int:
    return data["count"] * 2
```

Improves readability and static analysis.

---
# 13.5 Using Task Groups with TaskFlow API
```python
from airflow.utils.task_group import TaskGroup

@dag

def grouped_flow():

    @task\    def start(): pass

    with TaskGroup("group1"):
        @task
        def step1(): pass

        @task
        def step2(): pass

    start() >> step1() >> step2()
```

---
# 13.6 TaskFlow API + Traditional Operators
You can mix both.

```python
@task
def get_file():
    return "file.csv"

load = BashOperator(
    task_id="load_data",
    bash_command="echo processing {{ ti.xcom_pull(task_ids='get_file') }}"
)

g = get_file() >> load
```

---
# 13.7 Branching with TaskFlow API
```python
from airflow.decorators import task, dag
from airflow.operators.empty import EmptyOperator

@dag

def branching_example():

    @task.branch
    def choose_path():
        return "task_b"

    a = EmptyOperator(task_id="task_a")
    b = EmptyOperator(task_id="task_b")

    choose_path() >> [a, b]

branching_example()
```

---
# 13.8 Error Handling with TaskFlow API
Use try/except inside tasks:
```python
@task
def safe_task():
    try:
        risky_operation()
    except Exception as e:
        raise AirflowException(f"Error: {e}")
```

---
# 13.9 Reusable TaskFlow Components (TaskFlow as Templates)
Reusable Python functions:
```python
from airflow.decorators import task

def extract_template():
    @task
    def extract():
        ...
    return extract
```

Useful for shared logic across DAGs.

---
# 13.10 Cross-DAG TaskFlow Communication
Use XCom + `TriggerDagRunOperator`.

```python
trigger = TriggerDagRunOperator(
    task_id="trigger_downstream",
    trigger_dag_id="dag_b"
)
```

---
# 13.11 Real-World TaskFlow Examples
### Example 1 — API to S3
```python
@task
def extract():
    return requests.get(URL).json()

@task
def transform(data):
    data["ts"] = dt.now()
    return data

@task
def load(data):
    s3.put_object(Body=json.dumps(data))
```

### Example 2 — ML Pipeline
```python
@task
def preprocess(df): ...
@task
def train(data): ...
@task
def evaluate(model): ...
```

---
# 13.12 TaskFlow API Best Practices
✔ Use TaskFlow for Python-heavy DAGs  
✔ Prefer type hints  
✔ Keep functions small and focused  
✔ Use Task Groups for modular DAGs  
✔ Avoid returning large objects (use S3/DB instead)  
❌ Do not use TaskFlow API for pure SQL pipelines (use SQL operators instead)

---

# 13.13 Summary
In this chapter, you learned:
- How TaskFlow API simplifies DAG creation
- Automatic XCom management
- Type hints & modular task design
- TaskFlow + Operator hybrid patterns
- Real-world DAG examples

---

