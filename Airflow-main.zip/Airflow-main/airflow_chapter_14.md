# Chapter 14: Parallelism, Concurrency, Executors & Scaling Apache Airflow

Scaling Airflow from a single-node setup to an enterprise-grade distributed environment requires a deep understanding of **parallelism**, **concurrency**, **executors**, **pools**, and **worker architecture**. This chapter explains all scaling concepts in a clear, practical, and production-oriented way.

---
# 14.1 Why Scaling Matters in Airflow
As DAGs grow and pipelines become more complex, Airflow must handle:
- High volume of tasks
- Parallel workloads
- Multi-tenant environments
- Large DAG files
- Distributed workers
- Cloud execution patterns

Proper scaling avoids:
- Scheduler bottlenecks
- Long queue times
- Worker overload
- Missed SLAs

---
# 14.2 Key Airflow Scaling Concepts
Airflow uses the following settings to control scale:
- **parallelism**
- **dag_concurrency**
- **max_active_runs**
- **task_concurrency**
- **pools**

We examine all of these next.

---
# 14.3 parallelism (Global Limit)
Controls how many tasks **across the entire Airflow environment** can run at once.

Defined in `airflow.cfg`:
```ini
parallelism = 32
```

Example:
- If `parallelism=32`, Airflow will never run more than 32 tasks simultaneously, even if you have 500 waiting.

---
# 14.4 dag_concurrency (Per-DAG Limit)
Controls how many tasks from **one DAG** can run in parallel.

```ini
dag_concurrency = 16
```

If a DAG has 100 parallel tasks, only the first 16 will run immediately.

---
# 14.5 max_active_runs (Per-DAG Run Limit)
Controls how many *DAG runs* can execute at the same time.

```python
max_active_runs=1
```

Useful for stateful DAGs like:
- Incremental loads
- Daily ingestion jobs

---
# 14.6 task_concurrency (Per-Task Limit)
Defines how many instances of a single task can run simultaneously.

```python
task_concurrency=3
```

Useful when:
- API rate limits exist
- Upstream systems have capacity limits

---
# 14.7 Pools — Limiting Shared Resources
Pools prevent oversaturation of limited resources.

Examples:
- API pool (limit calls)
- Warehouse pool (limit Snowflake/BigQuery queries)
- SFTP pool (limit SFTP connections)

### Create a pool:
```bash
airflow pools set api_pool 5 "Limit API calls"
```

### Use a pool:
```python
PythonOperator(..., pool="api_pool")
```

---
# 14.8 Executors — The Engine of Scaling
Airflow supports multiple executors.

---
## 14.8.1 SequentialExecutor
- Runs one task at a time
- Development only

---
## 14.8.2 LocalExecutor
- Runs tasks in parallel on a **single machine**
- Great for small/mid-size workloads

Configuration:
```ini
executor = LocalExecutor
```

---
## 14.8.3 CeleryExecutor
- Fully distributed execution
- Multiple workers across machines
- Requires message queue (Redis/RabbitMQ)

Architecture:
```
Scheduler → Queue → Workers → Tasks
```

Benefits:
- Autoscaling
- High throughput
- Resilient worker architecture

---
## 14.8.4 KubernetesExecutor (Production-Grade)
Creates **one Kubernetes pod per task**.

Benefits:
- Perfect isolation
- Auto-scaling
- Resource-based scheduling
- Supports GPU workloads (ML pipelines)

Example config:
```ini
executor = KubernetesExecutor
```

---
## 14.8.5 CeleryKubernetesExecutor (Hybrid)
Combine Celery + K8s.

Use cases:
- Heavy jobs go to K8s
- Lightweight tasks run on Celery workers

---
# 14.9 Scheduler Scaling
Scheduler becomes a bottleneck in large deployments.

### Airflow 2.x supports **multiple schedulers** (HA mode).
To enable:
```ini
scheduler_ha = True
num_runs = -1
```

Benefits:
- High availability
- Faster task scheduling

---
# 14.10 Worker Scaling Strategies
### Celery workers
- Add more workers as DAG volume increases
- Autoscale using:
```bash
celery worker --autoscale=20,5
```

### Kubernetes Executor
- Kubernetes handles auto-provisioning pods
- Use cluster autoscaler

---
# 14.11 Horizontal Scaling vs Vertical Scaling
### Horizontal
Add more:
- Workers
- Schedulers
- Nodes

### Vertical
Increase CPU/RAM for:
- Scheduler
- Workers
- Metadata DB

---
# 14.12 Scaling the Metadata Database
The metadata DB must scale too.

Use Postgres/MySQL with:
- Read replicas
- High IOPS storage
- Connection pooling

DO NOT use SQLite outside local development.

---
# 14.13 Scaling Logs
For distributed environments:
- Store logs in S3/GCS/Azure
- Use remote log handlers

Example:
```ini
remote_logging = True
remote_log_conn_id = aws_s3_logs
remote_base_log_folder = s3://airflow-logs/
```

---
# 14.14 Scaling DAG Parsing & Code Repositories
Large deployments may face:
- DAG parse bottlenecks
- Slow webserver load times

### Solutions:
- Modular DAG files
- Use DAG factories
- Reduce size of global imports
- Store DAGs on Git + sync to Airflow via CI/CD

---
# 14.15 Patterns for High-Scale Airflow
## 1. Micro-DAG Pattern
Break giant DAGs into smaller DAGs.

## 2. Trigger Chain Pattern
Use Event-Based triggers instead of giant graphs.

## 3. Dataset Scheduling (Airflow 2.6+)
Trigger DAGs based on data updates instead of time.

## 4. Use Kubernetes Executor for ML/compute-heavy workloads.

## 5. Use Celery for high task throughput.

---
# 14.16 Enterprise Scaling Checklist
✔ Use Celery/K8s executor  
✔ Enable HA scheduler mode  
✔ Use remote logs  
✔ Use Postgres with connection pooling  
✔ Set sensible limits for parallelism, concurrency  
✔ Use pools for external APIs  
✔ Deploy workers via autoscaling groups  
✔ Avoid huge DAGs (>200 tasks)  
✔ Use Dag Serialization (Airflow 2.3+)  
✔ Use local task logs only in dev

---
# 14.17 Summary
In this chapter, you learned:
- How Airflow scales horizontally & vertically
- Understanding parallelism & concurrency settings
- Differences between executors
- When to choose Celery vs Kubernetes
- How to scale metadata DB, scheduler, and workers
- Best practices for enterprise Airflow scaling

---

